<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
  header("location: admin_Check_customer_infos.php");
  exit;
}
require "connection.php";
// First SQL query
$sql1 = "SELECT `Client_CODE`, `Username`, `Phone`, `Email`, `Address` FROM `client_login`";
$result1 = mysqli_query($link, $sql1);

// Second SQL query
$sql2 = "SELECT `Client_CODE`, `FillupDate` FROM `customer_info_date_client_form`";
$result2 = mysqli_query($link, $sql2);

$sql3 = "SELECT
Data_Approval_Admin,
Data_Approval_CRM,
Data_Approval_HOS,
first_acc_h_Name,
Client_CODE,
Father_or_Husbands_Name,
Mother’s_Name,
Email,
Nationality,
Date_of_Birth,
Sex,
Present_Address,
Permanent_Address,
NID,
Tel,
Mobile,
Occupation,
E_tin
FROM customer_info_first_account_holder";
$result3 = mysqli_query($link, $sql3);

$sql5 = "SELECT
Data_Approval_Admin1,
Data_Approval_CRM1,
Data_Approval_HOS1,
joint_acc_h_Name,
Client_CODE,
Father_or_Husbands_Name,
Mother’s_Name,
Email,
Nationality,
Date_of_Birth,
Sex,
Present_Address,
Permanent_Address,
NID,
Tel,
Mobile,
Occupation,
E_tin
FROM customer_info_joint_account_holder";
$result5 = mysqli_query($link, $sql5);

$sql7 = "SELECT
Data_Approval_Admin2,
Data_Approval_CRM2,
Data_Approval_HOS2,
authorized_acc_h_Name,
Client_CODE,
Father_or_Husbands_Name,
Mother’s_Name,
Email,
Nationality,
Date_of_Birth,
Sex,
Present_Address,
Permanent_Address,
NID,
Tel,
Mobile,
Occupation,
E_tin
FROM customer_info_authorized_account_holder";
$result6 = mysqli_query($link, $sql7);


$sql9 = "SELECT
  Data_Approval_Admin3,
  Data_Approval_CRM3,
  Data_Approval_HOS3,
  any_stock_exchange,
  Client_CODE,
  name_of_the_Stock_Comp,
  signature_image,
  bank_name,
  branch_name,
  account_No,
  routing_No,
  F_AccH_Name,
  J_AccH_Name,
  A_AccH_Name,
  F_AccH_Signature,
  J_AccH_Signature,
  A_AccH_Signature,
  F_AccH_Signature_Date,
  J_AccH_Signature_Date,
  A_AccH_Signature_Date
FROM customer_info_rest_of_info";
$result7= mysqli_query($link, $sql9);
// Fetch and combine the data based on Client_CODE
$data = [];
$data1 = [];
$data2 = [];
$data3 = [];
while ($row = mysqli_fetch_assoc($result1)) {
  $client_code = $row['Client_CODE'];
  if (!isset($data[$client_code])) {
    $data[$client_code] = [];
  }
  $data[$client_code]['Client_CODE'] = $client_code;
  $data[$client_code]['Username'] = $row['Username'];
  $data[$client_code]['Phone'] = $row['Phone'];
  $data[$client_code]['Email'] = $row['Email'];
  $data[$client_code]['Address'] = $row['Address'];
}

while ($row = mysqli_fetch_assoc($result2)) {
  $client_code = $row['Client_CODE'];
  if (!isset($data[$client_code])) {
    $data[$client_code] = [];
  }
  // Check if 'FillupDate' key exists in the row before accessing it
  if (isset($row['FillupDate'])) {
    $data[$client_code]['FillupDate'] = $row['FillupDate'];
  }
}

while ($row = mysqli_fetch_assoc($result3)) {
  $client_code = $row['Client_CODE'];
  if (!isset($data[$client_code])) {
    $data[$client_code] = [];
  }
  $data[$client_code]['Data_Approval_Admin'] = $row['Data_Approval_Admin'];
  $data[$client_code]['first_acc_h_Name'] = $row['first_acc_h_Name'];
  $data[$client_code]['Father_or_Husbands_Name'] = $row['Father_or_Husbands_Name'];
  $data[$client_code]['Mother’s_Name'] = $row['Mother’s_Name'];
  $data[$client_code]['Nationality'] = $row['Nationality'];
  $data[$client_code]['Date_of_Birth'] = $row['Date_of_Birth'];
  $data[$client_code]['Sex'] = $row['Sex'];
  $data[$client_code]['Present_Address'] = $row['Present_Address'];
  $data[$client_code]['Permanent_Address'] = $row['Permanent_Address'];
  $data[$client_code]['NID'] = $row['NID'];
  $data[$client_code]['Tel'] = $row['Tel'];
  $data[$client_code]['Mobile'] = $row['Mobile'];
  $data[$client_code]['Occupation'] = $row['Occupation'];
  $data[$client_code]['E_tin'] = $row['E_tin'];
}
while ($row1 = mysqli_fetch_assoc($result5)) {
  $client_code = $row1['Client_CODE'];
  if (!isset($data1[$client_code])) {
    $data1[$client_code] = [];
  }
  $data1[$client_code]['Data_Approval_Admin1'] = $row1['Data_Approval_Admin1'];
  $data1[$client_code]['joint_acc_h_Name'] = $row1['joint_acc_h_Name'];
  $data1[$client_code]['Father_or_Husbands_Name'] = $row1['Father_or_Husbands_Name'];
  $data1[$client_code]['Mother’s_Name'] = $row1['Mother’s_Name'];
  $data1[$client_code]['Nationality'] = $row1['Nationality'];
  $data1[$client_code]['Date_of_Birth'] = $row1['Date_of_Birth'];
  $data1[$client_code]['Sex'] = $row1['Sex'];
  $data1[$client_code]['Present_Address'] = $row1['Present_Address'];
  $data1[$client_code]['Permanent_Address'] = $row1['Permanent_Address'];
  $data1[$client_code]['NID'] = $row1['NID'];
  $data1[$client_code]['Tel'] = $row1['Tel'];
  $data1[$client_code]['Mobile'] = $row1['Mobile'];
  $data1[$client_code]['Occupation'] = $row1['Occupation'];
  $data1[$client_code]['E_tin'] = $row1['E_tin'];
}
while ($row2 = mysqli_fetch_assoc($result6)) {
  $client_code = $row2['Client_CODE'];
  if (!isset($data2[$client_code])) {
    $data2[$client_code] = [];
  }
  $data2[$client_code]['Data_Approval_Admin2'] = $row2['Data_Approval_Admin2'];
  $data2[$client_code]['authorized_acc_h_Name'] = $row2['authorized_acc_h_Name'];
  $data2[$client_code]['Father_or_Husbands_Name'] = $row2['Father_or_Husbands_Name'];
  $data2[$client_code]['Mother’s_Name'] = $row2['Mother’s_Name'];
  $data2[$client_code]['Nationality'] = $row2['Nationality'];
  $data2[$client_code]['Date_of_Birth'] = $row2['Date_of_Birth'];
  $data2[$client_code]['Sex'] = $row2['Sex'];
  $data2[$client_code]['Present_Address'] = $row2['Present_Address'];
  $data2[$client_code]['Permanent_Address'] = $row2['Permanent_Address'];
  $data2[$client_code]['NID'] = $row2['NID'];
  $data2[$client_code]['Tel'] = $row2['Tel'];
  $data2[$client_code]['Mobile'] = $row2['Mobile'];
  $data2[$client_code]['Occupation'] = $row2['Occupation'];
  $data2[$client_code]['E_tin'] = $row2['E_tin'];
}
while ($row3 = mysqli_fetch_assoc($result7)) {
  $client_code = $row3['Client_CODE'];
  if (!isset($data2[$client_code])) {
    $data3[$client_code] = [];
  }
  $data3[$client_code]['Data_Approval_Admin3'] = $row3['Data_Approval_Admin3'];
  $data3[$client_code]['any_stock_exchange'] = $row3['any_stock_exchange'];
  $data3[$client_code]['name_of_the_Stock_Comp'] = $row3['name_of_the_Stock_Comp'];
  $data3[$client_code]['signature_image'] = $row3['signature_image'];
  $data3[$client_code]['bank_name'] = $row3['bank_name'];
  $data3[$client_code]['branch_name'] = $row3['branch_name'];
  $data3[$client_code]['account_No'] = $row3['account_No'];
  $data3[$client_code]['routing_No'] = $row3['routing_No'];
  $data3[$client_code]['F_AccH_Name'] = $row3['F_AccH_Name'];
  $data3[$client_code]['J_AccH_Name'] = $row3['J_AccH_Name'];
  $data3[$client_code]['A_AccH_Name'] = $row3['A_AccH_Name'];
  $data3[$client_code]['F_AccH_Signature'] = $row3['F_AccH_Signature'];
  $data3[$client_code]['J_AccH_Signature'] = $row3['J_AccH_Signature'];
  $data3[$client_code]['A_AccH_Signature'] = $row3['A_AccH_Signature'];
  $data3[$client_code]['F_AccH_Signature_Date'] = $row3['F_AccH_Signature_Date'];
  $data3[$client_code]['J_AccH_Signature_Date'] = $row3['J_AccH_Signature_Date'];
  $data3[$client_code]['A_AccH_Signature_Date'] = $row3['A_AccH_Signature_Date'];
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
  foreach ($data as $client_code => $row) {
    if (isset($_POST["checkbox1_$client_code"])) {
      $approvalValue = isset($_POST["checkbox1_$client_code"]) ? $_POST["checkbox1_$client_code"] : '';
      $clientCode = $client_code;
      $sql4 = "UPDATE customer_info_first_account_holder SET Data_Approval_Admin = ? WHERE Client_CODE = ?";
      $stmt = $link->prepare($sql4);
      $stmt->bind_param('si', $approvalValue, $clientCode); // 'si' represents string and integer types
      $stmt->execute();
    }
  }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
  foreach ($data1 as $client_code => $row1) {
    if (isset($_POST["checkbox2_$client_code"])) {
      $approvalValue = isset($_POST["checkbox2_$client_code"]) ? $_POST["checkbox2_$client_code"] : '';
      $clientCode = $client_code;
      $sql6 = "UPDATE customer_info_joint_account_holder SET Data_Approval_Admin1 = ? WHERE Client_CODE = ?";
      $stmt = $link->prepare($sql6);
      $stmt->bind_param('si', $approvalValue, $clientCode); // 'si' represents string and integer types
      $stmt->execute();
    }
  }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
  foreach ($data2 as $client_code => $row2) {
    if (isset($_POST["checkbox3_$client_code"])) {
      $approvalValue = isset($_POST["checkbox3_$client_code"]) ? $_POST["checkbox3_$client_code"] : '';
      $clientCode = $client_code;
      $sql8 = "UPDATE customer_info_authorized_account_holder SET Data_Approval_Admin2 = ? WHERE Client_CODE = ?";
      $stmt = $link->prepare($sql8);
      $stmt->bind_param('si', $approvalValue, $clientCode); // 'si' represents string and integer types
      $stmt->execute();
    }
  }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
  foreach ($data3 as $client_code => $row3) {
    if (isset($_POST["checkbox4_$client_code"])) {
      $approvalValue = isset($_POST["checkbox4_$client_code"]) ? $_POST["checkbox4_$client_code"] : '';
      $clientCode = $client_code;
      $sql8 = "UPDATE customer_info_rest_of_info SET Data_Approval_Admin3 = ? WHERE Client_CODE = ?";
      $stmt = $link->prepare($sql8);
      $stmt->bind_param('si', $approvalValue, $clientCode); // 'si' represents string and integer types
      $stmt->execute();
    }
  }
}
mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Check Customer Info</title>
  <meta name="theme-name" content="mono" />
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
  <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
  <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
  <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
  <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
  <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
  <link id="main-css-href" rel="stylesheet" href="css/style.css" />
  <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css" type="text/css" />
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
    type="text/css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
  <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
  <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>




  <style>
    .arrow-button {
      position: absolute;
      top: 10px;
      right: 20px;
    }

    .rotate {
      transform: rotate(180deg);
    }
  </style>

  <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
  <script>
    NProgress.configure({
      showSpinner: false
    });
    NProgress.start();
  </script>
  <div id="toaster"></div>
  <div class="wrapper">
    <aside class="left-sidebar sidebar-light" id="left-sidebar">
      <div id="sidebar" class="sidebar sidebar-with-footer">
        <!-- Aplication Brand -->
        <div class="app-brand">
          <a href="#">
            <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
          </a>
        </div>
        <!-- begin sidebar scrollbar -->
        <div class="sidebar-left" data-simplebar style="height: 100%;">
          <!-- sidebar menu -->
          <ul class="nav sidebar-inner" id="sidebar-menu">
            <li>
              <a class="sidenav-item-link" href="index-ADMIN.php">
                <i class="mdi mdi-briefcase-account-outline"></i>
                <span class="nav-text">Dashboard</span>
              </a>
            </li>
            <li class="section-title">
              Form Check
            </li>
            <li class="active">
              <a class="sidenav-item-link" href="admin_Check_customer_infos.php">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check Customer Infos</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">KYC Profile Form Fill up</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check BO ACC. OPENING</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check BO ACC. NOMINATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check (POA)</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check Terms & Conditions</span>
              </a>
            </li>

            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check EFT Enrollment</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check Signature Card</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-search"></i>
                <span class="nav-text">Check Value Added Service</span>
              </a>
            </li>
            <li class="section-title">
              Pages
            </li>

            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                <i class="mdi mdi-account"></i>
                <span class="nav-text">Authentication</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="sign-in.html">
                      <span class="nav-text">Sign In</span>

                    </a>
                  </li>

                </div>
              </ul>
            </li>
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                aria-expanded="false" aria-controls="other-page">
                <i class="mdi mdi-file-multiple"></i>
                <span class="nav-text">Other pages</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="#">
                      <span class="nav-text">Nothing</span>

                    </a>
                  </li>

                </div>
              </ul>
            </li>
            <li class="section-title">
              Documentation
            </li>
            <li>
              <a class="sidenav-item-link" href="#">
                <i class="mdi mdi-airplane"></i>
                <span class="nav-text">Nothing</span>
              </a>
            </li>
          </ul>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-footer-content">
            <ul class="d-flex">
              <li>
                <a href="#" data-toggle="tooltip" title="Profile settings"><i class="mdi mdi-settings"></i></a>
              </li>
              <li>
                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip" title="Logout"><i
                    class="mdi mdi-logout"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </aside>
    <div class="page-wrapper">

      <!-- Header -->
      <header class="main-header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <!-- Sidebar toggle button -->
          <button id="sidebar-toggler" class="sidebar-toggle">
            <span class="sr-only">Toggle navigation</span>
          </button>

          <span class="page-title">ADMIN Dashboard</span>

          <div class="navbar-right ">

            <!-- search form -->
            <div class="search-form">
              <form action="index-ADMIN.php" method="get">
                <div class="input-group input-group-sm" id="input-group-search">
                  <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                    placeholder="Search..." />
                  <div class="input-group-append">
                    <button class="btn" type="button">/</button>
                  </div>
                </div>
              </form>
              <ul class="dropdown-menu dropdown-menu-search">

                <li class="nav-item">
                  <a class="nav-link" href="index-ADMIN.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index-ADMIN.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index-ADMIN.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index-ADMIN.php"></a>
                </li>

              </ul>

            </div>

            <ul class="nav navbar-nav">
              <!-- Offcanvas -->
              <li class="custom-dropdown">
                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                  href="javascript:">
                  <i class="mdi mdi-contacts icon"></i>
                </a>
              </li>
              <li class="custom-dropdown">
                <button class="notify-toggler custom-dropdown-toggler">
                  <i class="mdi mdi-bell-outline icon"></i>
                  <span class="badge badge-xs rounded-circle">21</span>
                </button>
                <div class="dropdown-notify">

                  <header>
                    <div class="nav nav-underline" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                        aria-controls="nav-home" aria-selected="true">All
                        (5)</a>
                      <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                        aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                      <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                        aria-controls="nav-contact" aria-selected="false">Others
                        (3)</a>
                    </div>
                  </header>

                  <footer class="border-top dropdown-notify-footer">
                    <div class="d-flex justify-content-between align-items-center py-2 px-4">
                      <span>Last updated 3 min ago</span>
                      <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                    </div>
                  </footer>
                </div>
              </li>
              <!-- User Account -->
              <li class="dropdown user-menu">
                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <img
                    src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                    class="user-image rounded-circle" alt="User Image" />
                  <span class="d-none d-lg-inline-block"><b>
                      <?php echo htmlspecialchars($_SESSION["Name"]); ?></i>
                    </b>
                    <b>
                      <?php echo htmlspecialchars($_SESSION["AdminID "]); ?>
                    </b></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">

                  <li>
                    <a class="dropdown-link-item" href="#">
                      <i class="mdi mdi-settings"></i>
                      <span class="nav-text">Account Setting</span>
                    </a>
                  </li>

                  <li class="dropdown-footer">
                    <a class="dropdown-link-item" href="/debug/lanka-bangla/main-login/client_logout.php"> <i
                        class="mdi mdi-logout"></i> Log Out </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>

      </header>

      <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
      <div class="content-wrapper">
        <div class="content">
          <!-- For Components documentaion -->

          <div class="px-6 py-4">
            <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
            <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023,
                Chittagong
                Stock Exchange </span> </p>
            <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">Check
                Customer Infos</span> </p>
          </div>

          <div class="row">
            <div class="col-sm-12">
              <!-- Custom Styles -->
              <div class="card card-default">
                <div class="card-body">
                  <div class="collapse" id="collapse-data-tables">
                    <pre class="language-html mb-4">

                    </pre>
                  </div>




                  <div class="table-responsive">
                    <table id="productsTable" class="table table-hover table-product" style="width:100%">
                      <strong>Click on More Info Twice to get the actual details,it may reload the page</strong>
                      <thead>
                        <tr>
                          <th>Client CODE </th>
                          <th>Username</th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Address</th>
                          <th>Fill Up Date</th>
                          <th>First Account Holder</th>
                          <th>Joint Account Holder</th>
                          <th>Auth Account Holder</th>
                          <th>Rest Of Info</th>
                        </tr>
                      </thead>
                      <tbody>

                        <!-- <tr>

          <td>
            <div class="dropdown">
              <a class="dropdown-toggle icon-burger-mini" href="#" role="button" id="dropdownMenuLink"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">
              </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </div>
          </td>
        </tr> -->

                        <?php foreach ($data as $client_code => $row): ?>
                          <tr>
                            <td>
                              <?php echo isset($row['Client_CODE']) ? $row['Client_CODE'] : ''; ?>
                            </td>
                            <td>
                              <?php echo isset($row['Username']) ? $row['Username'] : ''; ?>
                            </td>
                            <td>
                              <?php echo isset($row['Phone']) ? $row['Phone'] : ''; ?>
                            </td>
                            <td>
                              <?php echo isset($row['Email']) ? $row['Email'] : ''; ?>
                            </td>
                            <td>
                              <?php echo isset($row['Address']) ? $row['Address'] : ''; ?>
                            </td>
                            <td>
                              <?php echo isset($row['FillupDate']) ? $row['FillupDate'] : ''; ?>
                            </td>
                            <td>

                              <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal"
                                data-target="#modalLongForCustomerInfo"
                                data-client-code="<?php echo htmlspecialchars($client_code); ?>">
                                More Info
                              </button>

                            </td>
                            <td>

                              <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal"
                                data-target="#modalLongForCustomerInfo2"
                                data-client-code="<?php echo htmlspecialchars($client_code); ?>">
                                More Info
                              </button>

                            </td>
                            <td>

                              <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal"
                                data-target="#modalLongForCustomerInfo3"
                                data-client-code="<?php echo htmlspecialchars($client_code); ?>">
                                More Info
                              </button>

                            </td>
                            <td>

                              <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal"
                                data-target="#modalLongForCustomerInfo4"
                                data-client-code="<?php echo htmlspecialchars($client_code); ?>">
                                More Info
                              </button>

                            </td>

                          </tr>
                        <?php endforeach; ?>


                        <style>
                          .table-product {
                            width: 100%;
                            overflow-x: auto;
                          }
                        </style>
                      </tbody>
                    </table>

                  </div>
                  <div class="modal fade" id="modalLongForCustomerInfo" tabindex="-1" role="dialog"
                    aria-labelledby="modalLongForCustomerInfoTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalLongForCustomerInfoTitle">Customer Account Informations</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <h2>Customer Account Informations</h2>
                          <label>Please unselect Approve first if you want to Decline</label>
                          <div class="table-responsive">
                            <table id="productsTable" class="table table-hover table-product" style="width:100%">
                              <thead>
                                <tr>
                                  <th>Check Any</th>
                                  <th>Data_Approval_Admin</th>
                                  <th>Data_Approval_CRM</th>
                                  <th>Data_Approval_HOS</th>
                                  <th>Client Code</th>
                                  <th>First Account Holder Name</th>
                                  <th>Father or Husband's Name</th>
                                  <th>Mother's Name</th>
                                  <th>Email</th>
                                  <th>Nationality</th>
                                  <th>Date of Birth</th>
                                  <th>Sex</th>
                                  <th>Present Address</th>
                                  <th>Permanent Address</th>
                                  <th>National ID</th>
                                  <th>Telephone</th>
                                  <th>Mobile</th>
                                  <th>Occupation</th>
                                  <th>E-TIN</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php foreach ($data as $client_code => $row): ?>
                                  <tr>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                                    <td>
                                        <label>
                                          <input type="checkbox" id="checkbox1_<?php echo $client_code; ?>"
                                            name="checkbox1_<?php echo $client_code; ?>" value="Approved"
                                            onchange="handleCheckboxChange('<?php echo $client_code; ?>')"
                                            <?php if (isset($data[$client_code]['Data_Approval_Admin']) && $data[$client_code]['Data_Approval_Admin'] === 'Approved') echo 'checked'; ?>
                                          >
                                          Approve
                                        </label>
                                        <label>
                                          <input type="checkbox" id="checkbox2_<?php echo $client_code; ?>"
                                            name="checkbox1_<?php echo $client_code; ?>" value="Declined"
                                            onchange="handleCheckboxChange('<?php echo $client_code; ?>')"
                                            <?php if (isset($data[$client_code]['Data_Approval_Admin']) && $data[$client_code]['Data_Approval_Admin'] === 'Declined') echo 'checked'; ?>
                                          >
                                          Decline
                                        </label>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Data_Approval_Admin']) ? $row['Data_Approval_Admin'] : ''; ?>
                                      </td>

                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>
                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>

                                      <td>
                                        <?php echo isset($row['Client_CODE']) ? $row['Client_CODE'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['first_acc_h_Name']) ? $row['first_acc_h_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Father_or_Husbands_Name']) ? $row['Father_or_Husbands_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Mother’s_Name']) ? $row['Mother’s_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Email']) ? $row['Email'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Nationality']) ? $row['Nationality'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Date_of_Birth']) ? $row['Date_of_Birth'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Sex']) ? $row['Sex'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Present_Address']) ? $row['Present_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Permanent_Address']) ? $row['Permanent_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['NID']) ? $row['NID'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Tel']) ? $row['Tel'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Mobile']) ? $row['Mobile'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['Occupation']) ? $row['Occupation'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row['E_tin']) ? $row['E_tin'] : ''; ?>
                                      </td>
                                  </tr>
                                <?php endforeach; ?>

                              </tbody>
                            </table>

                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-secondary btn-pill" name="submit"
                              id="submit">Submit</button>
                            </form>
                            <button type="button" class="btn btn-secondary btn-pill" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal fade" id="modalLongForCustomerInfo2" tabindex="-1" role="dialog"
                    aria-labelledby="modalLongForCustomerInfoTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalLongForCustomerInfoTitle">Customer Account Informations</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <h2>Customer Account Informations</h2>
                          <label>Please unselect Approve first if you want to Decline</label>
                          <div class="table-responsive">
                            <table id="productsTable" class="table table-hover table-product" style="width:100%">
                              <thead>
                                <tr>
                                  <th>Check Any</th>
                                  <th>Data_Approval_Admin</th>
                                  <th>Data_Approval_CRM</th>
                                  <th>Data_Approval_HOS</th>
                                  <th>Client Code</th>
                                  <th>Joint Account Holder Name</th>
                                  <th>Father_or_Husbands_Name</th>
                                  <th>Mother’s_Name</th>
                                  <th>Email</th>
                                  <th>Nationality</th>
                                  <th>Date_of_Birth</th>
                                  <th>Sex</th>
                                  <th>Present_Address</th>
                                  <th>Permanent_Address</th>
                                  <th>NID</th>
                                  <th>Tel</th>
                                  <th>Mobile</th>
                                  <th>Occupation</th>
                                  <th>E_tin</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php foreach ($data1 as $client_code => $row1): ?>
                                  <tr>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                                    <td>
                                        <label>
                                          <input type="checkbox" id="checkbox3_<?php echo $client_code; ?>"
                                            name="checkbox2_<?php echo $client_code; ?>" value="Approved"
                                            onchange="handleCheckboxChange1('<?php echo $client_code; ?>')"
                                            <?php if (isset($data1[$client_code]['Data_Approval_Admin1']) && $data1[$client_code]['Data_Approval_Admin1'] === 'Approved') echo 'checked'; ?>
                                          >
                                          Approve
                                        </label>
                                        <label>
                                          <input type="checkbox" id="checkbox4_<?php echo $client_code; ?>"
                                            name="checkbox2_<?php echo $client_code; ?>" value="Declined"
                                            onchange="handleCheckboxChange1('<?php echo $client_code; ?>')"
                                            <?php if (isset($data1[$client_code]['Data_Approval_Admin1']) && $data1[$client_code]['Data_Approval_Admin1'] === 'Declined') echo 'checked'; ?>
                                          >
                                          Decline
                                        </label>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Data_Approval_Admin1']) ? $row1['Data_Approval_Admin1'] : ''; ?>
                                      </td>

                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>
                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>

                                      <td>
                                        <?php echo isset($row1['Client_CODE']) ? $row1['Client_CODE'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['joint_acc_h_Name']) ? $row1['joint_acc_h_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Father_or_Husbands_Name']) ? $row1['Father_or_Husbands_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Mother’s_Name']) ? $row1['Mother’s_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Email']) ? $row1['Email'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Nationality']) ? $row1['Nationality'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Date_of_Birth']) ? $row1['Date_of_Birth'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Sex']) ? $row1['Sex'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Present_Address']) ? $row1['Present_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Permanent_Address']) ? $row1['Permanent_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['NID']) ? $row1['NID'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Tel']) ? $row1['Tel'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Mobile']) ? $row1['Mobile'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['Occupation']) ? $row1['Occupation'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row1['E_tin']) ? $row1['E_tin'] : ''; ?>
                                      </td>
                                  </tr>
                                <?php endforeach; ?>

                              </tbody>
                            </table>

                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-secondary btn-pill" name="submit"
                              id="submit">Submit</button>
                            </form>
                            <button type="button" class="btn btn-secondary btn-pill" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal fade" id="modalLongForCustomerInfo3" tabindex="-1" role="dialog"
                    aria-labelledby="modalLongForCustomerInfoTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalLongForCustomerInfoTitle">Customer Account Informations</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <h2>Customer Account Informations</h2>
                          <label>Please unselect Approve first if you want to Decline</label>
                          <div class="table-responsive">
                            <table id="productsTable" class="table table-hover table-product" style="width:100%">
                              <thead>
                                <tr>
                                  <th>Check Any</th>
                                  <th>Data_Approval_Admin</th>
                                  <th>Data_Approval_CRM</th>
                                  <th>Data_Approval_HOS</th>
                                  <th>Client Code</th>
                                  <th>Authorized Account Holder Name</th>
                                  <th>Father_or_Husbands_Name</th>
                                  <th>Mother’s_Name</th>
                                  <th>Email</th>
                                  <th>Nationality</th>
                                  <th>Date_of_Birth</th>
                                  <th>Sex</th>
                                  <th>Present_Address</th>
                                  <th>Permanent_Address</th>
                                  <th>NID</th>
                                  <th>Tel</th>
                                  <th>Mobile</th>
                                  <th>Occupation</th>
                                  <th>E_tin</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php foreach ($data2 as $client_code => $row2): ?>
                                  <tr>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                                    <td>
                                        <label>
                                          <input type="checkbox" id="checkbox5_<?php echo $client_code; ?>"
                                            name="checkbox3_<?php echo $client_code; ?>" value="Approved"
                                            onchange="handleCheckboxChange2('<?php echo $client_code; ?>')"
                                            <?php if (isset($data2[$client_code]['Data_Approval_Admin2']) && $data2[$client_code]['Data_Approval_Admin2'] === 'Approved') echo 'checked'; ?>
                                          >
                                          Approve
                                        </label>
                                        <label>
                                          <input type="checkbox" id="checkbox6_<?php echo $client_code; ?>"
                                            name="checkbox3_<?php echo $client_code; ?>" value="Declined"
                                            onchange="handleCheckboxChange2('<?php echo $client_code; ?>')"
                                            <?php if (isset($data2[$client_code]['Data_Approval_Admin2']) && $data2[$client_code]['Data_Approval_Admin2'] === 'Declined') echo 'checked'; ?>
                                          >
                                          Decline
                                        </label>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Data_Approval_Admin2']) ? $row2['Data_Approval_Admin2'] : ''; ?>
                                      </td>

                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>
                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>

                                      <td>
                                        <?php echo isset($row2['Client_CODE']) ? $row2['Client_CODE'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['authorized_acc_h_Name']) ? $row2['authorized_acc_h_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Father_or_Husbands_Name']) ? $row2['Father_or_Husbands_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Mother’s_Name']) ? $row2['Mother’s_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Email']) ? $row2['Email'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Nationality']) ? $row2['Nationality'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Date_of_Birth']) ? $row2['Date_of_Birth'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Sex']) ? $row2['Sex'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Present_Address']) ? $row2['Present_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Permanent_Address']) ? $row2['Permanent_Address'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['NID']) ? $row2['NID'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Tel']) ? $row2['Tel'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Mobile']) ? $row2['Mobile'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['Occupation']) ? $row2['Occupation'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row2['E_tin']) ? $row2['E_tin'] : ''; ?>
                                      </td>
                                  </tr>
                                <?php endforeach; ?>

                              </tbody>
                            </table>

                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-secondary btn-pill" name="submit"
                              id="submit">Submit</button>
                            </form>
                            <button type="button" class="btn btn-secondary btn-pill" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="modal fade" id="modalLongForCustomerInfo4" tabindex="-1" role="dialog"
                    aria-labelledby="modalLongForCustomerInfoTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalLongForCustomerInfoTitle">Customer Account Informations</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <h2>Customer Account Informations</h2>
                          <label>Please unselect Approve first if you want to Decline</label>
                          <div class="table-responsive">
                            <table id="productsTable" class="table table-hover table-product" style="width:100%">
                              <thead>
                                <tr>
                                <th>Data_Approval_Admin</th>
                                <th>Data_Approval_CRM</th>
                                <th>Data_Approval_HOS</th>
                                <th>any_stock_exchange</th>
                                <th>Client_CODE</th>
                                <th>name_of_the_Stock_Comp</th>
                                <th>signature_image</th>
                                <th>bank_name</th>
                                <th>branch_name</th>
                                <th>account_No</th>
                                <th>routing_No</th>
                                <th>F_AccH_Name</th>
                                <th>J_AccH_Name</th>
                                <th>A_AccH_Name</th>
                                <th>F_AccH_Signature</th>
                                <th>J_AccH_Signature</th>
                                <th>A_AccH_Signature</th>
                                <th>F_AccH_Signature_Date</th>
                                <th>J_AccH_Signature_Date</th>
                                <th>A_AccH_Signature_Date</th>
                                </tr>
                              </thead>
                              <tbody>

                                <?php foreach ($data3 as $client_code => $row3): ?>
                                  <tr>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                                    <td>
                                        <label>
                                          <input type="checkbox" id="checkbox7_<?php echo $client_code; ?>"
                                            name="checkbox4_<?php echo $client_code; ?>" value="Approved"
                                            onchange="handleCheckboxChange3('<?php echo $client_code; ?>')"
                                            <?php if (isset($data3[$client_code]['Data_Approval_Admin3']) && $data3[$client_code]['Data_Approval_Admin3'] === 'Approved') echo 'checked'; ?>
                                          >
                                          Approve
                                        </label>
                                        <label>
                                          <input type="checkbox" id="checkbox8_<?php echo $client_code; ?>"
                                            name="checkbox4_<?php echo $client_code; ?>" value="Declined"
                                            onchange="handleCheckboxChange3('<?php echo $client_code; ?>')"
                                            <?php if (isset($data3[$client_code]['Data_Approval_Admin3']) && $data3[$client_code]['Data_Approval_Admin3'] === 'Declined') echo 'checked'; ?>
                                          >
                                          Decline
                                        </label>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['Data_Approval_Admin3']) ? $row3['Data_Approval_Admin3'] : ''; ?>
                                      </td>

                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>
                                      <td>
                                        <label>

                                        </label>
                                        <label>

                                        </label>
                                      </td>

                                      <td>
                                        <?php echo isset($row3['Client_CODE']) ? $row3['Client_CODE'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['any_stock_exchange']) ? $row3['any_stock_exchange'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['name_of_the_Stock_Comp']) ? $row3['name_of_the_Stock_Comp'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['signature_image']) ? $row3['signature_image'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['bank_name']) ? $row3['bank_name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['branch_name']) ? $row3['branch_name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['account_No']) ? $row3['account_No'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['routing_No']) ? $row3['routing_No'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['F_AccH_Name']) ? $row3['F_AccH_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['J_AccH_Name']) ? $row3['J_AccH_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['A_AccH_Name']) ? $row3['A_AccH_Name'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['F_AccH_Signature']) ? $row3['F_AccH_Signature'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['J_AccH_Signature']) ? $row3['J_AccH_Signature'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['A_AccH_Signature']) ? $row3['A_AccH_Signature'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['F_AccH_Signature_Date']) ? $row3['F_AccH_Signature_Date'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['J_AccH_Signature_Date']) ? $row3['J_AccH_Signature_Date'] : ''; ?>
                                      </td>
                                      <td>
                                        <?php echo isset($row3['A_AccH_Signature_Date']) ? $row3['A_AccH_Signature_Date'] : ''; ?>
                                      </td>
                                  </tr>
                                <?php endforeach; ?>

                              </tbody>
                            </table>

                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-secondary btn-pill" name="submit"
                              id="submit">Submit</button>
                            </form>
                            <button type="button" class="btn btn-secondary btn-pill" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <script>
                    // Function to handle checkbox change
                    function handleCheckboxChange(clientCode) {
                      var checkbox1 = document.getElementById('checkbox1_' + clientCode);
                      var checkbox2 = document.getElementById('checkbox2_' + clientCode);

                      // Disable the other checkbox if this one is checked
                      if (checkbox1.checked) {
                        checkbox2.disabled = true;
                      } else if (checkbox2.checked) {
                        checkbox1.disabled = true;
                      } else {
                        checkbox1.disabled = false;
                        checkbox2.disabled = false;
                      }
                    }
                  </script>
                   <script>
                    // Function to handle checkbox change
                    function handleCheckboxChange1(clientCode) {
                      var checkbox3 = document.getElementById('checkbox3_' + clientCode);
                      var checkbox4 = document.getElementById('checkbox4_' + clientCode);

                      // Disable the other checkbox if this one is checked
                      if (checkbox3.checked) {
                        checkbox4.disabled = true;
                      } else if (checkbox4.checked) {
                        checkbox3.disabled = true;
                      } else {
                        checkbox3.disabled = false;
                        checkbox4.disabled = false;
                      }
                    }
                  </script>
                   <script>
                    // Function to handle checkbox change
                    function handleCheckboxChange2(clientCode) {
                      var checkbox5 = document.getElementById('checkbox5_' + clientCode);
                      var checkbox6 = document.getElementById('checkbox6_' + clientCode);

                      // Disable the other checkbox if this one is checked
                      if (checkbox5.checked) {
                        checkbox6.disabled = true;
                      } else if (checkbox6.checked) {
                        checkbox5.disabled = true;
                      } else {
                        checkbox5.disabled = false;
                        checkbox6.disabled = false;
                      }
                    }
                  </script>
                   <script>
                    // Function to handle checkbox change
                    function handleCheckboxChange3(clientCode) {
                      var checkbox7 = document.getElementById('checkbox7_' + clientCode);
                      var checkbox8 = document.getElementById('checkbox8_' + clientCode);

                      // Disable the other checkbox if this one is checked
                      if (checkbox7.checked) {
                        checkbox8.disabled = true;
                      } else if (checkbox8.checked) {
                        checkbox7.disabled = true;
                      } else {
                        checkbox7.disabled = false;
                        checkbox8.disabled = false;
                      }
                    }
                  </script>
                </div>
              </div>

            </div>

          </div>
        </div>
        <!-- Footer -->
        <footer class="footer mt-auto">
          <div class="copyright bg-white">
            <p>
              Noushin Nurjahan
            </p>
          </div>
          <script>
            var d = new Date();
            var year = d.getFullYear();
            document.getElementById("copy-year").innerHTML = year;
          </script>
        </footer>
      </div>


    </div>


    <!-- Card Offcanvas -->
    <div class="card card-offcanvas" id="contact-off">
      <div class="card-header">
        <h2>SideBar ItemRight</h2>
        <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
      </div>
      <div class="card-body">

        <div class="mb-4">
          <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
            placeholder="Search Item...">
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

      </div>
    </div>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/simplebar/simplebar.min.js"></script>
    <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

    <script src="plugins/prism/prism.js"></script>

    <script src="js/mono.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/map.js"></script>
    <script src="js/custom.js"></script>

    <!--  -->

</body>

</html>