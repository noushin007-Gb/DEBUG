<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: customer_BO_account_form.php");
    exit;
}
require_once "connection.php";
$Client_CODE = $_SESSION["Client_CODE"];
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Date"])) {
    // Extract and sanitize form data for the first account holder
    $Application = trim($_POST["Application"]);
    $Date = trim($_POST["Date"]);
    $Date_Account_Opened = trim($_POST["Date_Account_Opened"]);
    $Name_of_CDBL_Participant = trim($_POST["Name_of_CDBL_Participant"]);
    $CDBL_Participant_ID = trim($_POST["CDBL_Participant_ID"]);
    $bo_type = isset($_POST["bo_type"]) ? $_POST["bo_type"] : '';
    $bo_category = isset($_POST["bo_category"]) ? $_POST["bo_category"] : '';
    if (empty($Application)) {
        $Application_err = "Enter your Text here";
    } elseif (strlen($Application) > 255) {
        $Application_err = "Text should have 255 characters or less.";
    }
    if (empty($Date)) {
        $Date_err = "Enter Date";
    }

    if (empty($Date_Account_Opened)) {
        $Date_Account_Opened_err = "Enter Date Account Opened";
    }

    if (!empty($CDBL_Participant_ID) && (!is_numeric($CDBL_Participant_ID) || strlen($CDBL_Participant_ID) !== 7)) {
        $CDBL_Participant_ID_err = "Enter CDBL Participant ID 7 Digit";
    }

    if (empty($bo_category)) {
        $bo_category_err = "Select Bo Category";
    }
    if (empty($bo_type)) {
        $bo_type_err = "Select Bo Type";
    }

    if (
        empty($bo_category_err) && empty($bo_type_err) &&
        empty($CDBL_Participant_ID_err) && empty($Name_of_CDBL_Participant_err) && empty($Date_Account_Opened_err) &&
        empty($Date_err) && empty($Application_err)
    ) {

        $checkQuery2 = "SELECT Client_CODE FROM customer_bo_account_opening_form WHERE Client_CODE = ?";
        if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
            mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
            mysqli_stmt_execute($checkStmt2);
            mysqli_stmt_store_result($checkStmt2);
            if (mysqli_stmt_num_rows($checkStmt2) == 0) {

                $insertQuery2 = "INSERT INTO customer_bo_account_opening_form (Date,Application,bo_category,
        bo_type,Name_of_CDBL_Participant,CDBL_Participant_ID,Client_CODE ,Date_Account_Opened) VALUES (?,?,?,?,?,?,?,?)";
                if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
                    mysqli_stmt_bind_param(
                        $insertStmt2,
                        "ssssssss",
                        $Date,
                        $Application,
                        $bo_category,
                        $bo_type,
                        $Name_of_CDBL_Participant,
                        $CDBL_Participant_ID,
                        $Client_CODE,
                        $Date_Account_Opened
                    );

                    if (mysqli_stmt_execute($insertStmt2)) {
                        // Redirect to success page or display a success message
                        $errorMessage = "Success!!!";
                        $displayError = true; // Set this based on your error condition

                    } else {
                        echo "Something went wrong. Please try again later.";
                    }
                    mysqli_stmt_close($insertStmt2);
                }
            } else {
                $errorMessage = "You Have Already Filled Up BO Account form";
                $displayError = true; // Set this based on your error condition
            }
        }
    }
}


//this is for generating bo id from the form

$sql3 = "SELECT BO_ID FROM customer_bo_account_opening_form WHERE Client_CODE=$Client_CODE";
$result2 = $link->query($sql3);
if ($result2->num_rows > 0) {
    // Assuming you're retrieving a single row, you can use fetch_assoc()
    $row = $result2->fetch_assoc();

    // Store the BO_ID in the session variable
    $_SESSION["BO_ID"] = $row["BO_ID"];
    $displayBOID = htmlspecialchars($_SESSION["BO_ID"]);
} else {
    $displayBOID = "AUTO GENERATED";
}




if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nameOfFullAccount2"])) {
    // Extract and sanitize form data for the first account holder
    $nameOfFullAccount2 = trim($_POST["nameOfFullAccount2"]);
    $TitleOfAccount2 = trim($_POST["TitleOfAccount2"]);
    $contactPersonName2 = trim($_POST["contactPersonName2"]);
    $individualGender2 = isset($_POST["individualGender2"]) ? $_POST["individualGender2"] : '';
    $occupation2 = trim($_POST["occupation2"]);
    $nid_bo2 = trim($_POST["nid_bo2"]);
    $fatherHusbandName2 = trim($_POST["fatherHusbandName2"]);
    $motherName2 = trim($_POST["motherName2"]);
    $Address2 = trim($_POST["Address2"]);
    $City2 = trim($_POST["City2"]);
    $PostCode2 = trim($_POST["PostCode2"]);
    $State2 = trim($_POST["State2"]);
    $Country2 = trim($_POST["Country2"]);
    $Telephone2 = trim($_POST["Telephone2"]);
    $MobilePhone2 = trim($_POST["MobilePhone2"]);
    $Fax2 = trim($_POST["Fax2"]);
    $email_id2 = trim($_POST["email_id2"]);
    $PassportNo2 = trim($_POST["PassportNo2"]);
    $IssuePlace2 = trim($_POST["IssuePlace2"]);
    $IssueDate2 = trim($_POST["IssueDate2"]);
    $ExpiryDate2 = trim($_POST["ExpiryDate2"]);
    $BankName2 = trim($_POST["BankName2"]);
    $BranchName2 = trim($_POST["BranchName2"]);
    $AccountNo2 = trim($_POST["AccountNo2"]);
    $RoutingNo2 = trim($_POST["RoutingNo2"]);
    $TinTaxID2 = trim($_POST["TinTaxID2"]);
    $ElectronicDividendCredit2 = isset($_POST["ElectronicDividendCredit2"]) ? $_POST["ElectronicDividendCredit2"] : '';
    $TaxExemption = isset($_POST["TaxExemption"]) ? $_POST["TaxExemption"] : '';
    $residency = isset($_POST["residency"]) ? $_POST["residency"] : '';
    $statementCycle = isset($_POST["statementCycle"]) ? $_POST["statementCycle"] : '';
    $otherStatementCycle = isset($_POST["otherStatementCycle"]) ? trim($_POST["otherStatementCycle"]) : ' ';
    $Nationality2 = trim($_POST["Nationality2"]);
    $DateOfBirth3 = trim($_POST["DateOfBirth3"]);
    $InternalRefNo3 = trim($_POST["InternalRefNo3"]);
    $InCaseOfCompany3 = trim($_POST["InCaseOfCompany3"]);
    $RegistrationNo3 = trim($_POST["RegistrationNo3"]);
    $nameOfJointAccount2 = trim($_POST["nameOfJointAccount2"]);
    $jointTitleOfAccount2 = trim($_POST["jointTitleOfAccount2"]);
    $customCheck4 = isset($_POST["customCheck4"]) ? $_POST["customCheck4"] : '';
    $depositoryAccountCode1 = isset($_POST["depositoryAccountCode1"]) ? trim($_POST["depositoryAccountCode1"]) : ' ';
    $customCheckExchange = isset($_POST["customCheckExchange"]) ? $_POST["customCheckExchange"] : '';
    $depositoryAccountCodeDSE = isset($_POST["depositoryAccountCodeDSE"]) ? trim($_POST["depositoryAccountCodeDSE"]) : ' ';
    $depositoryAccountCodeCSE = isset($_POST["depositoryAccountCodeCSE"]) ? trim($_POST["depositoryAccountCodeCSE"]) : ' ';
    $customCheck5 = isset($_POST["customCheck5"]) ? $_POST["customCheck5"] : '';
    $firstAccName1 = trim($_POST["firstAccName1"]);
    $secondAccName2 = trim($_POST["secondAccName2"]);
    $thirdAccName3 = trim($_POST["thirdAccName3"]);
    $customCheckInstructions = isset($_POST["customCheckInstructions"]) ? $_POST["customCheckInstructions"] : '';
    $IntroducerName1 = trim($_POST["IntroducerName1"]);
    $AccountID1 = trim($_POST["AccountID1"]);
    $DateOfRegistration3 = trim($_POST["DateOfRegistration3"]);


    if (empty($nameOfFullAccount2)) {
        $nameOfFullAccount2_err = "Enter your Name here";
    } elseif (strlen($nameOfFullAccount2) > 40) {
        $nameOfFullAccount2_err = "Name should have 40 characters or less.";
    }

    if (empty($TitleOfAccount2)) {
        $TitleOfAccount2_err = "Enter your title here";
    } elseif (strlen($TitleOfAccount2) > 10) {
        $TitleOfAccount2_err = "title should have 10 characters or less.";
    }

    if (empty($contactPersonName2)) {
        $contactPersonName2_err = "Enter your contact person name here";
    } elseif (strlen($contactPersonName2) > 40) {
        $TcontactPersonName2_err = "Contact Person Name should have 40 characters or less.";
    }
    if (empty($individualGender2)) {
        $individualGender2_err = "Select Individual Gender";
    }

    if (empty($occupation2)) {
        $occupation2_err = "Enter your occupation here";
    } elseif (strlen($occupation2) > 100) {
        $occupation2_err = "occupation should have 100 characters or less.";
    }

    if (empty($nid_bo2) && !preg_match('/^\d{11}(\d{6})?$/', $nid_bo2)) {
        $nid_bo2_err = "Enter a valid NID (11 or 17 digits).";
    }

    if (empty($fatherHusbandName2)) {
        $fatherHusbandName2_err = "Enter your Father/Husband Name here";
    } elseif (strlen($fatherHusbandName2) > 40) {
        $fatherHusbandName2_err = "Father/Husband Name should have 40 characters or less.";
    }
    if (empty($motherName2)) {
        $motherName2_err = "Enter your Mother Name here";
    } elseif (strlen($motherName2) > 40) {
        $motherName2_err = "Mother Name should have 40 characters or less.";
    }
    if (empty($Address2)) {
        $Address2_err = "Enter your Address here";
    } elseif (strlen($Address2) > 100) {
        $Address2_err = "Address should have 100 characters or less.";
    }

    if (empty($City2)) {
        $City2_err = "Enter your city here";
    } elseif (strlen($City2) > 50) {
        $City2_err = "City should have 50 characters or less.";
    }
    if (empty($PostCode2) && (!is_numeric($PostCode2) || strlen($PostCode2) !== 4)) {
        $PostCode2_err = "Enter a valid postCOde (4 digits).";
    }
    if (empty($State2)) {
        $State2_err = "Enter your state here";
    } elseif (strlen($State2) > 30) {
        $State2_err = "State should have 30 characters or less.";
    }
    if (empty($Country2)) {
        $Country2_err = "Enter your Country Name here";
    } elseif (strlen($Country2) > 100) {
        $Country2_err = "Country Name should have 100 characters or less.";
    }
    if (empty($Telephone2) && (!is_numeric($Telephone2) || strlen($Telephone2) !== 11)) {
        $Telephone2_err = "Enter a valid Telephone Number (11 digits).";
    }
    if (empty($MobilePhone2) && (!is_numeric($MobilePhone2) || strlen($MobilePhone2) !== 11)) {
        $MobilePhone2_err = "Enter a valid Mobile Number (11 digits).";
    }
    if (empty($Fax2) && (!is_numeric($Fax2)) || !preg_match('/^\d{1,15}$/', $Fax2)) {
        $Fax2_err = "Enter a valid FAX (up to 15 digits).";
    }
    if (empty($email_id2)) {
        $email_id2_err = "Enter Email.";
    } elseif (strlen($email_id2) > 50) {
        $email_id2_err = "Email should have 50 characters or less.";
    }
    if (empty($PassportNo2)) {
        $PassportNo2_err = "Enter your PassportNo here";
    } elseif (strlen($PassportNo2) > 20) {
        $PassportNo2_err = "PassportNo should have 20 characters or less.";
    }
    if (empty($IssuePlace2)) {
        $IssuePlace2_err = "Enter your IssuePlace here";
    } elseif (strlen($IssuePlace2) > 100) {
        $IssuePlace2_err = "IssuePlace should have 100 characters or less.";
    }
    if (empty($IssueDate2)) {
        $IssueDate2_err = "Enter Issue Date.";
    }
    if (empty($DateOfRegistration3)) {
        $DateOfRegistration3_err = "Enter Registration Date Date.";
    }
    if (empty($ExpiryDate2)) {
        $ExpiryDate2_err = "Enter Expiry Date.";
    }
    if (empty($BankName2)) {
        $BankName2_err = "Enter your Bank Name here";
    } elseif (strlen($BankName2) > 100) {
        $BankName2_err = "Bank Name should have 100 characters or less.";
    }
    if (empty($BranchName2)) {
        $BranchName2_err = "Enter your Branch Name here";
    } elseif (strlen($BranchName2) > 100) {
        $BranchName2_err = "Branch Name should have 100 characters or less.";
    }
    if (empty($AccountNo2) && (!is_numeric($AccountNo2)) || !preg_match('/^\d{1,25}$/', $AccountNo2)) {
        $AccountNo2_err = "Enter a valid Account No (up to 25 digits).";
    }
    if (empty($RoutingNo2) && (!is_numeric($RoutingNo2)) || !preg_match('/^\d{1,25}$/', $RoutingNo2)) {
        $RoutingNo2_err = "Enter a valid Routing No (up to 25 digits).";
    }

    if (empty($TinTaxID2) && (!is_numeric($TinTaxID2)) || !preg_match('/^\d{1,25}$/', $TinTaxID2)) {
        $TinTaxID2_err = "Enter a valid Account No (up to 25 digits).";
    }

    if (empty($ElectronicDividendCredit2)) {
        $ElectronicDividendCredit2_err = "Select Electronic Dividend Credit";
    }
    if (empty($TaxExemption)) {
        $TaxExemption_err = "Select Tax Exemption";
    }
    if (empty($residency)) {
        $residency_err = "Select Residency";
    }
    if (empty($statementCycle)) {
        $statementCycle_err = "Select a statementCycle";
    }
    if (empty($Nationality2)) {
        $Nationality2_err = "Enter your Nationality here";
    } elseif (strlen($Nationality2) > 50) {
        $Nationality2_err = "Nationality should have 50 characters or less.";
    }

    if (empty($DateOfBirth3)) {
        $DateOfBirth3_err = "Enter Birth Date.";
    }
    if (empty($InternalRefNo3)) {
        $InternalRefNo3_err = "Enter your Internal Ref No here";
    } elseif (strlen($InternalRefNo3) > 25) {
        $InternalRefNo3_err = "Internal Ref No should have 25 characters or less.";
    }
    if (empty($InCaseOfCompany3)) {
        $InCaseOfCompany3_err = "Enter your InCaseCompany here";
    } elseif (strlen($InCaseOfCompany3) > 50) {
        $InCaseOfCompany3_err = "InCaseCompany should have 50 characters or less.";
    }
    if (empty($RegistrationNo3) && (!is_numeric($RegistrationNo3)) || !preg_match('/^\d{1,25}$/', $RegistrationNo3)) {
        $RegistrationNo3_err = "Enter a valid Registration No upto 25 numbers.";
    }
    if (empty($nameOfJointAccount2)) {
        $nameOfJointAccount2_err = "Enter the Name of Join Account here";
    } elseif (strlen($nameOfJointAccount2) > 40) {
        $nameOfJointAccount2_err = "Name of Join Account should have 40 characters or less.";
    }
    if (empty($jointTitleOfAccount2)) {
        $jointTitleOfAccount2_err = "Enter your joint Title Of Account here";
    } elseif (strlen($jointTitleOfAccount2) > 10) {
        $jointTitleOfAccount2_err = "Joint Title Of Account should have 10 characters or less.";
    }
    if (empty($customCheck4)) {
        $customCheck4_err = "Select Any";
    }
    // if (!empty($depositoryAccountCode1) && (!is_numeric($depositoryAccountCode1) || strlen($depositoryAccountCode1) !== 7)) {
    //     $depositoryAccountCode1_err = "Enter a valid depository Account Bo No (7 digits).";
    // }

    // if (!empty($depositoryAccountCodeDSE) && (!is_numeric($depositoryAccountCodeDSE) || strlen($depositoryAccountCodeDSE) !== 7)) {
    //     $depositoryAccountCodeDSE_err = "Enter a valid depository Account DSE No(7 digits).";
    // }
    // if (!empty($depositoryAccountCodeCSE) && (!is_numeric($depositoryAccountCodeCSE) || strlen($depositoryAccountCodeCSE) !== 7)) {
    //     $depositoryAccountCodeCSE_err = "Enter a valid depository Account CSE No(7 digits).";
    // }
    if (empty($customCheckExchange)) {
        $customCheckExchange_err = "Select Any Exchange";
    }
    if (empty($customCheck5)) {
        $customCheck5_err = "Select Any";
    }
    if (empty($firstAccName1)) {
        $firstAccName1_err = "Enter your first Acc Name here";
    } elseif (strlen($firstAccName1) > 40) {
        $firstAccName1_err = "first Acc Name should have 40 characters or less.";
    }
    if (empty($secondAccName2)) {
        $secondAccName2_err = "Enter your second Acc Name here";
    } elseif (strlen($secondAccName2) > 40) {
        $secondAccName2_err = "second Acc Name should have 40 characters or less.";
    }
    if (empty($thirdAccName3)) {
        $thirdAccName3_err = "Enter your third Acc Name here";
    } elseif (strlen($thirdAccName3) > 40) {
        $thirdAccName3_err = "third Acc Name should have 40 characters or less.";
    }
    if (empty($customCheckInstructions)) {
        $customCheckInstructions_err = "Select Any";
    }
    if (empty($IntroducerName1)) {
        $IntroducerName1_err = "Enter Introducer Name here";
    } elseif (strlen($IntroducerName1) > 40) {
        $IntroducerName1_err = "Introducer Name should have 40 characters or less.";
    }

    if (empty($AccountID1) && (!is_numeric($AccountID1) || strlen($AccountID1) !== 7)) {
        $AccountID1_err = "Enter a valid Account No(7 digits).";
    }

    if (
        empty($nameOfFullAccount2_err) && empty($TitleOfAccount2_err) &&
        empty($contactPersonName2_err) && empty($individualGender2_err) &&
        empty($occupation2_err) && empty($nid_bo2_err) &&
        empty($fatherHusbandName2_err) && empty($motherName2_err) &&
        empty($Address2_err) && empty($City2_err) &&
        empty($PostCode2_err) && empty($State2_err) &&
        empty($Country2_err) && empty($Telephone2_err) &&
        empty($MobilePhone2_err) && empty($Fax2_err) &&
        empty($email_id2_err) && empty($PassportNo2_err) &&
        empty($IssuePlace2_err) && empty($IssueDate2_err) &&
        empty($ExpiryDate2_err) && empty($BankName2_err) &&
        empty($BranchName2_err) && empty($AccountNo2_err) &&
        empty($RoutingNo2_err) && empty($TinTaxID2_err) &&
        empty($ElectronicDividendCredit2_err) && empty($TaxExemption_err) &&
        empty($residency_err) && empty($statementCycle_err) &&
        empty($Nationality2_err) && empty($DateOfBirth3_err) &&
        empty($InternalRefNo3_err) && empty($InCaseOfCompany3_err) &&
        empty($RegistrationNo3_err) && empty($nameOfJointAccount2_err) &&
        empty($jointTitleOfAccount2_err) && empty($customCheck4_err) &&
        empty($customCheckExchange_err) &&
        empty($customCheck5_err) && empty($firstAccName1_err) &&
        empty($secondAccName1_err) && empty($thirdAccName3_err) &&
        empty($customCheckInstructions_err) && empty($IntroducerName1_err) &&
        empty($AccountID1_err) && empty($DateOfRegistration3_err)
    ) {
        try {
            $checkQuery2 = "SELECT Client_CODE FROM customer_bo_account_opening_form_part2 WHERE Client_CODE = ?";
            if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
                mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
                mysqli_stmt_execute($checkStmt2);
                mysqli_stmt_store_result($checkStmt2);
                if (mysqli_stmt_num_rows($checkStmt2) == 0) {

                    $insertQuery2 = "INSERT INTO customer_bo_account_opening_form_part2 (
                Client_CODE,
                BO_ID,
                nameOfFullAccount2,
                TitleOfAccount2,
                contactPersonName2,
                individualGender2,
                occupation2,
                nid_bo2,
                fatherHusbandName2,
                motherName2,
                Address2,
                City2,
                PostCode2,
                State2,
                Country2,
                Telephone2,
                MobilePhone2,
                Fax2,
                email_id2,
                PassportNo2,
                IssuePlace2,
                IssueDate2,
                ExpiryDate2,
                BankName2,
                BranchName2,
                AccountNo2,
                RoutingNo2,
                TinTaxID2,
                ElectronicDividendCredit2,
                TaxExemption,
                residency,
                statementCycle,
                otherStatementCycle,
                Nationality2,
                DateOfBirth3,
                InternalRefNo3,
                InCaseOfCompany3,
                RegistrationNo3,
                nameOfJointAccount2,
                jointTitleOfAccount2,
                customCheck4,
                depositoryAccountCode1,
                customCheckExchange,
                depositoryAccountCodeDSE,
                depositoryAccountCodeCSE,
                customCheck5,
                firstAccName1,
                secondAccName2,
                thirdAccName3,
                customCheckInstructions,
                IntroducerName1,
                AccountID1,
                DateOfRegistration3
            ) VALUES (?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
             ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
              ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
                        mysqli_stmt_bind_param(
                            $insertStmt2,
                            "sssssssssssssssssssssssssssssssssssssssssssssssssssss",
                            $Client_CODE,
                            $displayBOID,
                            $nameOfFullAccount2,
                            $TitleOfAccount2,
                            $contactPersonName2,
                            $individualGender2,
                            $occupation2,
                            $nid_bo2,
                            $fatherHusbandName2,
                            $motherName2,
                            $Address2,
                            $City2,
                            $PostCode2,
                            $State2,
                            $Country2,
                            $Telephone2,
                            $MobilePhone2,
                            $Fax2,
                            $email_id2,
                            $PassportNo2,
                            $IssuePlace2,
                            $IssueDate2,
                            $ExpiryDate2,
                            $BankName2,
                            $BranchName2,
                            $AccountNo2,
                            $RoutingNo2,
                            $TinTaxID2,
                            $ElectronicDividendCredit2,
                            $TaxExemption,
                            $residency,
                            $statementCycle,
                            $otherStatementCycle,
                            $Nationality2,
                            $DateOfBirth3,
                            $InternalRefNo3,
                            $InCaseOfCompany3,
                            $RegistrationNo3,
                            $nameOfJointAccount2,
                            $jointTitleOfAccount2,
                            $customCheck4,
                            $depositoryAccountCode1,
                            $customCheckExchange,
                            $depositoryAccountCodeDSE,
                            $depositoryAccountCodeCSE,
                            $customCheck5,
                            $firstAccName1,
                            $secondAccName2,
                            $thirdAccName3,
                            $customCheckInstructions,
                            $IntroducerName1,
                            $AccountID1,
                            $DateOfRegistration3
                        );

                        if (mysqli_stmt_execute($insertStmt2)) {
                            // Redirect to success page or display a success message
                            $errorMessage = "Success!!!";
                            $displayError = true; // Set this based on your error condition
                        } else {
                            $errorMessage = "Something went wrong. Please try again later.";
                        }
                        mysqli_stmt_close($insertStmt2);

                    }
                } else {
                    $errorMessage = "You Have Already Filled Up BO Account Part 2 form";
                    $displayError = true; // Set this based on your error condition
                }
            }
        } catch (mysqli_sql_exception $e) {
            // Handle the foreign key constraint violation error
            $errorMessage = "You Have to fill up the upper form first!!!";
            // You can log the error, display a user-friendly message, or take appropriate action.
            // For example, you can redirect the user to an error page.
            $displayError = true;
        }
    }
}
// Close the database connection
mysqli_close($link);
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Fill Customer Info</title>
    <meta name="theme-name" content="mono" />
    <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
    <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
    <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
    <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
    <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
    <link id="main-css-href" rel="stylesheet" href="css/style.css" />
    <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
    <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css"
        type="text/css" />
    <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
        type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
    <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>

    <style>
        .arrow-button {
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .rotate {
            transform: rotate(180deg);
        }
    </style>
    <style>
        .hidden {
            display: none;
        }

        .custom-alert {
            position: relative;
            background-color: #187016;
            color: #fff;
            padding: 10px;
            width: 500px;
            border-radius: 5px;
        }

        .close-button {
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 20px;
            cursor: pointer;
            z-index: 1;
            padding-left: 5px;
            /* Ensure the cross is on top */
        }
    </style>

    <script>
        /* for alert box */
        document.addEventListener("DOMContentLoaded", function() {
            const errorDiv = document.getElementById("errorDiv");
            const closeButton = document.getElementById("closeButton");
            closeButton.addEventListener("click", function() {
                errorDiv.style.display = "none";
            });
            setTimeout(function() {
                errorDiv.style.display = "none";
            }, 3000);
        });
    </script>
    <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
    <script>
        NProgress.configure({
            showSpinner: false
        });
        NProgress.start();
    </script>
    <div id="toaster"></div>
    <div class="wrapper">
        <aside class="left-sidebar sidebar-light" id="left-sidebar">
            <div id="sidebar" class="sidebar sidebar-with-footer">
                <!-- Aplication Brand -->
                <div class="app-brand">
                    <a href="#">
                        <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
                    </a>
                </div>
                <!-- begin sidebar scrollbar -->
                <div class="sidebar-left" data-simplebar style="height: 100%;">
                    <!-- sidebar menu -->
                    <ul class="nav sidebar-inner" id="sidebar-menu">
                        <li>
                            <a class="sidenav-item-link" href="index.php">
                                <i class="mdi mdi-briefcase-account-outline"></i>
                                <span class="nav-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="section-title">
                            Forms
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_opening_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">ACCOUNT INFORMATION</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">CREDIT FACILITY</span>
                            </a>
                        </li>
                        <li class="active">
                            <a class="sidenav-item-link" href="customer_BO_account_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">BO ACC. OPENING</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">BO ACC. NOMINATION</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_POA.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Power of Attorney (POA)</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_application_for_terms_and_conditions_by_laws.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Terms & Conditions</span>
                            </a>
                        </li>

                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">EFT Enrollment</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Signature Card</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Value Added Service</span>
                            </a>
                        </li>
                        <li class="section-title">
                            Pages
                        </li>

                        <li class="has-sub">
                            <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                                <i class="mdi mdi-account"></i>
                                <span class="nav-text">Authentication</span> <b class="caret"></b>
                            </a>
                            <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                                <div class="sub-menu">
                                    <li>
                                        <a class="sidenav-item-link" href="sign-in.html">
                                            <span class="nav-text">Sign In</span>

                                        </a>
                                    </li>

                                </div>
                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                                data-target="#other-page" aria-expanded="false" aria-controls="other-page">
                                <i class="mdi mdi-file-multiple"></i>
                                <span class="nav-text">Other pages</span> <b class="caret"></b>
                            </a>
                            <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                                <div class="sub-menu">
                                    <li>
                                        <a class="sidenav-item-link" href="#">
                                            <span class="nav-text">Nothing</span>

                                        </a>
                                    </li>

                                </div>
                            </ul>
                        </li>
                        <li class="section-title">
                            Documentation
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="#">
                                <i class="mdi mdi-airplane"></i>
                                <span class="nav-text">Nothing</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-footer">
                    <div class="sidebar-footer-content">
                        <ul class="d-flex">
                            <li>
                                <a href="#" data-toggle="tooltip" title="Profile settings"><i
                                        class="mdi mdi-settings"></i></a>
                            </li>
                            <li>
                                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip"
                                    title="Logout"><i class="mdi mdi-logout"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </aside>
        <div class="page-wrapper">

            <!-- Header -->
            <header class="main-header" id="header">
                <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
                    <!-- Sidebar toggle button -->
                    <button id="sidebar-toggler" class="sidebar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                    </button>

                    <span class="page-title">Customer Dashboard</span>

                    <div class="navbar-right ">

                        <!-- search form -->
                        <div class="search-form">
                            <form action="index.php" method="get">
                                <div class="input-group input-group-sm" id="input-group-search">
                                    <input type="text" autocomplete="off" name="query" id="search-input"
                                        class="form-control" placeholder="Search..." />
                                    <div class="input-group-append">
                                        <button class="btn" type="button">/</button>
                                    </div>
                                </div>
                            </form>
                            <ul class="dropdown-menu dropdown-menu-search">

                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>

                            </ul>

                        </div>

                        <ul class="nav navbar-nav">
                            <!-- Offcanvas -->
                            <li class="custom-dropdown">
                                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                                    href="javascript:">
                                    <i class="mdi mdi-contacts icon"></i>
                                </a>
                            </li>
                            <li class="custom-dropdown">
                                <button class="notify-toggler custom-dropdown-toggler">
                                    <i class="mdi mdi-bell-outline icon"></i>
                                    <span class="badge badge-xs rounded-circle">21</span>
                                </button>
                                <div class="dropdown-notify">

                                    <header>
                                        <div class="nav nav-underline" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab"
                                                href="#all" role="tab" aria-controls="nav-home" aria-selected="true">All
                                                (5)</a>
                                            <a class="nav-item nav-link" id="message-tab" data-toggle="tab"
                                                href="#message" role="tab" aria-controls="nav-profile"
                                                aria-selected="false">Msgs (4)</a>
                                            <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other"
                                                role="tab" aria-controls="nav-contact" aria-selected="false">Others
                                                (3)</a>
                                        </div>
                                    </header>

                                    <footer class="border-top dropdown-notify-footer">
                                        <div class="d-flex justify-content-between align-items-center py-2 px-4">
                                            <span>Last updated 3 min ago</span>
                                            <a id="refress-button" href="javascript:"
                                                class="btn mdi mdi-cached btn-refress"></a>
                                        </div>
                                    </footer>
                                </div>
                            </li>
                            <!-- User Account -->
                            <li class="dropdown user-menu">
                                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                                    <img src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                                        class="user-image rounded-circle" alt="User Image" />
                                    <span
                                        class="d-none d-lg-inline-block"><b><?php echo htmlspecialchars($_SESSION["username"]); ?></i></b>
                                        <b><?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?></b></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">

                                    <li>
                                        <a class="dropdown-link-item" href="#">
                                            <i class="mdi mdi-settings"></i>
                                            <span class="nav-text">Account Setting</span>
                                        </a>
                                    </li>

                                    <li class="dropdown-footer">
                                        <a class="dropdown-link-item"
                                            href="/debug/lanka-bangla/main-login/client_logout.php"> <i
                                                class="mdi mdi-logout"></i> Log Out </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>

            </header>

            <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
            <div class="content-wrapper">
                <div class="content">
                    <!-- For Components documentaion -->

                    <div class="px-6 py-4">
                        <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
                        <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023,
                                Chittagong
                                Stock Exchange </span> </p>
                        <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">BO ACCOUNT
                                OPENING FORM </span> </p>
                        <div class="alert alert-dark <?php if (!$displayError)
                            echo 'hidden'; ?> custom-alert" role="alert" id="errorDiv">
                            <span class="close-button" id="closeButton">&times;</span>
                            <?php echo $errorMessage; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-10">
                            <!-- Custom Styles -->
                            <div class="card card-default">
                                <div class="card-body">
                                    <label for="text" style="margin-top: 20px;margin-bottom: 20px;">Please complete all
                                        details in CAPITAL
                                        letters. Please fill all names correctly. All
                                        communications shall be sent only to the First
                                        Named Account Holder's correspondence address</label>
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="date">Date :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light" id="Date"
                                                        name="Date">
                                                    <?php if (!empty($Date_err)): ?>
                                                        <span class="text-danger"><?php echo $Date_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="application">Application : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Application" placeholder="" name="Application">
                                                    <?php if (!empty($Application_err)): ?>
                                                        <span class="text-danger"><?php echo $Application_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="text">Please Tick whichever is</label>
                                                <div class="form-group">
                                                    <label for="bo_category">BO Category : </label>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckRegular" name="bo_category" value="Regular"
                                                            onclick="handleCheckboxSelection1('customCheckRegular')">
                                                        <label class="custom-control-label"
                                                            for="customCheckRegular">Regular</label>
                                                    </div>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckOmnibus" name="bo_category" value="Omnibus"
                                                            onclick="handleCheckboxSelection1('customCheckOmnibus')">
                                                        <label class="custom-control-label"
                                                            for="customCheckOmnibus">Omnibus</label>
                                                    </div>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckClearing" name="bo_category" value="Clearing"
                                                            onclick="handleCheckboxSelection1('customCheckClearing')">
                                                        <label class="custom-control-label"
                                                            for="customCheckClearing">Clearing</label>
                                                    </div>
                                                    <?php if (!empty($bo_category_err)): ?>
                                                        <span class="text-danger"><?php echo $bo_category_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <label for="bo_Type">BO Type : </label>
                                                <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckCompany" name="bo_type" value="Company"
                                                        onclick="handleCheckboxSelection('customCheckCompany')">
                                                    <label class="custom-control-label"
                                                        for="customCheckCompany">Company</label>
                                                </div>
                                                <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckIndividual" name="bo_type" value="Individual"
                                                        onclick="handleCheckboxSelection('customCheckIndividual')">
                                                    <label class="custom-control-label"
                                                        for="customCheckIndividual">Individual</label>
                                                </div>
                                                <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckJointHolder" name="bo_type" value="Joint Holder"
                                                        onclick="handleCheckboxSelection('customCheckJointHolder')">
                                                    <label class="custom-control-label"
                                                        for="customCheckJointHolder">Joint Holder</label>
                                                </div>
                                                <?php if (!empty($bo_type_err)): ?>
                                                    <span class="text-danger"><?php echo $bo_type_err; ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <script>
                                                function handleCheckboxSelection1(checkboxId) {
                                                    const checkboxes = [
                                                        'customCheckRegular',
                                                        'customCheckOmnibus',
                                                        'customCheckClearing'
                                                    ];
                                                    checkboxes.forEach((checkbox) => {
                                                        if (checkbox !== checkboxId) {
                                                            document.getElementById(checkbox).checked = false;
                                                        }
                                                    });
                                                }
                                            </script>
                                            <div class="col-sm-6">
                                                <div class="form-group">

                                                    <div class="form-group">
                                                        <label for="cdblParticipentName">Name of CDBL Participant :
                                                        </label>
                                                        <input type="text" class="form-control rounded-0 bg-light"
                                                            id="Name_of_CDBL_Participant"
                                                            placeholder="LankaBangla Securities Ltd."
                                                            name="Name_of_CDBL_Participant"
                                                            value="LankaBangla Securities Ltd." readonly>
                                                    </div>
                                                    <div class="form-group">

                                                        <fieldset disabled>
                                                            <label for="bo_id">BO ID : </label>
                                                            <input type="text" class="form-control rounded-0 bg-light"
                                                                id="BO_ID" placeholder="<?php echo $displayBOID; ?>">
                                                        </fieldset>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="CDBL_Participant_ID">CDBL Participant ID : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="CDBL_Participant_ID" placeholder="Enter CDBL Participant ID"
                                                        name="CDBL_Participant_ID">
                                                        
                                                    <?php if (!empty($CDBL_Participant_ID_err)): ?>
                                                        <span
                                                            class="text-danger"><?php echo $CDBL_Participant_ID_err; ?></span>
                                                    <?php elseif (empty($CDBL_Participant_ID_err)): ?>
                                                        <span
                                                            class="text">CDBL ID Should be 7digit</span>    
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="DateAccountOpened">Date Account Opened :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="Date_Account_Opened" name="Date_Account_Opened">
                                                    <?php if (!empty($Date_Account_Opened_err)): ?>
                                                        <span
                                                            class="text-danger"><?php echo $Date_Account_Opened_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <script>
                                                function handleCheckboxSelection(checkboxId) {
                                                    const checkboxes = [
                                                        'customCheckCompany',
                                                        'customCheckIndividual',
                                                        'customCheckJointHolder'
                                                    ];
                                                    checkboxes.forEach((checkbox) => {
                                                        if (checkbox !== checkboxId) {
                                                            document.getElementById(checkbox).checked = false;
                                                        }
                                                    });
                                                }
                                            </script>

                                        </div>

                                        <div class="form-footer pt-5 border-top">
                                            <button type="submit" class="btn btn-secondary btn-pill"
                                                id="submitRest">submit</button>

                                            <button type="submit" class="btn btn-light btn-pill">Cancel</button>

                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- 1. First Applicant -->
                            <div class="card card-default">
                                <div class="card-header" id="cardHeader3">
                                    <h2>First Applicant</h2>
                                </div>
                                <div class="card-body">
                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <label for="DepositoryAccount">I / WE request you to open a Depository
                                                    Account in my / our name
                                                    as per the following details : </label>
                                                <div class="form-group">
                                                    <label for="nameOfFullAccount">Name in Full of Account
                                                        Holder : Short Name of Account Holder (Insert full name starting
                                                        with Title i.e.
                                                        Mr./Mrs./Ms/Dr, abbreviate only if over
                                                        30 characters)</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="nameOfFullAccount2" name="nameOfFullAccount2"
                                                        placeholder="Enter Full of Account Name">
                                                     <?php if (!empty($nameOfFullAccount2_err)): ?>
                                                        <span class="text-danger"><?php echo $nameOfFullAccount2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="TitleOfAccount">Title i.e</label>
                                                    <label for="TitleOfAccount">Mr./Mrs./Ms : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="TitleOfAccount2" name="TitleOfAccount2"
                                                        placeholder="Enter Title i.e Mr./Mrs./Ms">
                                                        <?php if (!empty($TitleOfAccount2_err)): ?>
                                                        <span class="text-danger"><?php echo $TitleOfAccount2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="contactPersonName">Name of Contact Person (In case of a
                                                        Company/Firm/Statutory
                                                        Body) : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="contactPersonName2" name="contactPersonName2"
                                                        placeholder="Enter Name of Contact Person">
                                                        <?php if (!empty($contactPersonName2_err)): ?>
                                                        <span class="text-danger"><?php echo $contactPersonName2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="individualName">In Case of Individual : </label>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="maleCheckbox" name="individualGender2" value="Male"
                                                            onclick="handleGenderSelection('maleCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="maleCheckbox">Male</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="femaleCheckbox" name="individualGender2" value="Female"
                                                            onclick="handleGenderSelection('femaleCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="femaleCheckbox">Female</label>
                                                    </div>
                                                    <?php if (!empty($individualGender2_err)): ?>
                                                        <span class="text-danger"><?php echo $individualGender2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <script>
                                                function handleGenderSelection(selectedCheckbox) {
                                                    const maleCheckbox = document.getElementById('maleCheckbox');
                                                    const femaleCheckbox = document.getElementById('femaleCheckbox');
                                                    if (selectedCheckbox === 'maleCheckbox') {
                                                        femaleCheckbox.checked = false;
                                                    } else if (selectedCheckbox === 'femaleCheckbox') {
                                                        maleCheckbox.checked = false;
                                                    }
                                                }
                                            </script>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="occupation">Occupation : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="occupation2" name="occupation2"
                                                        placeholder="Enter Occupation">
                                                        <?php if (!empty($occupation2_err)): ?>
                                                        <span class="text-danger"><?php echo $occupation2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="nid_bo">NID : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="nid_bo2" name="nid_bo2" placeholder="Enter NID">
                                                        <?php if (!empty($nid_bo2_err)): ?>
                                                        <span class="text-danger"><?php echo $nid_bo2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="fatherHusbandName">Father's / Husband's Name : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="fatherHusbandName2" name="fatherHusbandName2"
                                                        placeholder="Enter Father's / Husband's Name">
                                                        <?php if (!empty($fatherHusbandName2_err)): ?>
                                                        <span class="text-danger"><?php echo $fatherHusbandName2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="motherName">Mother's Name : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="motherName2" name="motherName2"
                                                        placeholder="Enter Mother's Name">
                                                        <?php if (!empty($motherName2_err)): ?>
                                                        <span class="text-danger"><?php echo $motherName2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Contact Details</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Address">Address :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Address2" name="Address2" placeholder="Enter Address">
                                                        <?php if (!empty($Address2_err)): ?>
                                                        <span class="text-danger"><?php echo $Address2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="City">City :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="City2" name="City2" placeholder="Enter City">
                                                        <?php if (!empty($City2_err)): ?>
                                                        <span class="text-danger"><?php echo $City2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="PostCode">Post Code :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="PostCode2" name="PostCode2" placeholder="Enter Post Code">
                                                        <?php if (!empty($PostCode2_err)): ?>
                                                        <span class="text-danger"><?php echo $PostCode2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="State">State/Division :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="State2" name="State2" placeholder="Enter State/Division">
                                                        <?php if (!empty($State2_err)): ?>
                                                        <span class="text-danger"><?php echo $State2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Country">Country :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Country2" name="Country2" placeholder="Enter Country">
                                                        <?php if (!empty($Country2_err)): ?>
                                                        <span class="text-danger"><?php echo $Country2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Telephone">Telephone :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Telephone2" name="Telephone2" placeholder="Enter Telephone">
                                                        <?php if (!empty($Telephone2_err)): ?>
                                                        <span class="text-danger"><?php echo $Telephone2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="MobilePhone">Mobile Phone :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="MobilePhone2" name="MobilePhone2"
                                                        placeholder="Enter Mobile Phone">
                                                        <?php if (!empty($MobilePhone2_err)): ?>
                                                        <span class="text-danger"><?php echo $MobilePhone2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Fax">Fax :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light" id="Fax2"
                                                        name="Fax2" placeholder="Enter Fax">
                                                        <?php if (!empty($Fax2_err)): ?>
                                                        <span class="text-danger"><?php echo $Fax2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="email_id">E-mail :</label>
                                                    <input type="email" class="form-control rounded-0 bg-light"
                                                        id="email_id2" name="email_id2" placeholder="Enter Email">
                                                        <?php if (!empty($email_id2_err)): ?>
                                                        <span class="text-danger"><?php echo $email_id2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Passport Details</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="PassportNo">Passport No :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="PassportNo2" name="PassportNo2"
                                                        placeholder="Enter Passport No">
                                                        <?php if (!empty($PassportNo2_err)): ?>
                                                        <span class="text-danger"><?php echo $PassportNo2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="IssuePlace">Issue Place :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="IssuePlace2" name="IssuePlace2"
                                                        placeholder="Enter Issue Place">
                                                        <?php if (!empty($IssuePlace2_err)): ?>
                                                        <span class="text-danger"><?php echo $IssuePlace2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="IssueDate">Issue Date :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="IssueDate2" name="IssueDate2">
                                                        <?php if (!empty($IssueDate2_err)): ?>
                                                        <span class="text-danger"><?php echo $IssueDate2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="ExpiryDate">Expiry Date :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="ExpiryDate2" name="ExpiryDate2">
                                                        <?php if (!empty($ExpiryDate2_err)): ?>
                                                        <span class="text-danger"><?php echo $ExpiryDate2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Bank Details</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="BankName">Bank Name :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="BankName2" name="BankName2" placeholder="Enter Bank Name">
                                                        <?php if (!empty($BankName2_err)): ?>
                                                        <span class="text-danger"><?php echo $BankName2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="BranchName">Branch Name :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="BranchName2" name="BranchName2"
                                                        placeholder="Enter Branch Name">
                                                        <?php if (!empty($BranchName2_err)): ?>
                                                        <span class="text-danger"><?php echo $BranchName2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="AccountNo">Account No :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="AccountNo2" name="AccountNo2"
                                                        placeholder="Enter Account No">
                                                        <?php if (!empty($AccountNo2_err)): ?>
                                                        <span class="text-danger"><?php echo $AccountNo2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="RoutingNo">Routing No :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="RoutingNo2" name="RoutingNo2"
                                                        placeholder="Enter Routing No">
                                                        <?php if (!empty($RoutingNo2_err)): ?>
                                                        <span class="text-danger"><?php echo $RoutingNo2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="TinTaxID">Tin/TAX ID :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="TinTaxID2" name="TinTaxID2" placeholder="Enter Tin/TAX ID">
                                                        <?php if (!empty($TinTaxID2_err)): ?>
                                                        <span class="text-danger"><?php echo $TinTaxID2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="ElectronicDividendCredit">Electronic Dividend Credit
                                                        :</label>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="ElectronicDividendYes" name="ElectronicDividendCredit2"
                                                            value="yes"
                                                            onclick="toggleCheckbox('ElectronicDividendYes', 'ElectronicDividendNo')">
                                                        <label class="custom-control-label"
                                                            for="ElectronicDividendYes">Yes</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="ElectronicDividendNo" name="ElectronicDividendCredit2"
                                                            value="no"
                                                            onclick="toggleCheckbox('ElectronicDividendNo', 'ElectronicDividendYes')">
                                                        <label class="custom-control-label"
                                                            for="ElectronicDividendNo">No</label>
                                                    </div>
                                                    <?php if (!empty($ElectronicDividendCredit2_err)): ?>
                                                        <span class="text-danger"><?php echo $ElectronicDividendCredit2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="TaxExemption">Tax Exemption if any :</label>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="TaxExemptionYes" name="TaxExemption" value="yes"
                                                            onclick="toggleCheckbox('TaxExemptionYes', 'TaxExemptionNo')">
                                                        <label class="custom-control-label"
                                                            for="TaxExemptionYes">Yes</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="TaxExemptionNo" name="TaxExemption" value="no"
                                                            onclick="toggleCheckbox('TaxExemptionNo', 'TaxExemptionYes')">
                                                        <label class="custom-control-label"
                                                            for="TaxExemptionNo">No</label>
                                                    </div>
                                                    <?php if (!empty($TaxExemption_err)): ?>
                                                        <span class="text-danger"><?php echo $TaxExemption_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <script>
                                                function toggleCheckbox(checkboxId, otherCheckboxId) {
                                                    const checkbox = document.getElementById(checkboxId);
                                                    const otherCheckbox = document.getElementById(otherCheckboxId);
                                                    if (checkbox.checked) {
                                                        otherCheckbox.checked = false;
                                                    }
                                                }
                                            </script>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Others Information</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Residency :</label>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="resideCheckbox" name="residency" value="Reside"
                                                            onclick="toggleCheckbox('resideCheckbox', 'nonResideCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="resideCheckbox">Reside</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="nonResideCheckbox" name="residency" value="NonReside"
                                                            onclick="toggleCheckbox('nonResideCheckbox', 'resideCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="nonResideCheckbox">NonReside</label>
                                                    </div>
                                                    <?php if (!empty($residency_err)): ?>
                                                        <span class="text-danger"><?php echo $residency_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <script>
                                                function toggleCheckbox(checkboxId, otherCheckboxId) {
                                                    const checkbox = document.getElementById(checkboxId);
                                                    const otherCheckbox = document.getElementById(otherCheckboxId);
                                                    if (checkbox.checked) {
                                                        otherCheckbox.checked = false;
                                                    }
                                                }
                                            </script>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Statement Cycle Code :</label>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="dailyCheckbox" name="statementCycle" value="Daily"
                                                            onclick="toggleCheckbox('dailyCheckbox', 'weeklyCheckbox', 'fortnightlyCheckbox', 'monthlyCheckbox', 'otherCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="dailyCheckbox">Daily</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="weeklyCheckbox" name="statementCycle" value="Weekly"
                                                            onclick="toggleCheckbox('weeklyCheckbox', 'dailyCheckbox', 'fortnightlyCheckbox', 'monthlyCheckbox', 'otherCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="weeklyCheckbox">Weekly</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="fortnightlyCheckbox" name="statementCycle"
                                                            value="Fortnightly"
                                                            onclick="toggleCheckbox('fortnightlyCheckbox', 'dailyCheckbox', 'weeklyCheckbox', 'monthlyCheckbox', 'otherCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="fortnightlyCheckbox">Fortnightly</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="monthlyCheckbox" name="statementCycle" value="Monthly"
                                                            onclick="toggleCheckbox('monthlyCheckbox', 'dailyCheckbox', 'weeklyCheckbox', 'fortnightlyCheckbox', 'otherCheckbox')">
                                                        <label class="custom-control-label"
                                                            for="monthlyCheckbox">Monthly</label>
                                                    </div>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="otherCheckbox" name="statementCycle" value="Other"
                                                            onclick="handleOtherCheckbox()">
                                                        <label class="custom-control-label" for="otherCheckbox">Other
                                                            (Please Specify)</label>
                                                        <input type="text" class="form-control mt-2"
                                                            id="otherStatementCycle" name="otherStatementCycle"
                                                            disabled>
                                                    </div>
                                                    <?php if (!empty($statementCycle_err)): ?>
                                                        <span class="text-danger"><?php echo $statementCycle_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <script>
                                                function toggleCheckbox(checkboxId, ...otherCheckboxIds) {
                                                    const checkbox = document.getElementById(checkboxId);
                                                    if (checkbox.checked) {
                                                        otherCheckboxIds.forEach((id) => {
                                                            document.getElementById(id).checked = false;
                                                        });
                                                        document.getElementById('otherStatementCycle').disabled = true;
                                                    }
                                                }

                                                function handleOtherCheckbox() {
                                                    const otherCheckbox = document.getElementById('otherCheckbox');
                                                    if (otherCheckbox.checked) {
                                                        document.getElementById('dailyCheckbox').checked = false;
                                                        document.getElementById('weeklyCheckbox').checked = false;
                                                        document.getElementById('fortnightlyCheckbox').checked = false;
                                                        document.getElementById('monthlyCheckbox').checked = false;
                                                        document.getElementById('otherStatementCycle').disabled = false;
                                                    } else {
                                                        document.getElementById('otherStatementCycle').disabled = true;
                                                    }
                                                }
                                            </script>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Nationality">Nationality :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Nationality2" name="Nationality2"
                                                        placeholder="Enter Nationality">
                                                        <?php if (!empty($Nationality2_err)): ?>
                                                        <span class="text-danger"><?php echo $Nationality2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="DateOfBirth">Date of Birth :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="DateOfBirth3" name="DateOfBirth3">
                                                        <?php if (!empty($DateOfBirth3_err)): ?>
                                                        <span class="text-danger"><?php echo $DateOfBirth3_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="InternalRefNo">Internal Ref. No (To be filled in by CDBL
                                                        Partic) :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="InternalRefNo3" name="InternalRefNo3"
                                                        placeholder="Enter Internal Ref. No">
                                                        <?php if (!empty($InternalRefNo3_err)): ?>
                                                        <span class="text-danger"><?php echo $InternalRefNo3_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="DateOfRegistration">Date of Registration :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="DateOfRegistration3" name="DateOfRegistration3">
                                                        <?php if (!empty($DateOfRegistration3_err)): ?>
                                                        <span class="text-danger"><?php echo $DateOfRegistration3_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="InCaseOfCompany">In case of Company :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="InCaseOfCompany3" name="InCaseOfCompany3"
                                                        placeholder="Enter Company Details">
                                                        <?php if (!empty($InCaseOfCompany3_err)): ?>
                                                        <span class="text-danger"><?php echo $InCaseOfCompany3_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="RegistrationNo">Registration No :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="RegistrationNo3" name="RegistrationNo3"
                                                        placeholder="Enter Registration No">
                                                        <?php if (!empty($RegistrationNo3_err)): ?>
                                                        <span class="text-danger"><?php echo $RegistrationNo3_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Joint Applicant (Second Account Holder)</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="nameOfJointAccount">Name in Full of Account
                                                        Holder : Short Name of Account Holder (Insert full name starting
                                                        with Title i.e.
                                                        Mr./Mrs./Ms/Dr, abbreviate only if over
                                                        30 characters)</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="nameOfJointAccount2" name="nameOfJointAccount2"
                                                        placeholder="Enter Full of Account Name">
                                                        <?php if (!empty($nameOfJointAccount2_err)): ?>
                                                        <span class="text-danger"><?php echo $nameOfJointAccount2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="jointTitleOfAccount">Title i.e</label>
                                                    <label for="jointTitleOfAccount">Mr./Mrs./Ms : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="jointTitleOfAccount2" name="jointTitleOfAccount2"
                                                        placeholder="Enter Title i.e Mr./Mrs./Ms">
                                                        <?php if (!empty($jointTitleOfAccount2_err)): ?>
                                                        <span class="text-danger"><?php echo $jointTitleOfAccount2_err; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>

                                            <div class="col-sm-12">

                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Would you like to create a link to your existing Depository
                                                        Account:</label>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckYes1" name="customCheck4" value="Yes">
                                                        <label class="custom-control-label"
                                                            for="customCheckYes1">Yes</label>
                                                    </div>

                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckNo1" name="customCheck4" value="No">
                                                        <label class="custom-control-label"
                                                            for="customCheckNo1">No</label>
                                                    </div>
                                                    <?php if (!empty($customCheck4_err)): ?>
                                                        <span class="text-danger"><?php echo $customCheck4_err; ?></span>
                                                    <?php endif; ?>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="depositoryAccountCode1" name="depositoryAccountCode1"
                                                        placeholder="Enter Depository BO Account Code"
                                                        style="display: none;">

                                                </div>
                                            </div>

                                            <script>
                                                const customCheckYes1 = document.getElementById("customCheckYes1");
                                                const customCheckNo1 = document.getElementById("customCheckNo1");
                                                const inputText = document.getElementById("depositoryAccountCode1");
                                                customCheckYes1.addEventListener("change", function() {
                                                    if (customCheckYes1.checked) {
                                                        customCheckNo1.checked = false;
                                                        inputText.style.display = "block";
                                                        inputText.disabled = false;
                                                    } else {
                                                        inputText.style.display = "none";
                                                        inputText.disabled = true;
                                                    }
                                                });
                                                customCheckNo1.addEventListener("change", function() {
                                                    if (customCheckNo1.checked) {
                                                        customCheckYes1.checked = false;
                                                        inputText.style.display = "none";
                                                        inputText.disabled = true;
                                                    }
                                                });
                                            </script>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Nominees/Heirs</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <label>
                                                If account holder (s) wish to give a Power of Attorney (POA) to someone
                                                to operate the account,
                                                a separate Form-20 must be filled up and
                                                signed by all account holders giving the name, contact details etc. of
                                                the POA holder and a POA
                                                document lodged with the form.
                                                If account holder(s) wish to continue nominate person(s) who will be
                                                entitled to receive
                                                securities outstanding in the account in the event
                                                of the death of the sole account holder/all the joint account holders, a
                                                separate nomination
                                                Form-23 must be filled up and signed by all
                                                account holders and the nominees giving names of nominees, relationship
                                                with first account
                                                holder, percentage distribution and contact
                                                details, if any nominee is a minor, gurdian’s name, address,
                                                relationship with nominees has also
                                                to be provided</label>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Power of Attorney (POA)</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <label>
                                                If account holder (s) wish to give a Power of Attorney (POA) to someone
                                                to operate the account,
                                                a separate Form-20 must be filled up and
                                                signed by all account holders giving the name, contact details etc. of
                                                the POA holder and a POA
                                                document lodged with the form.</label>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>To be filled in by the Stock Broker/Stock Exchange in case the
                                                    application is for opening a
                                                    Cle</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Would you like to create a link to your existing Depository
                                                        Account:</label>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckDSE" name="customCheckExchange" value="DSE">
                                                        <label class="custom-control-label"
                                                            for="customCheckDSE">DSE</label>
                                                    </div>

                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="customCheckCSE" name="customCheckExchange" value="CSE">
                                                        <label class="custom-control-label"
                                                            for="customCheckCSE">CSE</label>
                                                    </div>
                                                    <?php if (!empty($customCheckExchange_err)): ?>
                                                        <span class="text-danger"><?php echo $customCheckExchange_err; ?></span>
                                                    <?php endif; ?>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="depositoryAccountCodeDSE" name="depositoryAccountCodeDSE"
                                                        placeholder="Enter DSE Trading Id" style="display: none;"
                                                        >
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="depositoryAccountCodeCSE" name="depositoryAccountCodeCSE"
                                                        placeholder="Enter CSE Trading Id" style="display: none;"
                                                        >
                                                </div>
                                            </div>

                                            <script>
                                                const customCheckDSE = document.getElementById("customCheckDSE");
                                                const customCheckCSE = document.getElementById("customCheckCSE");
                                                const inputTextDSE = document.getElementById(
                                                "depositoryAccountCodeDSE");
                                                const inputTextCSE = document.getElementById(
                                                "depositoryAccountCodeCSE");
                                                customCheckDSE.addEventListener("change", function() {
                                                    if (customCheckDSE.checked) {
                                                        customCheckCSE.checked = false;
                                                        inputTextDSE.style.display = "block";
                                                        inputTextCSE.style.display = "none";
                                                        inputTextDSE.disabled = false;
                                                        inputTextCSE.disabled = true;
                                                    } else {
                                                        inputTextDSE.style.display = "none";
                                                        inputTextDSE.disabled = true;
                                                    }
                                                });
                                                customCheckCSE.addEventListener("change", function() {
                                                    if (customCheckCSE.checked) {
                                                        customCheckDSE.checked = false;
                                                        inputTextCSE.style.display = "block";
                                                        inputTextDSE.style.display = "none";
                                                        inputTextCSE.disabled = false;
                                                        inputTextDSE.disabled = true;
                                                    } else {
                                                        inputTextCSE.style.display = "none";
                                                        inputTextCSE.disabled = true;
                                                    }
                                                });
                                            </script>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Photograph</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-120">
                                                <div class="form-group">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">1st Applicant Signatory in case of Ltd.
                                                                    Co.</th>
                                                                <th scope="col">2nd Applicant Signatory in case of Ltd.
                                                                    Co.</th>
                                                                <th scope="col">Authorized Signatory in case of Ltd. Co
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <span id="selectedFileName1"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                        </div>
                                                                        <div
                                                                            style="text-align: center; margin-top: 20px;">
                                                                            <img id="previewImage1" src="#"
                                                                                alt="Selected Image"
                                                                                style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <span id="selectedFileName2"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                        </div>
                                                                        <div
                                                                            style="text-align: center; margin-top: 20px;">
                                                                            <img id="previewImage2" src="#"
                                                                                alt="Selected Image"
                                                                                style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <span id="selectedFileName3"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                        </div>
                                                                        <div
                                                                            style="text-align: center; margin-top: 20px;">
                                                                            <img id="previewImage3" src="#"
                                                                                alt="Selected Image"
                                                                                style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <input type="file" id="imageInput1"
                                                                                accept="image/*"
                                                                                style="display: none;" />
                                                                            <label for="imageInput1"
                                                                                style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                                                                Image</label>
                                                                            <span id="selectedFileName1"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                            <button id="clearImageBtn1"
                                                                                style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                                                                Image</button>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <input type="file" id="imageInput2"
                                                                                accept="image/*"
                                                                                style="display: none;" />
                                                                            <label for="imageInput2"
                                                                                style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                                                                Image</label>
                                                                            <span id="selectedFileName2"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                            <button id="clearImageBtn2"
                                                                                style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                                                                Image</button>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                                                        <div
                                                                            style="position: relative; display: inline-block;">
                                                                            <input type="file" id="imageInput3"
                                                                                accept="image/*"
                                                                                style="display: none;" />
                                                                            <label for="imageInput3"
                                                                                style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                                                                Image</label>
                                                                            <span id="selectedFileName3"
                                                                                style="display: none;">No file
                                                                                selected</span>
                                                                            <button id="clearImageBtn3"
                                                                                style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                                                                Image</button>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <script>
                                                        // Function to handle the image input change and display the preview image
                                                        function handleImageInputChange(inputId, previewId,
                                                        fileNameId) {
                                                            const input = document.getElementById(inputId);
                                                            const previewImage = document.getElementById(previewId);
                                                            input.addEventListener('change', function(event) {
                                                                const file = event.target.files[0];
                                                                const reader = new FileReader();
                                                                reader.onload = function() {
                                                                    previewImage.src = reader.result;
                                                                    document.getElementById(
                                                                            'clearImageBtn' +
                                                                            inputId.slice(-1)).style
                                                                        .display =
                                                                        'block';
                                                                };
                                                                if (file) {
                                                                    reader.readAsDataURL(file);
                                                                }
                                                            });
                                                            // Function to handle the "Clear Image" button
                                                            document.getElementById('clearImageBtn' + inputId.slice(-1))
                                                                .addEventListener('click',
                                                                    function(event) {
                                                                        event
                                                                            .preventDefault(); // Prevent the default form submission behavior
                                                                        previewImage.src = '#';
                                                                        input.value = '';
                                                                        document.getElementById('clearImageBtn' +
                                                                            inputId
                                                                            .slice(-1)).style.display = 'none';
                                                                    });
                                                        }
                                                        // Call the function for each input element and preview image
                                                        handleImageInputChange('imageInput1', 'previewImage1',
                                                            'selectedFileName1');
                                                        handleImageInputChange('imageInput2', 'previewImage2',
                                                            'selectedFileName2');
                                                        handleImageInputChange('imageInput3', 'previewImage3',
                                                            'selectedFileName3');
                                                    </script>

                                                </div>
                                            </div>

                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Standing Instructions</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-group">
                                                <label for="standingInstructions" style="margin-right: 20px;">I/We
                                                    authorize you to receive
                                                    facsimile (fax) transfer instruction for delivery : </label>
                                                <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckYes4" name="customCheck5" value="Male">
                                                    <label class="custom-control-label"
                                                        for="customCheckYes4">Yes</label>
                                                </div>

                                                <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckNo4" name="customCheck5" value="No">
                                                    <label class="custom-control-label" for="customCheckNo4">No</label>
                                                </div>
                                                <?php if (!empty($customCheck5_err)): ?>
                                                        <span class="text-danger"><?php echo $customCheck5_err; ?></span>
                                                    <?php endif; ?>
                                            </div>
                                            <script>
                                                const customCheckYes4 = document.getElementById("customCheckYes4");
                                                const customCheckNo4 = document.getElementById("customCheckNo4");
                                                customCheckYes4.addEventListener("change", function() {
                                                    if (customCheckYes4.checked) {
                                                        customCheckNo4.checked = false;
                                                    }
                                                });
                                                customCheckNo4.addEventListener("change", function() {
                                                    if (customCheckNo4.checked) {
                                                        customCheckYes4.checked = false;
                                                    }
                                                });
                                            </script>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>DECLARATION</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-group">
                                                <label for="DECLARATION" style="margin-right: 20px;">The rules and
                                                    regulations of the Depository
                                                    and CDBL participant pertaining to an account which are in force now
                                                    have been read by
                                                    me/us and I/we have understood the same and I/we agree to abide by
                                                    and to be bound by the
                                                    rules as are in force from time to time for
                                                    such account. I/We also declare that the particulars given by me/us
                                                    are true to the best of
                                                    my/our knowledge as on the date of making such
                                                    application. I/We further agree that any false/misleading
                                                    information given by me/us or
                                                    suppression of any material fact will render my/our
                                                    account liable for termination and further action</label>

                                            </div>
                                            <div class="col-sm-120">

                                                <div class="form-group">
                                                    <label for="Declaration"></label>

                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Applicant</th>
                                                                <th scope="col">Name of applicant
                                                                    /Authorized signatories in case of ltd</th>
                                                                <th scope="col">Signature</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>First Account Holder</td>
                                                                <td>
                                                                    <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="firstAccName1" placeholder=""
                                                                        name="firstAccName1">
                                                                        <?php if (!empty($firstAccName1_err)): ?>
                                                        <span class="text-danger"><?php echo $firstAccName1_err; ?></span>
                                                    <?php endif; ?>
                                                                </td>
                                                                <td> <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="signaturFirst1" placeholder=""
                                                                        name="signaturFirst1"><input type="file"
                                                                        class="form-control-file"
                                                                        id="exampleFormControlFile1"></td>
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <td>Second Account Holder</td>
                                                                <td>
                                                                    <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="secondAccName2" placeholder=""
                                                                        name="secondAccName2">
                                                                        <?php if (!empty($secondAccName2_err)): ?>
                                                        <span class="text-danger"><?php echo $secondAccName2_err; ?></span>
                                                    <?php endif; ?>
                                                                </td>
                                                                <td> <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="signaturSecond2" placeholder=""
                                                                        name="signaturSecond2"><input type="file"
                                                                        class="form-control-file"
                                                                        id="exampleFormControlFile1">
                                                                </td>

                                                            </tr>
                                                            <tr>
                                                                <td>3rd Signatory ( Ltd Co. Only)</td>
                                                                <td>
                                                                    <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="thirdAccName3" placeholder=""
                                                                        name="thirdAccName3">
                                                                        <?php if (!empty($thirdAccName3_err)): ?>
                                                        <span class="text-danger"><?php echo $thirdAccName3_err; ?></span>
                                                    <?php endif; ?> 
                                                                </td>
                                                                <td> <input type="text"
                                                                        class="form-control rounded-0 bg-light"
                                                                        id="signaturThird3" placeholder=""
                                                                        name="signaturThird3">
                                                                    <input type="file" class="form-control-file"
                                                                        id="exampleFormControlFile1">
                                                                </td>
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>

                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Special Instructions on operation of Joint Account : </h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-group">
                                                <div class="custom-control custom-checkbox d-inline-block mr-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckEitherOrSurvivor" name="customCheckInstructions"
                                                        value="EitherOrSurvivor">
                                                    <label class="custom-control-label"
                                                        for="customCheckEitherOrSurvivor">Either or
                                                        Survivor</label>
                                                </div>

                                                <div class="custom-control custom-checkbox d-inline-block mr-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckAnyOneCanOperate" name="customCheckInstructions"
                                                        value="AnyOneCanOperate">
                                                    <label class="custom-control-label"
                                                        for="customCheckAnyOneCanOperate">Any one can
                                                        operate</label>
                                                </div>

                                                <div class="custom-control custom-checkbox d-inline-block mr-3">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckAnyTwoWithOne" name="customCheckInstructions"
                                                        value="AnyTwoWithOne">
                                                    <label class="custom-control-label"
                                                        for="customCheckAnyTwoWithOne">Any two will operate
                                                        jointly with any one of the others</label>
                                                </div>

                                                <div class="custom-control custom-checkbox d-inline-block">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customCheckOperatedBy" name="customCheckInstructions"
                                                        value="OperatedBy">
                                                    <label class="custom-control-label"
                                                        for="customCheckOperatedBy">Account will be operated
                                                        by</label>
                                                </div>
                                                <?php if (!empty($customCheckInstructions_err)): ?>
                                                        <span class="text-danger"><?php echo $customCheckInstructions_err; ?></span>
                                                    <?php endif; ?> 
                                            </div>
                                            <script>
                                                const customCheckEitherOrSurvivor = document.getElementById(
                                                    "customCheckEitherOrSurvivor");
                                                const customCheckAnyOneCanOperate = document.getElementById(
                                                    "customCheckAnyOneCanOperate");
                                                const customCheckAnyTwoWithOne = document.getElementById(
                                                    "customCheckAnyTwoWithOne");
                                                const customCheckOperatedBy = document.getElementById(
                                                    "customCheckOperatedBy");
                                                customCheckEitherOrSurvivor.addEventListener("change", function() {
                                                    if (customCheckEitherOrSurvivor.checked) {
                                                        customCheckAnyOneCanOperate.checked = false;
                                                        customCheckAnyTwoWithOne.checked = false;
                                                        customCheckOperatedBy.checked = false;
                                                    }
                                                });
                                                customCheckAnyOneCanOperate.addEventListener("change", function() {
                                                    if (customCheckAnyOneCanOperate.checked) {
                                                        customCheckEitherOrSurvivor.checked = false;
                                                        customCheckAnyTwoWithOne.checked = false;
                                                        customCheckOperatedBy.checked = false;
                                                    }
                                                });
                                                customCheckAnyTwoWithOne.addEventListener("change", function() {
                                                    if (customCheckAnyTwoWithOne.checked) {
                                                        customCheckEitherOrSurvivor.checked = false;
                                                        customCheckAnyOneCanOperate.checked = false;
                                                        customCheckOperatedBy.checked = false;
                                                    }
                                                });
                                                customCheckOperatedBy.addEventListener("change", function() {
                                                    if (customCheckOperatedBy.checked) {
                                                        customCheckEitherOrSurvivor.checked = false;
                                                        customCheckAnyOneCanOperate.checked = false;
                                                        customCheckAnyTwoWithOne.checked = false;
                                                    }
                                                });
                                            </script>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                                <h2>Introduction</h2>
                                            </div>
                                            <div class="col-sm-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Introduction">Introduction by an existing account holder
                                                        of LankaBangla Securities
                                                        Ltd.
                                                        I confirm the identity, occupation and address of the
                                                        applicant(s)</label>
                                                </div>
                                                <div class="form-group">
                                                    <label for="(SignatureIntroducer)">Signature Of Introducer</label>
                                                    <input style="margin-bottom: 20px;" type="text"
                                                        class="form-control rounded-0 bg-light"
                                                        id="SignatureIntroducer1" name="SignatureIntroducer1">
                                                    <input type="file" class="form-control-file"
                                                        id="SignatureIntroducerFile">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="(IntroducerName)">Introducer Name : </label>
                                                    <input style="margin-bottom: 20px;" type="text"
                                                        class="form-control rounded-0 bg-light" id="IntroducerName1"
                                                        name="IntroducerName1">
                                                        <?php if (!empty($IntroducerName1_err)): ?>
                                                        <span class="text-danger"><?php echo $IntroducerName1_err; ?></span>
                                                    <?php endif; ?> 
                                                </div>
                                                <div class="form-group">
                                                    <label for="(IntroducerName)">Account ID : </label>
                                                    <input style="margin-bottom: 20px;" type="text"
                                                        class="form-control rounded-0 bg-light" id="AccountID1"
                                                        name="AccountID1">
                                                        <?php if (!empty($AccountID1_err)): ?>
                                                        <span class="text-danger"><?php echo $AccountID1_err; ?></span>
                                                    <?php endif; ?> 
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-footer pt-5 border-top">
                                            <button type="submit" class="btn btn-secondary btn-pill"
                                                id="submitFirstApplicant">submit</button>

                                            <button type="submit" class="btn btn-light btn-pill">Cancel</button>

                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>

    </div>

    </div>

    <!-- Footer -->
    <footer class="footer mt-auto">
        <div class="copyright bg-white">
            <p>
                Noushin Nurjahan
            </p>
        </div>
        <script>
            var d = new Date();
            var year = d.getFullYear();
            document.getElementById("copy-year").innerHTML = year;
        </script>
    </footer>

    </div>
    </div>

    <!-- Card Offcanvas -->
    <div class="card card-offcanvas" id="contact-off">
        <div class="card-header">
            <h2>SideBar ItemRight</h2>
            <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
        </div>
        <div class="card-body">

            <div class="mb-4">
                <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
                    placeholder="Search Item...">
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

        </div>
    </div>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/simplebar/simplebar.min.js"></script>
    <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

    <script src="plugins/prism/prism.js"></script>

    <script src="js/mono.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/map.js"></script>
    <script src="js/custom.js"></script>

    <!--  -->

</body>

</html>