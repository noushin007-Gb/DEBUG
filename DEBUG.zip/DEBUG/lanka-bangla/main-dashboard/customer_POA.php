<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
  header("location: customer_POA.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Fill Customer Info</title>
    <meta name="theme-name" content="mono" />
    <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
    <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
    <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
    <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
    <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
    <link id="main-css-href" rel="stylesheet" href="css/style.css" />
    <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
    <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css"
        type="text/css" />
    <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
        type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
    <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
    <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>

    <style>
        .arrow-button {
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .rotate {
            transform: rotate(180deg);
        }
    </style>

    <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
    <script>
        NProgress.configure({
            showSpinner: false
        });
        NProgress.start();
    </script>
    <div id="toaster"></div>
    <div class="wrapper">
        <aside class="left-sidebar sidebar-light" id="left-sidebar">
            <div id="sidebar" class="sidebar sidebar-with-footer">
                <!-- Aplication Brand -->
                <div class="app-brand">
                    <a href="#">
                        <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
                    </a>
                </div>
                <!-- begin sidebar scrollbar -->
                <div class="sidebar-left" data-simplebar style="height: 100%;">
                    <!-- sidebar menu -->
                    <ul class="nav sidebar-inner" id="sidebar-menu">
                        <li>
                            <a class="sidenav-item-link" href="index.php">
                                <i class="mdi mdi-briefcase-account-outline"></i>
                                <span class="nav-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="section-title">
                            Forms
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_opening_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">ACCOUNT INFORMATION</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">CREDIT FACILITY</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_BO_account_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">BO ACC. OPENING</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">BO ACC. NOMINATION</span>
                            </a>
                        </li>
                        <li class="active">
                            <a class="sidenav-item-link" href="customer_POA.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Power of Attorney (POA)</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="customer_application_for_terms_and_conditions_by_laws.php">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Terms & Conditions</span>
                            </a>
                        </li>

                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">EFT Enrollment</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Signature Card</span>
                            </a>
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="">
                                <i class="mdi mdi-account-edit"></i>
                                <span class="nav-text">Value Added Service</span>
                            </a>
                        </li>
                        <li class="section-title">
                            Pages
                        </li>

                        <li class="has-sub">
                            <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                                <i class="mdi mdi-account"></i>
                                <span class="nav-text">Authentication</span> <b class="caret"></b>
                            </a>
                            <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                                <div class="sub-menu">
                                    <li>
                                        <a class="sidenav-item-link" href="sign-in.html">
                                            <span class="nav-text">Sign In</span>

                                        </a>
                                    </li>

                                </div>
                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                                data-target="#other-page" aria-expanded="false" aria-controls="other-page">
                                <i class="mdi mdi-file-multiple"></i>
                                <span class="nav-text">Other pages</span> <b class="caret"></b>
                            </a>
                            <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                                <div class="sub-menu">
                                    <li>
                                        <a class="sidenav-item-link" href="#">
                                            <span class="nav-text">Nothing</span>

                                        </a>
                                    </li>

                                </div>
                            </ul>
                        </li>
                        <li class="section-title">
                            Documentation
                        </li>
                        <li>
                            <a class="sidenav-item-link" href="#">
                                <i class="mdi mdi-airplane"></i>
                                <span class="nav-text">Nothing</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-footer">
                    <div class="sidebar-footer-content">
                        <ul class="d-flex">
                            <li>
                                <a href="#" data-toggle="tooltip" title="Profile settings"><i
                                        class="mdi mdi-settings"></i></a>
                            </li>
                            <li>
                                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip"
                                    title="Logout"><i class="mdi mdi-logout"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </aside>
        <div class="page-wrapper">

            <!-- Header -->
            <header class="main-header" id="header">
                <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
                    <!-- Sidebar toggle button -->
                    <button id="sidebar-toggler" class="sidebar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                    </button>

                    <span class="page-title">Customer Dashboard</span>

                    <div class="navbar-right ">

                        <!-- search form -->
                        <div class="search-form">
                            <form action="index.php" method="get">
                                <div class="input-group input-group-sm" id="input-group-search">
                                    <input type="text" autocomplete="off" name="query" id="search-input"
                                        class="form-control" placeholder="Search..." />
                                    <div class="input-group-append">
                                        <button class="btn" type="button">/</button>
                                    </div>
                                </div>
                            </form>
                            <ul class="dropdown-menu dropdown-menu-search">

                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"></a>
                                </li>

                            </ul>

                        </div>

                        <ul class="nav navbar-nav">
                            <!-- Offcanvas -->
                            <li class="custom-dropdown">
                                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                                    href="javascript:">
                                    <i class="mdi mdi-contacts icon"></i>
                                </a>
                            </li>
                            <li class="custom-dropdown">
                                <button class="notify-toggler custom-dropdown-toggler">
                                    <i class="mdi mdi-bell-outline icon"></i>
                                    <span class="badge badge-xs rounded-circle">21</span>
                                </button>
                                <div class="dropdown-notify">

                                    <header>
                                        <div class="nav nav-underline" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab"
                                                href="#all" role="tab" aria-controls="nav-home" aria-selected="true">All
                                                (5)</a>
                                            <a class="nav-item nav-link" id="message-tab" data-toggle="tab"
                                                href="#message" role="tab" aria-controls="nav-profile"
                                                aria-selected="false">Msgs (4)</a>
                                            <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other"
                                                role="tab" aria-controls="nav-contact" aria-selected="false">Others
                                                (3)</a>
                                        </div>
                                    </header>

                                    <footer class="border-top dropdown-notify-footer">
                                        <div class="d-flex justify-content-between align-items-center py-2 px-4">
                                            <span>Last updated 3 min ago</span>
                                            <a id="refress-button" href="javascript:"
                                                class="btn mdi mdi-cached btn-refress"></a>
                                        </div>
                                    </footer>
                                </div>
                            </li>
                            <!-- User Account -->
                            <li class="dropdown user-menu">
                                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                                    <img src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                                        class="user-image rounded-circle" alt="User Image" />
                                    <span class="d-none d-lg-inline-block"><b>
                                            <?php echo htmlspecialchars($_SESSION["username"]); ?></i>
                                        </b>
                                        <b>
                                            <?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?>
                                        </b></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">

                                    <li>
                                        <a class="dropdown-link-item" href="#">
                                            <i class="mdi mdi-settings"></i>
                                            <span class="nav-text">Account Setting</span>
                                        </a>
                                    </li>

                                    <li class="dropdown-footer">
                                        <a class="dropdown-link-item"
                                            href="/debug/lanka-bangla/main-login/client_logout.php"> <i
                                                class="mdi mdi-logout"></i> Log Out </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>

            </header>

            <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
            <div class="content-wrapper">
                <div class="content">
                    <!-- For Components documentaion -->

                    <div class="px-6 py-4">
                        <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
                        <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023,
                                Chittagong
                                Stock Exchange </span> </p>
                        <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">Power of
                                Attorney (POA) </span> </p>
                    </div>

                    <div class="row">
                        <div class="col-sm-10">
                            <!-- Custom Styles -->
                            <div class="card card-default">
                                <div class="card-body">
                                    <label for="text" style="margin-top: 20px;margin-bottom: 20px;">Please complete all
                                        details in CAPITAL
                                        letters.
                                        Please fill all names correctly. All communications shall be sent to
                                        thecorrespondence
                                        address of only the First Named Account Holder
                                        as specified in BO Account Opening Form 02.</label>
                                    <form>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="application">Application : </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="application1" placeholder="" name="application1">
                                                </div>
                                                <div class="form-group">
                                                    <label for="date">Date :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="date1" name="date1">
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                </div>
                                            </div>
                                            <!-- <div class="col-sm-8">
                        <label for="text">Please Tick whichever is</label>
                        <div class="form-group">
                          <label for="boCatagory">BO Category : </label>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckRegular"
                              name="customCheckRegular" value="Regular"
                              onclick="handleCheckboxSelection('customCheckRegular')">
                            <label class="custom-control-label" for="customCheckRegular">Regular</label>
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckOmnibus"
                              name="customCheckOmnibus" value="Omnibus"
                              onclick="handleCheckboxSelection('customCheckOmnibus')">
                            <label class="custom-control-label" for="customCheckOmnibus">Omnibus</label>
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckClearing"
                              name="customCheckClearing" value="Clearing"
                              onclick="handleCheckboxSelection('customCheckClearing')">
                            <label class="custom-control-label" for="customCheckClearing">Clearing</label>
                          </div>
                        </div>
                      </div> -->
                                            <!-- <script>
                        function handleCheckboxSelection(checkboxId) {
                          const checkboxes = [
                            'customCheckRegular',
                            'customCheckOmnibus',
                            'customCheckClearing'
                          ];
                          checkboxes.forEach((checkbox) => {
                            if (checkbox !== checkboxId) {
                              document.getElementById(checkbox).checked = false;
                            }
                          });
                        }
                      </script> -->
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <!-- <label for="boType">BO Type : </label>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckCompany"
                              name="customCheckCompany" value="Company"
                              onclick="handleCheckboxSelection('customCheckCompany')">
                            <label class="custom-control-label" for="customCheckCompany">Company</label>
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckIndividual"
                              name="customCheckIndividual" value="Individual"
                              onclick="handleCheckboxSelection('customCheckIndividual')">
                            <label class="custom-control-label" for="customCheckIndividual">Individual</label>
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                            <input type="checkbox" class="custom-control-input" id="customCheckJointHolder"
                              name="customCheckJointHolder" value="Joint Holder"
                              onclick="handleCheckboxSelection('customCheckJointHolder')">
                            <label class="custom-control-label" for="customCheckJointHolder">Joint Holder</label>
                          </div> -->
                                                    <div class="form-group">
                                                        <fieldset disabled><label for="cdblParticipentName">Name of CDBL
                                                                Participant : </label>
                                                            <input type="text" class="form-control rounded-0 bg-light"
                                                                id="cdblParticipentName"
                                                                placeholder="LankaBangla Securities Ltd."
                                                                name="cdblParticipentName"
                                                                value="LankaBangla Securities Ltd.">
                                                        </fieldset>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="CDBL_Participant_ID">CDBL Participant ID : </label>
                                                        <input type="text" class="form-control rounded-0 bg-light"
                                                            id="CDBL_Participant_ID"
                                                            placeholder="Enter CDBL Participant ID"
                                                            name="CDBL_Participant_ID">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="bo_id">BO ID : </label>
                                                        <input type="text" class="form-control rounded-0 bg-light"
                                                            id="bo_id" placeholder="Enter BO ID" name="bo_id">
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Name of Account Holder">Name of Account Holder (Insert
                                                        full name starting with
                                                        Title
                                                        i.e. Mr./Mrs./Ms/Dr, abbreviate only if over 30 characters)" :
                                                    </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Name_of_Account_Holder"
                                                        placeholder="Enter Name of Account Holder"
                                                        name="Name_of_Account_Holder">
                                                </div>
                                                <label for="text" style="margin-top: 20px;margin-bottom: 20px;">Power of
                                                    Attorney Holder's
                                                    Details</label>
                                                <div class="form-group">
                                                    <label for="Full Name:">Full Name:</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Full Name1" name="Full Name1">
                                                </div>
                                                <div class="form-group">
                                                    <label for="Short Name of Power of Attorney Holder">Short Name of
                                                        Power of Attorney Holder
                                                        (Insert full name starting with Title i.e. Mr./Mrs./Ms/Dr,
                                                        abbreviate only
                                                        if over 30 Characters)</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Short_Name_of_Power_of_Attorney_Holder1" placeholder=" "
                                                        name="Short_Name_of_Power_of_Attorney_Holder1">
                                                </div>

                                                <div class="form-group">
                                                    <label for="Title">Title i.e.
                                                        Mr/Mrs </label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Title1" placeholder="" name="Title1">
                                                </div>

                                            </div>

                                        </div>
                                        <!-- 
                    <script>
                      function handleCheckboxSelection(checkboxId) {
                        const checkboxes = [
                          'customCheckCompany',
                          'customCheckIndividual',
                          'customCheckJointHolder'
                        ];
                        checkboxes.forEach((checkbox) => {
                          if (checkbox !== checkboxId) {
                            document.getElementById(checkbox).checked = false;
                          }
                        });
                      }
                    </script> -->

                                </div>
                                <div class="form-footer pt-5 border-top">
                                </div>

                            </div>
                        </div>
                        <!-- 1. POA-->
                        <div class="card card-default">
                            <div class="card-header" id="cardHeader3">
                                <h2>1. Power of Attorney Holder's Contact Details</h2>
                            </div>
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-sm-12">
                                    </div>
                                    <div class="col-sm-6">

                                    </div>
                                    <div class="col-sm-6">

                                    </div>

                                    </script>

                                    <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">

                                    </div>
                                    <div class="col-sm-12">

                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="Address">Address :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="Address1"
                                                name="Address1" placeholder="Enter Address">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="City">City :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="City"
                                                name="City" placeholder="Enter City">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="PostCode">Post Code :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="PostCode1"
                                                name="PostCode1" placeholder="Enter Post Code">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="State">State/Division :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="State1"
                                                name="State1" placeholder="Enter State/Division">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="Country">Country :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="Country1"
                                                name="Country1" placeholder="Enter Country">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="Telephone">Telephone :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="Telephone1"
                                                name="Telephone1" placeholder="Enter Telephone">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="MobilePhone">Mobile Phone :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="MobilePhone1"
                                                name="MobilePhone1" placeholder="Enter Mobile Phone">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="Fax">Fax :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="Fax1"
                                                name="Fax1" placeholder="Enter Fax">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="email_id">E-mail :</label>
                                            <input type="email" class="form-control rounded-0 bg-light" id="email_id1"
                                                name="email_id1" placeholder="Enter Email">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">

                                    </div>
                                    <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                        <h2>2. Power of Attorney Holder's Passport Details</h2>
                                    </div>
                                    <div class="col-sm-12">

                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="PassportNo">Passport No :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="PassportNo1"
                                                name="PassportNo1" placeholder="Enter Passport No">
                                        </div>
                                        <div class="form-group">
                                            <label for="IssuePlace">Issue Place :</label>
                                            <input type="text" class="form-control rounded-0 bg-light" id="IssuePlace1"
                                                name="IssuePlace1" placeholder="Enter Issue Place">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="IssueDate">Issue Date :</label>
                                            <input type="date" class="form-control rounded-0 bg-light" id="IssueDate1"
                                                name="IssueDate1">
                                        </div>
                                        <div class="form-group">
                                            <label for="ExpiryDate">Expiry Date :</label>
                                            <input type="date" class="form-control rounded-0 bg-light" id="ExpiryDate1"
                                                name="ExpiryDate1">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">

                                    </div>
                                    <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                        <h2>
                                            <h2>3. Others Information of Power of Attorney Holder</h2>
                                        </h2>
                                    </div>
                                    <div class="col-sm-12">

                                        <div class="form-group">

                                            <script>
                                            </script>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Residency">Residency </label>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input" id="Residen"
                                                            name="Residency" value="Residen"
                                                            onclick="handleCheckboxSelection1('Residen')">
                                                        <label class="custom-control-label"
                                                            for="Residen">Residen</label>
                                                    </div>
                                                    <div
                                                        class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                                                        <input type="checkbox" class="custom-control-input"
                                                            id="Non_Reside" name="Residency" value="Omnibus"
                                                            onclick="handleCheckboxSelection1('Non_Reside')">
                                                        <label class="custom-control-label" for="Non_Reside">Non
                                                            Reside</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <script>
                                                function handleCheckboxSelection1(checkboxId) {
                                                    const checkboxes = [
                                                        'Residen',
                                                        'Non_Reside',
                                                    ];
                                                    checkboxes.forEach((checkbox) => {
                                                        if (checkbox !== checkboxId) {
                                                            document.getElementById(checkbox).checked = false;
                                                        }
                                                    });
                                                }
                                            </script>
                                            <script>
                                                function toggleCheckbox(checkboxId, ...otherCheckboxIds) {
                                                    const checkbox = document.getElementById(checkboxId);
                                                    if (checkbox.checked) {
                                                        otherCheckboxIds.forEach((id) => {
                                                            document.getElementById(id).checked = false;
                                                        });
                                                        document.getElementById('otherStatementCycle').disabled = true;
                                                    }
                                                }

                                                function handleOtherCheckbox() {
                                                    const otherCheckbox = document.getElementById('otherCheckbox');
                                                    if (otherCheckbox.checked) {
                                                        document.getElementById('dailyCheckbox').checked = false;
                                                        document.getElementById('weeklyCheckbox').checked = false;
                                                        document.getElementById('fortnightlyCheckbox').checked = false;
                                                        document.getElementById('monthlyCheckbox').checked = false;
                                                        document.getElementById('otherStatementCycle').disabled = false;
                                                    } else {
                                                        document.getElementById('otherStatementCycle').disabled = true;
                                                    }
                                                }
                                            </script>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Nationality">Nationality :</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Nationality1" name="Nationality1"
                                                        placeholder="Enter Nationality">
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="DateOfBirth">Date of Birth :</label>
                                                    <input type="date" class="form-control rounded-0 bg-light"
                                                        id="DateOfBirth1" name="DateOfBirth1">
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Power of Attorney Effective Form">Power of Attorney
                                                        Effective Form:</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Power_of_Attorney_Effective_Form1"
                                                        name="Power_of_Attorney_Effective_Form1"
                                                        placeholder="Enter Power of Attorney Effective Form">
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="Power of Attorney Effective To">Power of Attorney
                                                        Effective To:</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Power_of_Attorney_Effective_To1"
                                                        name="Power_of_Attorney_Effective_To1"
                                                        placeholder="Enter Power of Attorney Effective To">
                                                </div>
                                                <div class="form-group">
                                                    <label for="Remarks ">Remarks (Insert reference to POA document i.e.
                                                        Specific POA or General POA etc.):</label>
                                                    <input type="text" class="form-control rounded-0 bg-light"
                                                        id="Remarks1" name="Remarks1" placeholder="">
                                                </div>
                                            </div>

                                        </div>

                                        <div class="col-sm-6">

                                        </div>
                                        <div class="col-sm-12">

                                        </div>
                                        <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">

                                            <h2>CDBL By Laws</h2>
                                            <br>
                                            <h2>4. Photograph of Power of Attorney Holder</h2>
                                        </div>
                                        <div class="col-sm-12">

                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">(POA Holder)</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <div
                                                                    style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; weight: 15vh; height: 25vh; margin: 0;">
                                                                    <div
                                                                        style="position: relative; display: inline-block;">
                                                                        <span id="selectedFileName1"
                                                                            style="display: none;">No file
                                                                            selected</span>
                                                                    </div>
                                                                    <div style="text-align: center; margin-top: 20px;">
                                                                        <img id="previewImage1" src="#"
                                                                            alt="Selected Image"
                                                                            style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div
                                                                    style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; weight: 15vh; height: 25vh; margin: 0;">
                                                                    <div
                                                                        style="position: relative; display: inline-block;">
                                                                        <input type="file" id="imageInput1"
                                                                            accept="image/*" style="display: none;" />
                                                                        <label for="imageInput1"
                                                                            style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                                                            Image</label>
                                                                        <span id="selectedFileName1"
                                                                            style="display: none;">No file
                                                                            selected</span>
                                                                        <button id="clearImageBtn1"
                                                                            style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                                                            Image</button>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <script>
                                                    // Function to handle the image input change and display the preview image
                                                    function handleImageInputChange(inputId, previewId, fileNameId) {
                                                        const input = document.getElementById(inputId);
                                                        const previewImage = document.getElementById(previewId);
                                                        input.addEventListener('change', function(event) {
                                                            const file = event.target.files[0];
                                                            const reader = new FileReader();
                                                            reader.onload = function() {
                                                                previewImage.src = reader.result;
                                                                document.getElementById('clearImageBtn' +
                                                                        inputId.slice(-1)).style.display =
                                                                    'block';
                                                            };
                                                            if (file) {
                                                                reader.readAsDataURL(file);
                                                            }
                                                        });
                                                        // Function to handle the "Clear Image" button
                                                        document.getElementById('clearImageBtn' + inputId.slice(-1))
                                                            .addEventListener('click',
                                                                function(event) {
                                                                    event
                                                                        .preventDefault(); // Prevent the default form submission behavior
                                                                    previewImage.src = '#';
                                                                    input.value = '';
                                                                    document.getElementById('clearImageBtn' + inputId
                                                                        .slice(
                                                                            -1)).style.display = 'none';
                                                                });
                                                    }
                                                    // Call the function for each input element and preview image
                                                    handleImageInputChange('imageInput1', 'previewImage1',
                                                        'selectedFileName1');
                                                    handleImageInputChange('imageInput2', 'previewImage2',
                                                        'selectedFileName2');
                                                    handleImageInputChange('imageInput3', 'previewImage3',
                                                        'selectedFileName3');
                                                </script>

                                            </div>
                                        </div>
                                        <div class="col-sm-12">

                                        </div>

                                        <div class="col-sm-12">

                                        </div>
                                        <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                                            <h2>5. DECLARATION</h2>
                                        </div>
                                        <div class="col-sm-12">

                                        </div>
                                        <label>
                                            The rules and regulations of the Depository and CDBL participant pertaining
                                            to an account which are in force now have been read by
                                            me/us and I/we have understood the same and I/we agree to abide by and to be
                                            bound by the rules as are in force from time to time
                                            for such account. I/We also declare that the particulars given by me/us are
                                            true to the best of my/our knowledge as on the date of
                                            making such application. I/We further agree that any false/misleading
                                            information given by me/us or suppression of any material fact
                                            will render my/our account liable for termination and further
                                            action.</label>
                                        <div class="col-sm-12">

                                        </div>

                                        <div class="col-sm-12">

                                        </div>

                                        <div class="col-sm-120">

                                            <div class="form-group">
                                                <label for="Declaration"></label>

                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">Applicant</th>
                                                            <th scope="col">Name of applicant
                                                                /Authorized signatories in case of ltd</th>
                                                            <th scope="col">Signature</th>
                                                            <th scope="col">Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>POA Holder</td>
                                                            <td>
                                                                <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="poaAccName1" placeholder="" name="poaAccName1">
                                                            </td>
                                                            <td> <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="signaturpoa1" placeholder=""
                                                                    name="signaturpoa1"><input type="file"
                                                                    class="form-control-file"
                                                                    id="exampleFormControlFile1"></td>
                                                            </td>
                                                            <td> <input type="date"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="datepoaSig1" placeholder="" name="datepoaSig1">
                                                            </td>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>First Account Holder</td>
                                                            <td>
                                                                <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="firstAccName1" placeholder=""
                                                                    name="firstAccName1">
                                                            </td>
                                                            <td> <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="signaturFirst1" placeholder=""
                                                                    name="signaturFirst1"><input type="file"
                                                                    class="form-control-file"
                                                                    id="exampleFormControlFile1"></td>
                                                            </td>
                                                            <td> <input type="date"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="dateFirstSig1" placeholder=""
                                                                    name="dateFirstSig1"></td>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Second Account Holder</td>
                                                            <td>
                                                                <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="secondAccName2" placeholder=""
                                                                    name="secondAccName2">
                                                            </td>
                                                            <td> <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="signaturSecond2" placeholder=""
                                                                    name="signaturSecond2"><input type="file"
                                                                    class="form-control-file"
                                                                    id="exampleFormControlFile1"></td>
                                                            </td>
                                                            <td> <input type="date"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="dateSecondSig2" placeholder=""
                                                                    name="dateSecondSig2"></td>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>3rd Signatory ( Ltd Co. Only)</td>
                                                            <td>
                                                                <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="thirdAccName3" placeholder=""
                                                                    name="thirdAccName3">
                                                            </td>
                                                            <td> <input type="text"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="signaturThird3" placeholder=""
                                                                    name="signaturThird3">
                                                                <input type="file" class="form-control-file"
                                                                    id="exampleFormControlFile1">
                                                            </td>
                                                            </td>
                                                            <td> <input type="date"
                                                                    class="form-control rounded-0 bg-light"
                                                                    id="dateThirdSig3" placeholder=""
                                                                    name="dateThirdSig3"></td>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                            </div>

                                        </div>
                                        <div class=" col-sm-12">

                                        </div>

                                        <div class="form-footer pt-5 border-top">
                                            <button type="submit" class="btn btn-secondary btn-pill"
                                                id="submitFirstApplicant">submit</button>

                                            <button type="submit" class="btn btn-light btn-pill">Cancel</button>

                                        </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    </div>

    </div>

    <!-- Footer -->
    <footer class="footer mt-auto">
        <div class="copyright bg-white">
            <p>
                Noushin Nurjahan
            </p>
        </div>
        <script>
            var d = new Date();
            var year = d.getFullYear();
            document.getElementById("copy-year").innerHTML = year;
        </script>
    </footer>

    </div>
    </div>

    <!-- Card Offcanvas -->
    <div class="card card-offcanvas" id="contact-off">
        <div class="card-header">
            <h2>SideBar ItemRight</h2>
            <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
        </div>
        <div class="card-body">

            <div class="mb-4">
                <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
                    placeholder="Search Item...">
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

            <div class="media media-sm">
                <div class="media-sm-wrapper">

                </div>
                <div class="media-body">

                </div>
            </div>

        </div>
    </div>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/simplebar/simplebar.min.js"></script>
    <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

    <script src="plugins/prism/prism.js"></script>

    <script src="js/mono.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/map.js"></script>
    <script src="js/custom.js"></script>

    <!--  -->

</body>

</html>