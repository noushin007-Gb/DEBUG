<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: customer_application_for_creditfacility_form.php");
    exit;
}
require_once "connection.php";
$Client_CODE = $_SESSION["Client_CODE"];
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["fill_up_date"])) {
  // Extract and sanitize form data for the first account holder
  $fill_up_date = trim($_POST["fill_up_date"]);
  $text_fill_up = trim($_POST["text_fill_up"]);
  $faithfully = trim($_POST["faithfully"]);
  $Name = trim($_POST["Name"]);
  $BO = trim($_POST["BO"]);
  $Recommened_by = trim($_POST["Recommened_by"]);
  $approved_by = trim($_POST["approved_by"]);

  if (empty($text_fill_up)) {
    $text_fill_up_err = "Enter your Text here";
  } elseif (strlen($text_fill_up) > 255) {
    $text_fill_up_err = "Text should have 255 characters or less.";
  }
  if (empty($fill_up_date)) {
    $fill_up_date_err = "Enter Fill Up Date";
  }
  if (empty($faithfully)) {
    $faithfully_err = "Enter your Text here";
  } elseif (strlen($faithfully) > 40) {
    $faithfully_err = "Text should have 40 characters or less.";
  }
  if (empty($Name)) {
    $Name_err = "Enter your Name.";
  } elseif (strlen($Name) > 40) {
    $Name_err = "Name should have 40 characters or less.";
  }
  if (!empty($BO) && (!is_numeric($BO) || strlen($BO) !== 7)) {
    $BO_err = "Enter your BO Number (7 digits).";
  }
  if (empty($Recommened_by)) {
    $Recommened_by_err = "Enter Recommeneder name";
  } elseif (strlen($Recommened_by) > 40) {
    $Recommened_by_err = "Recommenedation should have 40 characters or less.";
  }
  if (empty($approved_by)) {
    $approved_by_err = "Enter Approver name";
  } elseif (strlen($approved_by) > 40) {
    $approved_by_err = "Approved By should have 40 characters or less.";
  }
 
  if (
    empty($text_fill_up_err) && empty($fill_up_date_err) &&
    empty($faithfully_err) && empty($Name_err) && empty($BO_err) &&
    empty($Recommened_by_err) && empty($approved_by_err)) {

    $checkQuery2 = "SELECT Client_CODE FROM customer_credit_facility_form WHERE Client_CODE = ?";
    if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
      mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
      mysqli_stmt_execute($checkStmt2);
      mysqli_stmt_store_result($checkStmt2);
      if (mysqli_stmt_num_rows($checkStmt2) == 0) {
        // Prepare and execute the insert statement for the first account holder's details
        $insertQuery2 = "INSERT INTO customer_credit_facility_form (fill_up_date,text_fill_up,Client_CODE,
        faithfully,Name,Code,BO,Recommened_by,approved_by) VALUES (?,?,?,?,?,?,?,?,?)";
        if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
          mysqli_stmt_bind_param($insertStmt2, "sssssssss", $fill_up_date,$text_fill_up, $Client_CODE, $faithfully,
           $Name,$Client_CODE,$BO,$Recommened_by,$approved_by);

          if (mysqli_stmt_execute($insertStmt2)) {
            // Redirect to success page or display a success message
            $errorMessage = "Success!!!";
            $displayError = true; // Set this based on your error condition

          } else {
            echo "Something went wrong. Please try again later.";
          }
          mysqli_stmt_close($insertStmt2);
        }
      } else {
        $errorMessage = "You Have Already Filled Up Credit Facility form";
        $displayError = true; // Set this based on your error condition
      }
    }
  }
}
   // Close the database connection
   mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Fill Customer Info</title>
  <meta name="theme-name" content="mono" />
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
  <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
  <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
  <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
  <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
  <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
  <link id="main-css-href" rel="stylesheet" href="css/style.css" />
  <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css" type="text/css" />
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
    type="text/css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
  <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
  <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>

  <style>
    .arrow-button {
      position: absolute;
      top: 10px;
      right: 20px;
    }

    .rotate {
      transform: rotate(180deg);
    }
  </style>
  <style>
    .hidden {
      display: none;
    }

    .custom-alert {
      position: relative;
      background-color: #187016;
      color: #fff;
      padding: 10px;
      width: 500px;
      border-radius: 5px;
    }

    .close-button {
      position: absolute;
      top: 5px;
      right: 5px;
      font-size: 20px;
      cursor: pointer;
      z-index: 1;
      padding-left: 5px;
      /* Ensure the cross is on top */
    }
  </style>

  <script>
    /* for alert box */
    document.addEventListener("DOMContentLoaded", function() {
      const errorDiv = document.getElementById("errorDiv");
      const closeButton = document.getElementById("closeButton");
      closeButton.addEventListener("click", function() {
        errorDiv.style.display = "none";
      });
      setTimeout(function() {
        errorDiv.style.display = "none";
      }, 3000);
    });
  </script>
  <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
  <script>
    NProgress.configure({
      showSpinner: false
    });
    NProgress.start();
  </script>
  <div id="toaster"></div>
  <div class="wrapper">
    <aside class="left-sidebar sidebar-light" id="left-sidebar">
      <div id="sidebar" class="sidebar sidebar-with-footer">
        <!-- Aplication Brand -->
        <div class="app-brand">
          <a href="#">
            <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
          </a>
        </div>
        <!-- begin sidebar scrollbar -->
        <div class="sidebar-left" data-simplebar style="height: 100%;">
          <!-- sidebar menu -->
          <ul class="nav sidebar-inner" id="sidebar-menu">
            <li>
              <a class="sidenav-item-link" href="index.php">
                <i class="mdi mdi-briefcase-account-outline"></i>
                <span class="nav-text">Dashboard</span>
              </a>
            </li>
            <li class="section-title">
              Forms
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_opening_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">ACCOUNT INFORMATION</span>
              </a>
            </li>
            <li class="active">
              <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">CREDIT FACILITY</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_BO_account_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. OPENING</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. NOMINATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_POA.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Power of Attorney (POA)</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_application_for_terms_and_conditions_by_laws.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Terms & Conditions</span>
              </a>
            </li>

            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">EFT Enrollment</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Signature Card</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Value Added Service</span>
              </a>
            </li>
            <li class="section-title">
              Pages
            </li>

            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                <i class="mdi mdi-account"></i>
                <span class="nav-text">Authentication</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="sign-in.html">
                      <span class="nav-text">Sign In</span>

                    </a>
                  </li>
                </div>
              </ul>
            </li>
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                aria-expanded="false" aria-controls="other-page">
                <i class="mdi mdi-file-multiple"></i>
                <span class="nav-text">Other pages</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="#">
                      <span class="nav-text">Nothing</span>

                    </a>
                  </li>
                </div>
              </ul>
            </li>
            <li class="section-title">
              Documentation
            </li>
            <li>
              <a class="sidenav-item-link" href="#">
                <i class="mdi mdi-airplane"></i>
                <span class="nav-text">Nothing</span>
              </a>
            </li>

          </ul>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-footer-content">
            <ul class="d-flex">
              <li>
                <a href="#" data-toggle="tooltip" title="Profile settings"><i class="mdi mdi-settings"></i></a></li>
              <li>
                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip" title="Logout"><i
                    class="mdi mdi-logout"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </aside>
    <div class="page-wrapper">

      <!-- Header -->
      <header class="main-header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <!-- Sidebar toggle button -->
          <button id="sidebar-toggler" class="sidebar-toggle">
            <span class="sr-only">Toggle navigation</span>
          </button>

          <span class="page-title">Customer Dashboard</span>

          <div class="navbar-right ">

            <!-- search form -->
            <div class="search-form">
              <form action="index.php" method="get">
                <div class="input-group input-group-sm" id="input-group-search">
                  <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                    placeholder="Search..." />
                  <div class="input-group-append">
                    <button class="btn" type="button">/</button>
                  </div>
                </div>
              </form>
              <ul class="dropdown-menu dropdown-menu-search">

                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>

              </ul>

            </div>

            <ul class="nav navbar-nav">
              <!-- Offcanvas -->
              <li class="custom-dropdown">
                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                  href="javascript:">
                  <i class="mdi mdi-contacts icon"></i>
                </a>
              </li>
              <li class="custom-dropdown">
                <button class="notify-toggler custom-dropdown-toggler">
                  <i class="mdi mdi-bell-outline icon"></i>
                  <span class="badge badge-xs rounded-circle">21</span>
                </button>
                <div class="dropdown-notify">

                  <header>
                    <div class="nav nav-underline" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                        aria-controls="nav-home" aria-selected="true">All (5)</a>
                      <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                        aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                      <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                        aria-controls="nav-contact" aria-selected="false">Others (3)</a>
                    </div>
                  </header>

                  <footer class="border-top dropdown-notify-footer">
                    <div class="d-flex justify-content-between align-items-center py-2 px-4">
                      <span>Last updated 3 min ago</span>
                      <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                    </div>
                  </footer>
                </div>
              </li>
              <!-- User Account -->
              <li class="dropdown user-menu">
                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <img
                    src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                    class="user-image rounded-circle" alt="User Image" />
                  <span
                    class="d-none d-lg-inline-block"><b><?php echo htmlspecialchars($_SESSION["username"]); ?></i></b>
                    <b><?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?></b></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">

                  <li>
                    <a class="dropdown-link-item" href="#">
                      <i class="mdi mdi-settings"></i>
                      <span class="nav-text">Account Setting</span>
                    </a>
                  </li>

                  <li class="dropdown-footer">
                    <a class="dropdown-link-item" href="/debug/lanka-bangla/main-login/client_logout.php"> <i
                        class="mdi mdi-logout"></i> Log Out </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>

      </header>

      <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
      <div class="content-wrapper">
        <div class="content">
          <!-- For Components documentaion -->

          <div class="px-6 py-4">
            <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
            <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023, Chittagong
                Stock Exchange </span> </p>
            <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">APPLICATION FOR CREDIT
                FACILITY FORM </span> </p>
            <div class="alert alert-dark <?php if (!$displayError)
                 echo 'hidden'; ?> custom-alert" role="alert" id="errorDiv">
              <span class="close-button" id="closeButton">&times;</span>
              <?php echo $errorMessage; ?>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-10">
              <!-- Custom Styles -->
              <div class="card card-default">
                <div class="card-body">
                  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="date">Date :</label>
                          <input type="date" class="form-control rounded-0 bg-light" id="fill_up_date"
                            name="fill_up_date">
                          <?php if (!empty($fill_up_date_err)): ?>
                          <span class="text-danger"><?php echo $fill_up_date_err; ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <div class="px-6 py-4">[FILL UP THE FORM IN CAPITAL LETTERS]</div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                          </div>
                          <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <div class="px-6 py-4">Cheif Executive Officer
                            LankaBangla Securities Ltd
                            9/E, Motijheel C/A, Dhaka</div>
                          <div class="px-6 py-4">Dear Sir</div>
                        </div>
                      </div>
                      <div class="col-sm-10">
                      </div>
                      <div class="col-sm-12">
                        <div class="form-group">
                          <div class="px-6 py-4">
                            <div class="d-flex align-items-center">
                              <span class="me-2">I/We. </span>
                              <input class="form-control form-control-sm" id="text_fill_up" name="text_fill_up"
                                type="text" placeholder="" style="margin-left: 10px;">
                              <?php if (!empty($text_fill_up_err)): ?>
                              <span class="text-danger"><?php echo $text_fill_up_err; ?></span>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-12">
                      </div>
                      <div class="col-sm-12">
                        <div class="form-group">
                          <div class="px-6 py-4" style="display: inline-block; white-space: nowrap;">
                            <div class="d-flex align-items-center">
                              <span class="me-2">Client Code</span>
                              <fieldset disabled>
                                <input class="form-control form-control-sm" type="text"
                                  placeholder=<?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?>>
                              </fieldset>
                              <span class="me-2">would like to avail the credit facility from your company</span>
                            </div>
                            <div class="d-flex align-items-center">
                              <span class="me-2">for purchasing shares/ securities through
                                your broker house.</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <div class="px-6 py-4" style="display: inline-block; white-space: nowrap;">
                            <div class="d-flex align-items-center">
                              <span class="me-2">I furnish herewith the necessary information/documents for your kind
                                perusal.</span>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="px-6 py-4" style="display: inline-block; white-space: nowrap;">
                            <div class="d-flex align-items-center">
                              <span class="me-2">Your faithfully</span>
                            </div>
                          </div>
                          <div class="px-6 py-4">
                            <div class="d-flex align-items-center">
                              <input class="form-control form-control-sm" id="faithfully" name="faithfully" type="text"
                                placeholder="" style="margin-right: 10px ">
                              <?php if (!empty($faithfully_err)): ?>
                              <span class="text-danger"><?php echo $faithfully_err; ?></span>
                              <?php endif; ?>
                            </div>
                          </div>
                          <div class="px-6 py-4">
                            <div class="d-flex align-items-center">
                              <span class="me-2"
                                style="display: inline-block; white-space: nowrap;margin-right: 10px;margin-bottom: 10px ">Name
                                :</span>
                              <input class="form-control form-control-sm" id="Name" name="Name" type="text"
                                placeholder="" style="margin-right: 10px;margin-bottom: 10px ">
                              <?php if (!empty($Name_err)): ?>
                              <span class="text-danger"><?php echo $Name_err; ?></span>
                              <?php endif; ?>
                            </div>
                            <div class="d-flex align-items-center">
                              <span class="me-2"
                                style="display: inline-block; white-space: nowrap;margin-right: 10px;margin-bottom: 10px ">Code
                                :</span>
                              <fieldset disabled>
                                <input class="form-control form-control-sm"
                                  placeholder=<?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?> type="text">
                              </fieldset>
                            </div>
                            <div class="d-flex align-items-center">
                              <span class="me-2"
                                style="display: inline-block; white-space: nowrap;margin-right: 10px;margin-bottom: 10px ">BO
                                :</span>
                              <input class="form-control form-control-sm" id="BO" name="BO" type="text" placeholder=""
                                style="margin-right: 10px;margin-bottom: 10px ">
                              <?php if (!empty($BO_err)): ?>
                              <span class="text-danger"><?php echo $BO_err; ?></span>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="px-6 py-4" style="display: inline-block; white-space: nowrap;">
                            <div class="d-flex align-items-center">
                              <input class="form-control form-control-sm" id="Recommened_by" name="Recommened_by"
                                type="text" placeholder="" style="margin-right: 10px;margin-bottom: 10px ">
                              <?php if (!empty($Recommened_by_err)): ?>
                              <span class="text-danger"><?php echo $Recommened_by_err; ?></span>
                              <?php endif; ?>
                            </div>
                            <div class="d-flex align-items-center">
                              <span>Recommened By : </span>
                            </div>
                          </div>
                          <div class="px-6 py-4" style="display: inline-block; white-space: nowrap;">
                            <div class="d-flex align-items-center">
                              <input class="form-control form-control-sm" id="approved_by" name="approved_by"
                                type="text" placeholder="" style="margin-right: 10px;margin-bottom: 10px ">
                              <?php if (!empty($approved_by_err)): ?>
                              <span class="text-danger"><?php echo $approved_by_err; ?></span>
                              <?php endif; ?>
                            </div>
                            <div class="d-flex align-items-center">
                              <span>Approved By : </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                      <input type="checkbox" class="custom-control-input" id="customCheckTerms" name="customCheckTerms"
                        value="customCheckTerms">
                      <label class="custom-control-label" for="customCheckTerms">See our <button type="button"
                          data-toggle="modal" data-target="#exampleModalLong" style="color: green;"
                          style="border: 20cap;">
                          TERMS AND CONDITIONS
                        </button> for more info. By checking the box you acknowledge and represent it</label>
                    </div>
                    <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog"
                      aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">TERMS AND CONDITIONS</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">×</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <h4>DEFINITIONS</h4>
                            <ul>
                              <li><strong>Securities Account:</strong> The account opened by the CLIENT with the BROKER
                                to deposit, sell, or buy securities.</li>
                              <li><strong>Approved Securities:</strong> The securities purchased into the Securities
                                Account.</li>
                              <li><strong>Portfolio Value:</strong> The total market value of all the stocks in the
                                Securities Account.</li>
                              <li><strong>Margin Call:</strong> A request to the CLIENT to deposit money or shares to
                                bring the Debit Balance below a certain percentage of the Portfolio Value.</li>
                              <li><strong>Portfolio Value within Securities Account:</strong> The total value of cash
                                owned by the CLIENT together with any interest in the Securities Account for securities
                                purchased into the account.</li>
                            </ul>
                            <h4>TERMS AND CONDITIONS</h4>
                            <ol>
                              <li>This will strictly be a short-term facility and valid up-to [insert date].</li>
                              <li>The BROKER has absolute discretion to accept or decline any security against which
                                credit facility is granted and can make changes to their list of approved securities at
                                any time.</li>
                              <li>The CLIENT may use the credit facility to purchase quoted securities through the
                                BROKER into the Securities Account up to a maximum value of [insert percentage] of the
                                Portfolio Value or Tk [insert amount], whichever is lower. The CLIENT is responsible for
                                maintaining the maximum limit of the Debit Balance at all times. If the Debit Balance
                                exceeds [insert percentage] of the Portfolio Value, the BROKER will issue a Margin Call
                                to the CLIENT.</li>
                              <li>The BROKER has the authority to give notice to the CLIENT to adjust the debit balance
                                in the Securities Account within 20 trading days for any reason. If the CLIENT doesn't
                                respond to such notice, the BROKER has the discretion to sell or buy any or all shares
                                or securities in the CLIENT's Securities Account without the CLIENT's consent in order
                                to adjust the Debit Balance.</li>
                              <li>If a particular security is omitted from the list of approved securities by the
                                BROKER, the CLIENT must adjust the Portfolio Value or the Debit Balance within two
                                market days.</li>
                              <li>If the CLIENT doesn't respond to a Margin Call, the BROKER will sell whatever shares
                                it sees fit to regularize the Debit Balance to [insert percentage] of the Portfolio
                                Value. A deviation of +/-5% is accepted in case of adjustment.</li>
                              <li>If the Debit Balance reaches [insert percentage] of the Portfolio Value due to a
                                sudden fall in the market or any other event, the BROKER will sell shares of any company
                                as it sees fit to make the Debit Balance nil. Any residual shares will remain in the
                                account and will be available to the CLIENT.</li>
                              <li>The CLIENT shall pay brokerage commission for all transactions (buy and sell) in the
                                Securities Account, as well as for transactions carried out to regularize the Securities
                                Account. The rate of brokerage will be fixed by the BROKER and can change from time to
                                time.</li>
                              <li>If the CLIENT exceeds the value of the Debit Balance above the stipulated limit or
                                violates any other terms and conditions/rules/requirements laid down by the BROKER or
                                any regulatory authority, the BROKER has the discretion to sell or buy any or all shares
                                or securities in the CLIENT's Securities Account without the CLIENT's consent in order
                                to adjust the Debit Balance. If the Portfolio Value becomes inadequate to regularize the
                                Debit Balance, the CLIENT must make a cash payment to settle any shortfall.</li>
                              <li>If the CLIENT enjoys margin facilities in the Securities Account, the highest limit to
                                buy a single stock is Tk [insert amount] or [insert percentage] of the Portfolio Value,
                                whichever is lower.</li>
                              <li>The BROKER will charge [insert percentage] per annum interest on the CLIENT's account
                                for any debit amount, calculated on a daily basis. The BROKER reserves the right to
                                increase or decrease the interest rate by giving 7 trading days' notice to the CLIENT.
                              </li>
                              <li>The Securities Account will be fully operated by the CLIENT at all times, except when
                                the BROKER is regularizing the account as explained in clauses 5, 6, 7, and 10.</li>
                              <li>The BROKER has the right to change, rectify, or include any additional terms and
                                conditions at any time with due notice to the CLIENT.</li>
                            </ol>

                            <h4>NOMINEE</h4>
                            <ul>
                              <li>In the event of the death of one of the joint account holders, the survivor will be
                                the beneficiary of the transactions. On the death of the sole account holder, the
                                nominee or successor will be the beneficiary of the transactions.</li>
                            </ul>

                            <h4>GOVERNING LAW</h4>
                            <ul>
                              <li>All transactions shall be subject to the Rules and Regulations of the Securities and
                                Exchange Commission of Bangladesh, Dhaka Stock Exchange Ltd., and other prevailing laws
                                and regulations of Bangladesh.</li>
                            </ul>

                            <h4>If Client(s) is/are an Individual/Individuals</h4>
                            <p>Signature of CLIENT(s)</p>
                            <input type="text" id="signatureOfClient1" name="signatureOfClient1"
                              placeholder="Signature of CLIENT(s)">

                            <h4>If Client is a Company:</h4>
                            <p>Authorized Signatory</p>
                            <input type="text" id="authSignature" name="authSignature"
                              placeholder="Enter Authorized Signatory">
                          </div>

                          <div class="modal-footer">
                            <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>

                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-footer pt-5 border-top">
                      <button type="submit" class="btn btn-secondary btn-pill" id="submit" name="submit">Submit</button>
                      <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                    </div>
                  </form>
                </div>
                <script>
                  const submitBtn = document.getElementsByName("submit")[0];
                  const customCheckTerms = document.getElementById("customCheckTerms");
                  submitBtn.addEventListener("click", function(event) {
                    if (!customCheckTerms.checked) {
                      event.preventDefault();
                      alert("Please agree to the terms before submitting.");
                    }
                  });
                </script>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer mt-auto">
    <div class="copyright bg-white">
      <p>
        Noushin Nurjahan
      </p>
    </div>
    <script>
      var d = new Date();
      var year = d.getFullYear();
      document.getElementById("copy-year").innerHTML = year;
    </script>
  </footer>

  </div>
  </div>

  <!-- Card Offcanvas -->
  <div class="card card-offcanvas" id="contact-off">
    <div class="card-header">
      <h2>SideBar ItemRight</h2>
      <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
    </div>
    <div class="card-body">

      <div class="mb-4">
        <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
          placeholder="Search Item...">
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

    </div>
  </div>

  <script src="plugins/jquery/jquery.min.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="plugins/simplebar/simplebar.min.js"></script>
  <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

  <script src="plugins/prism/prism.js"></script>

  <script src="js/mono.js"></script>
  <script src="js/chart.js"></script>
  <script src="js/map.js"></script>
  <script src="js/custom.js"></script>

  <!--  -->

</body>

</html>