<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Customer Dashboard</title>
  <meta name="theme-name" content="mono" />
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
  <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
  <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
  <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
  <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
  <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
  <link id="main-css-href" rel="stylesheet" href="css/style.css" />
  <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
  <script src="plugins/nprogress/nprogress.js"></script>

</head>

<body class="navbar-fixed sidebar-fixed" id="body">
  <script>
    NProgress.configure({
      showSpinner: false
    });
    NProgress.start();
  </script>
  <div id="toaster"></div>
  <div class="wrapper">
    <aside class="left-sidebar sidebar-light" id="left-sidebar">
      <div id="sidebar" class="sidebar sidebar-with-footer">
        <!-- Aplication Brand -->
        <div class="app-brand">
          <a href="#">
            <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
          </a>
        </div>
        <!-- begin sidebar scrollbar -->
        <div class="sidebar-left" data-simplebar style="height: 100%;">
          <!-- sidebar menu -->
          <ul class="nav sidebar-inner" id="sidebar-menu">
            <li class="active">
              <a class="sidenav-item-link" href="index.html">
                <i class="mdi mdi-briefcase-account-outline"></i>
                <span class="nav-text">Dashboard</span>
              </a>
            </li>
            <li class="section-title">
              View
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_opening_form.html">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Customer Filled Form</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_opening_form.html">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">CDBL System Query</span>
              </a>
            </li>

            <li class="section-title">
              Pages
            </li>

            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                <i class="mdi mdi-account"></i>
                <span class="nav-text">Authentication</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="sign-in.html">
                      <span class="nav-text">Sign In</span>

                    </a>
                  </li>
                </div>
              </ul>
            </li>
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                aria-expanded="false" aria-controls="other-page">
                <i class="mdi mdi-file-multiple"></i>
                <span class="nav-text">Other pages</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="3">
                      <span class="nav-text">Nothing</span>

                    </a>
                  </li>
                </div>
                
              </ul>
            </li>
            <li class="section-title">
              Documentation
            </li>
            <li>
              <a class="sidenav-item-link" href="#">
                <i class="mdi mdi-airplane"></i>
                <span class="nav-text">Nothing</span>
              </a>
            </li>
          </ul>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-footer-content">
            <ul class="d-flex">
              <li>
                <a href="#" data-toggle="tooltip" title="Profile settings"><i
                    class="mdi mdi-settings"></i></a></li>
              <li>
                <a href="#" data-toggle="tooltip" title="Logout"><i class="mdi mdi-logout"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </aside>
    <div class="page-wrapper">

      <!-- Header -->
      <header class="main-header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <!-- Sidebar toggle button -->
          <button id="sidebar-toggler" class="sidebar-toggle">
            <span class="sr-only">Toggle navigation</span>
          </button>

          <span class="page-title">Account Officer Dashboard</span>

          <div class="navbar-right ">

            <!-- search form -->
            <div class="search-form">
              <form action="index.html" method="get">
                <div class="input-group input-group-sm" id="input-group-search">
                  <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                    placeholder="Search..." />
                  <div class="input-group-append">
                    <button class="btn" type="button">/</button>
                  </div>
                </div>
              </form>
              <ul class="dropdown-menu dropdown-menu-search">

                <li class="nav-item">
                  <a class="nav-link" href="index.html"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.html"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.html"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.html"></a>
                </li>

              </ul>

            </div>

            <ul class="nav navbar-nav">
              <!-- Offcanvas -->
              <li class="custom-dropdown">
                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                  href="javascript:">
                  <i class="mdi mdi-contacts icon"></i>
                </a>
              </li>
              <li class="custom-dropdown">
                <button class="notify-toggler custom-dropdown-toggler">
                  <i class="mdi mdi-bell-outline icon"></i>
                  <span class="badge badge-xs rounded-circle">21</span>
                </button>
                <div class="dropdown-notify">

                  <header>
                    <div class="nav nav-underline" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                        aria-controls="nav-home" aria-selected="true">All (5)</a>
                      <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                        aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                      <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                        aria-controls="nav-contact" aria-selected="false">Others (3)</a>
                    </div>
                  </header>

                  

                  <footer class="border-top dropdown-notify-footer">
                    <div class="d-flex justify-content-between align-items-center py-2 px-4">
                      <span>Last updated 3 min ago</span>
                      <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                    </div>
                  </footer>
                </div>
              </li>
              <!-- User Account -->
              <li class="dropdown user-menu">
                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <img src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg" class="user-image rounded-circle" alt="User Image" />
                  <span class="d-none d-lg-inline-block">Noushin</span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">
                  
                  
                  <li>
                    <a class="dropdown-link-item" href="#">
                      <i class="mdi mdi-settings"></i>
                      <span class="nav-text">Account Setting</span>
                    </a>
                  </li>

                  <li class="dropdown-footer">
                    <a class="dropdown-link-item" href="#"> <i class="mdi mdi-logout"></i> Log Out </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>

      </header>

      <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
      <div class="content-wrapper">
        <div class="content">
          <!-- Top Statistics -->
          <div class="row">
            <div class="col-xl-3 col-sm-6">
              <div class="card card-default">
                <div class="card-body">
                  <label>View Account Officer Info</label>
                </div>

              </div>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <footer class="footer mt-auto">
          <div class="copyright bg-white">
            <p>
              Noushin Nurjahan
            </p>
          </div>
          <script>
            var d = new Date();
            var year = d.getFullYear();
            document.getElementById("copy-year").innerHTML = year;
          </script>
        </footer>

      </div>
    </div>

    <!-- Card Offcanvas -->
    <div class="card card-offcanvas" id="contact-off">
      <div class="card-header">
        <h2>SideBar ItemRight</h2>
        <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
      </div>
      <div class="card-body">

        <div class="mb-4">
          <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
            placeholder="Search Item...">
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">


          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

        <div class="media media-sm">
          <div class="media-sm-wrapper">

          </div>
          <div class="media-body">

          </div>
        </div>

      </div>
    </div>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/simplebar/simplebar.min.js"></script>
    <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

    <script src="plugins/apexcharts/apexcharts.js"></script>

    <script src="plugins/DataTables/DataTables-1.10.18/js/jquery.dataTables.min.js"></script>

    <script src="plugins/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill.js"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-us-aea.js"></script>

    <script src="plugins/daterangepicker/moment.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <script>
      jQuery(document).ready(function() {
        jQuery('input[name="dateRange"]').daterangepicker({
          autoUpdateInput: false,
          singleDatePicker: true,
          locale: {
            cancelLabel: 'Clear'
          }
        });
        jQuery('input[name="dateRange"]').on('apply.daterangepicker', function(ev, picker) {
          jQuery(this).val(picker.startDate.format('MM/DD/YYYY'));
        });
        jQuery('input[name="dateRange"]').on('cancel.daterangepicker', function(ev, picker) {
          jQuery(this).val('');
        });
      });
    </script>

    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <script src="plugins/toaster/toastr.min.js"></script>

    <script src="js/mono.js"></script>
    <script src="js/chart.js"></script>
    <script src="js/map.js"></script>
    <script src="js/custom.js"></script>

    <!--  -->

</body>

</html>