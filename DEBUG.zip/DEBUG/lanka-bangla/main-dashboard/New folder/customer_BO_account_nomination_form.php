<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: customer_BO_account_nomination_form.php");
    exit;
}





?>



<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Fill Customer Info</title>
  <meta name="theme-name" content="mono" />
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
  <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
  <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
  <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
  <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
  <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
  <link id="main-css-href" rel="stylesheet" href="css/style.css" />
  <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css" type="text/css" />
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
    type="text/css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
  <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
  <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>

  <style>
    .arrow-button {
      position: absolute;
      top: 10px;
      right: 20px;
    }

    .rotate {
      transform: rotate(180deg);
    }
  </style>

  <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
  <script>
    NProgress.configure({
      showSpinner: false
    });
    NProgress.start();
  </script>
  <div id="toaster"></div>
  <div class="wrapper">
    <aside class="left-sidebar sidebar-light" id="left-sidebar">
      <div id="sidebar" class="sidebar sidebar-with-footer">
        <!-- Aplication Brand -->
        <div class="app-brand">
          <a href="#">
            <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
          </a>
        </div>
        <!-- begin sidebar scrollbar -->
        <div class="sidebar-left" data-simplebar style="height: 100%;">
          <!-- sidebar menu -->
          <ul class="nav sidebar-inner" id="sidebar-menu">
            <li>
              <a class="sidenav-item-link" href="index.php">
                <i class="mdi mdi-briefcase-account-outline"></i>
                <span class="nav-text">Dashboard</span>
              </a>
            </li>
            <li class="section-title">
              Forms
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_opening_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">ACCOUNT INFORMATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">CREDIT FACILITY</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_BO_account_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. OPENING</span>
              </a>
            </li>
            <li class="active">
              <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. NOMINATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_POA.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Power of Attorney (POA)</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Terms & Conditions</span>
              </a>
            </li>

            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">EFT Enrollment</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Signature Card</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Value Added Service</span>
              </a>
            </li>
           
            <li class="section-title">
              Pages
            </li>
           
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                <i class="mdi mdi-account"></i>
                <span class="nav-text">Authentication</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="sign-in.html">
                      <span class="nav-text">Sign In</span>

                    </a>
                  </li>
                 
                </div>
              </ul>
            </li>
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                aria-expanded="false" aria-controls="other-page">
                <i class="mdi mdi-file-multiple"></i>
                <span class="nav-text">Other pages</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="#">
                      <span class="nav-text">Nothing</span>

                    </a>
                  </li>
                 
                </div>
              </ul>
            </li>
            <li class="section-title">
              Documentation
            </li>
            <li>
              <a class="sidenav-item-link" href="#">
                <i class="mdi mdi-airplane"></i>
                <span class="nav-text">Nothing</span>
              </a>
            </li>
           
          </ul>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-footer-content">
            <ul class="d-flex">
              <li>
                <a href="#" data-toggle="tooltip" title="Profile settings"><i
                    class="mdi mdi-settings"></i></a></li>
              <li>
                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip" title="Logout"><i class="mdi mdi-logout"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </aside>
    <div class="page-wrapper">

      <!-- Header -->
      <header class="main-header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <!-- Sidebar toggle button -->
          <button id="sidebar-toggler" class="sidebar-toggle">
            <span class="sr-only">Toggle navigation</span>
          </button>

          <span class="page-title">Customer Dashboard</span>

          <div class="navbar-right ">

            <!-- search form -->
            <div class="search-form">
              <form action="index.php" method="get">
                <div class="input-group input-group-sm" id="input-group-search">
                  <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                    placeholder="Search..." />
                  <div class="input-group-append">
                    <button class="btn" type="button">/</button>
                  </div>
                </div>
              </form>
              <ul class="dropdown-menu dropdown-menu-search">

                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>

              </ul>

            </div>

            <ul class="nav navbar-nav">
              <!-- Offcanvas -->
              <li class="custom-dropdown">
                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                  href="javascript:">
                  <i class="mdi mdi-contacts icon"></i>
                </a>
              </li>
              <li class="custom-dropdown">
                <button class="notify-toggler custom-dropdown-toggler">
                  <i class="mdi mdi-bell-outline icon"></i>
                  <span class="badge badge-xs rounded-circle">21</span>
                </button>
                <div class="dropdown-notify">

                  <header>
                    <div class="nav nav-underline" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                        aria-controls="nav-home" aria-selected="true">All (5)</a>
                      <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                        aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                      <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                        aria-controls="nav-contact" aria-selected="false">Others (3)</a>
                    </div>
                  </header>

                  

                  <footer class="border-top dropdown-notify-footer">
                    <div class="d-flex justify-content-between align-items-center py-2 px-4">
                      <span>Last updated 3 min ago</span>
                      <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                    </div>
                  </footer>
                </div>
              </li>
              <!-- User Account -->
              <li class="dropdown user-menu">
                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <img src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg" class="user-image rounded-circle" alt="User Image" />
                  <span class="d-none d-lg-inline-block"><b><?php echo htmlspecialchars($_SESSION["username"]); ?></i></b> 
                 <b><?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?></b></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">
                  
                  
                  <li>
                    <a class="dropdown-link-item" href="#">
                      <i class="mdi mdi-settings"></i>
                      <span class="nav-text">Account Setting</span>
                    </a>
                  </li>

                  <li class="dropdown-footer">
                    <a class="dropdown-link-item" href="/debug/lanka-bangla/main-login/client_logout.php"> <i class="mdi mdi-logout"></i> Log Out </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>

      </header>

      <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
      <div class="content-wrapper">
        <div class="content">
          <!-- For Components documentaion -->

          <div class="px-6 py-4">
            <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
            <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023, Chittagong
                Stock Exchange </span> </p>
            <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">BO ACCOUNT
                NOMINATION FORM </span> </p>
          </div>

          <div class="row">
            <div class="col-sm-10">
              <!-- Custom Styles -->
              <div class="card card-default">
                <div class="card-body">
                  <label for="text" style="margin-top: 20px;margin-bottom: 20px;">Please complete all details in CAPITAL
                    letters. Please fill all names correctly. All communications shall be sent to the
                    correspondence address of only the First Named Account Holder as specified in BO Account Opening
                    Form 02.</label>
                  <form>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="date">Date :</label>
                          <input type="date" class="form-control rounded-0 bg-light" id="date1" name="date1">
                          <?php if (!empty($date1_err)): ?>
                                                        <span class="text-danger"><?php echo $date1_err; ?></span>
                                                    <?php endif; ?>
                        </div>
                        <div class="form-group">
                          <label for="application">Application : </label>
                          <input type="text" class="form-control rounded-0 bg-light" id="application1" placeholder=""
                            name="application1">
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                        </div>
                      </div>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <fieldset disabled><label for="cdblParticipentName">Name of CDBL Participant : </label>
                            <input type="text" class="form-control rounded-0 bg-light" id="cdblParticipentName1"
                              placeholder="LankaBangla Securities Ltd." name="cdblParticipentName1"
                              value="LankaBangla Securities Ltd.">
                          </fieldset>
                        </div>
                        <div class="form-group">
                          <label for="bo_id">Account Holder's BO Id : </label>
                          <input type="text" class="form-control rounded-0 bg-light" id="bo_id1"
                            placeholder="Enter BO ID" name="bo_id1">
                        </div>

                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="CDBL_Participant_ID">CDBL Participant ID : </label>
                          <input type="text" class="form-control rounded-0 bg-light" id="CDBL_Participant_ID1"
                            placeholder="Enter CDBL Participant ID" name="CDBL_Participant_ID1">
                        </div>
                        <div class="form-group">
                          <label for="NameofAccountHolder">Name of Account Holder (Insert full name starting with Title
                            i.e. Mr./Mrs./Ms/Dr, abbreviate only if over 30 characters) : </label>
                          <input type="text" class="form-control rounded-0 bg-light" id="bo_id1"
                            placeholder="Enter Name of Account Holder" name="NameofAccountHolder1">
                        </div>

                      </div>

                      <script>
                        function handleCheckboxSelection(checkboxId) {
                          const checkboxes = [
                            'customCheckCompany',
                            'customCheckIndividual',
                            'customCheckJointHolder'
                          ];
                          checkboxes.forEach((checkbox) => {
                            if (checkbox !== checkboxId) {
                              document.getElementById(checkbox).checked = false;
                            }
                          });
                        }
                      </script>

                    </div>
                    <label style="margin-top: 30px;" for="nominate">I/We nominate the following person (S) who is/are
                      entitled to receive securities outstanding in my/our account in the event of the
                      death of the sole holder/all the joint holders.training</label>
                    <div class="form-footer pt-5 border-top">
                    </div>
                  </form>
                </div>
              </div>
              <!-- 1. Nominee.Heirs Details -->
              <div class="card card-default">
                <div class="card-header" id="cardHeader3">
                  <h2>Nominee.Heirs Details</h2>
                </div>
                <div class="card-body">
                  <form>
                    <div class="row">
                      <div class="col-sm-12">

                      </div>
                      <div style="margin-bottom: 50px;">
                        <h2>Nominee 1</h2>
                      </div>
                      <div class="col-sm-12">
                      </div>
                      <div class="col-sm-6">

                        <div class="form-group">
                          <label for="fullName">Full Name :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="fullName2" name="fullName2"
                            placeholder="Enter Full Name">
                        </div>
                        <div class="form-group">
                          <label for="shortName">Short Name (Insert full name starting with Title i.e. Mr./Mrs./Ms/Dr,
                            abbreviate only if over 30 characters) :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="shortName2" name="shortName2"
                            placeholder="Enter Short Name">
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="title">Title i.e. Mr./Mrs./Ms :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="title2" name="title2"
                            placeholder="Enter Title i.e Mr./Mrs./Ms">
                        </div>
                        <div class="form-group">
                          <label for="relationship">Relationship with Nominee :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="relationship2"
                            name="relationship2" placeholder="Enter Relationship with Nominee">
                        </div>
                      </div>

                      <div class="form-group" style="margin-right: 10px;">
                        <label for="percentage">Percentage (%) :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="percentage2" name="percentage2"
                          placeholder="Enter Percentage">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="address">Address :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="address2" name="address2"
                          placeholder="Enter Address">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="city">City :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="city2" name="city2"
                          placeholder="Enter City">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="postCode">Post Code :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="postCode2" name="postCode2"
                          placeholder="Enter Post Code">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="state">State/Division :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="state2" name="state2"
                          placeholder="Enter State/Division">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="country">Country :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="country2" name="country2"
                          placeholder="Enter Country">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="telephone">Telephone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="telephone2" name="telephone2"
                          placeholder="Enter Telephone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="mobilePhone">Mobile Phone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="mobilePhone2" name="mobilePhone2"
                          placeholder="Enter Mobile Phone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="fax">Fax :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="fax2" name="fax2"
                          placeholder="Enter Fax">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="email">Email :</label>
                        <input type="email" class="form-control rounded-0 bg-light" id="email2" name="email2"
                          placeholder="Enter Email">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="passportNo">Passport No :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="passportNo2" name="passportNo2"
                          placeholder="Enter Passport No">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="nid">NID :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="nid2" name="nid2"
                          placeholder="Enter NID">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="issuePlace">Issue Place :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="issuePlace2" name="issuePlace2"
                          placeholder="Enter Issue Place">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="issueDate">Issue Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="issueDate2" name="issueDate2">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="expiryDate">Expiry Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="expiryDate2" name="expiryDate2">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="residency">Residency :</label>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="residencyResidentCheckbox"
                            name="residencyStatus" value="Resident"
                            onclick="handleResidencySelection2('residencyResidentCheckbox')">
                          <label class="custom-control-label" for="residencyResidentCheckbox">Resident</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="residencyNonResidentCheckbox"
                            name="residencyStatus" value="NonResident"
                            onclick="handleResidencySelection2('residencyNonResidentCheckbox')">
                          <label class="custom-control-label" for="residencyNonResidentCheckbox">Non-Resident</label>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="nationality">Nationality :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="nationality2" name="nationality2"
                          placeholder="Enter Nationality">
                      </div>
                      <div class="form-group">
                        <label for="dateOfBirth">Date of Birth :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="dateOfBirth2" name="dateOfBirth2">
                      </div>
                    </div>

                    <!-- Guardian's Details (If Nominee is a Minor) -->
                    <div class="row">
                      <div class="col-sm-6"> <label style="font-weight: 1000;margin-bottom: 30px;"
                          for="DepositoryAccount">Guardian's Details (If Nominee is a Minor)</label>
                        <div class="form-group">
                          <label for="guardianFullName">Name in Full :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianFullName3"
                            name="guardianFullName3" placeholder="Enter Name in Full">
                        </div>
                        <div class="form-group">
                          <label for="guardianShortName">Short Name (Insert full name starting with Title i.e.
                            Mr./Mrs./Ms/Dr, abbreviate only if over 30 characters) :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianShortName3"
                            name="guardianShortName3" placeholder="Enter Short Name">
                        </div>
                      </div>

                      <div class="col-sm-6">

                        <label style="margin-bottom: 30px;">:</label>
                        <div class="form-group">


                          <label for="guardianRelationship">Relationship with Nominee :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianRelationship3"
                            name="guardianRelationship3" placeholder="Enter Relationship with Nominee">
                        </div>
                        <div class="form-group">
                          <label for="guardianDateOfBirth">Date of Birth of Minor :</label>
                          <input type="date" class="form-control rounded-0 bg-light" id="guardianDateOfBirth3"
                            name="guardianDateOfBirth3">
                        </div>
                      </div>

                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianMaturityDate">Maturity Date of Minor :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianMaturityDate3"
                          name="guardianMaturityDate3">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianAddress">Address :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianAddress3"
                          name="guardianAddress3" placeholder="Enter Address">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianCity">City :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianCity3" name="guardianCity3"
                          placeholder="Enter City">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianPostCode">Post Code :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianPostCode3"
                          name="guardianPostCode3" placeholder="Enter Post Code">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianState">State/Division :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianState3"
                          name="guardianState3" placeholder="Enter State/Division">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianCountry">Country :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianCountry3"
                          name="guardianCountry3" placeholder="Enter Country">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianTelephone">Telephone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianTelephone3"
                          name="guardianTelephone3" placeholder="Enter Telephone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianMobilePhone">Mobile Phone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianMobilePhone3"
                          name="guardianMobilePhone3" placeholder="Enter Mobile Phone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianFax">Fax :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianFax3" name="guardianFax3"
                          placeholder="Enter Fax">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianEmail">Email :</label>
                        <input type="email" class="form-control rounded-0 bg-light" id="guardianEmail3"
                          name="guardianEmail3" placeholder="Enter Email">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianPassportNo">Passport No Grd :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianPassportNo3"
                          name="guardianPassportNo3" placeholder="Enter Passport No">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianNid">NID Grd :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianNid3" name="guardianNid3"
                          placeholder="Enter NID">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianIssuePlace">Issue Place :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianIssuePlace3"
                          name="guardianIssuePlace3" placeholder="Enter Issue Place">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianIssueDate">Issue Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianIssueDate3"
                          name="guardianIssueDate3">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianExpiryDate">Expiry Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianExpiryDate3"
                          name="guardianExpiryDate3">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianResidency">Residency Grd :</label>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="guardianResidencyResidentCheckbox"
                            name="guardianResidencyStatus" value="Resident"
                            onclick="handleResidencySelection('guardianResidencyResidentCheckbox')">
                          <label class="custom-control-label" for="guardianResidencyResidentCheckbox">Resident</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="guardianResidencyNonResidentCheckbox"
                            name="guardianResidencyStatus" value="NonResident"
                            onclick="handleResidencySelection('guardianResidencyNonResidentCheckbox')">
                          <label class="custom-control-label"
                            for="guardianResidencyNonResidentCheckbox">Non-Resident</label>
                        </div>
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianNationality">Nationality :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianNationality3"
                          name="guardianNationality3" placeholder="Enter Nationality">
                      </div>
                      <div class="form-group">
                        <label for="guardianDateOfBirth">Date of Birth :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianDateOfBirth3"
                          name="guardianDateOfBirth3">
                      </div>
                    </div>

                    <script>
                      function handleResidencySelection2(selectedCheckbox) {
                        const residencyResidentCheckbox = document.getElementById('residencyResidentCheckbox');
                        const residencyNonResidentCheckbox = document.getElementById('residencyNonResidentCheckbox');

                        if (selectedCheckbox === 'residencyResidentCheckbox') {
                          residencyNonResidentCheckbox.checked = false;
                        } else if (selectedCheckbox === 'residencyNonResidentCheckbox') {
                          residencyResidentCheckbox.checked = false;
                        }
                      }
                    </script>

                    <script>
                      function handleResidencySelection(selectedCheckbox) {
                        const guardianResidencyResidentCheckbox = document.getElementById('guardianResidencyResidentCheckbox');
                        const guardianResidencyNonResidentCheckbox = document.getElementById('guardianResidencyNonResidentCheckbox');
                        if (selectedCheckbox === 'guardianResidencyResidentCheckbox') {
                          guardianResidencyNonResidentCheckbox.checked = false;
                        } else if (selectedCheckbox === 'guardianResidencyNonResidentCheckbox') {
                          guardianResidencyResidentCheckbox.checked = false;
                        }
                      }
                    </script>
                  
                 
                    <div class="row">
                      <div class="col-sm-12">

                      </div>
                      <div style="margin-bottom: 50px;">
                        <h2>Nominee 2</h2>
                      </div>
                      <div class="col-sm-12">
                      </div>
                      <div class="col-sm-6">

                        <div class="form-group">
                          <label for="fullName">Full Name :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="fullName4" name="fullName4"
                            placeholder="Enter Full Name">
                        </div>
                        <div class="form-group">
                          <label for="shortName">Short Name (Insert full name starting with Title i.e. Mr./Mrs./Ms/Dr,
                            abbreviate only if over 30 characters) :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="shortName4" name="shortName4"
                            placeholder="Enter Short Name">
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="title">Title i.e. Mr./Mrs./Ms :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="title4" name="title4"
                            placeholder="Enter Title i.e Mr./Mrs./Ms">
                        </div>
                        <div class="form-group">
                          <label for="relationship">Relationship with Nominee :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="relationship4"
                            name="relationship4" placeholder="Enter Relationship with Nominee">
                        </div>
                      </div>

                      <div class="form-group" style="margin-right: 10px;">
                        <label for="percentage">Percentage (%) :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="percentage4" name="percentage4"
                          placeholder="Enter Percentage">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="address">Address :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="address4" name="address4"
                          placeholder="Enter Address">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="city">City :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="city4" name="city4"
                          placeholder="Enter City">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="postCode">Post Code :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="postCode4" name="postCode4"
                          placeholder="Enter Post Code">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="state">State/Division :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="state4" name="state4"
                          placeholder="Enter State/Division">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="country">Country :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="country4" name="country4"
                          placeholder="Enter Country">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="telephone">Telephone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="telephone4" name="telephone4"
                          placeholder="Enter Telephone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="mobilePhone">Mobile Phone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="mobilePhone4" name="mobilePhone4"
                          placeholder="Enter Mobile Phone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="fax">Fax :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="fax4" name="fax4"
                          placeholder="Enter Fax">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="email">Email :</label>
                        <input type="email" class="form-control rounded-0 bg-light" id="email4" name="email4"
                          placeholder="Enter Email">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="passportNo">Passport No :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="passportNo4" name="passportNo4"
                          placeholder="Enter Passport No">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="nid">NID :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="nid4" name="nid4"
                          placeholder="Enter NID">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="issuePlace">Issue Place :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="issuePlace4" name="issuePlace4"
                          placeholder="Enter Issue Place">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="issueDate">Issue Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="issueDate4" name="issueDate4">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="expiryDate">Expiry Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="expiryDate4" name="expiryDate4">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="residency">Residency :</label>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="residencyResidentCheckbox"
                            name="residencyStatus" value="Resident"
                            onclick="handleResidencySelection2('residencyResidentCheckbox')">
                          <label class="custom-control-label" for="residencyResidentCheckbox">Resident</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="residencyNonResidentCheckbox"
                            name="residencyStatus" value="NonResident"
                            onclick="handleResidencySelection2('residencyNonResidentCheckbox')">
                          <label class="custom-control-label" for="residencyNonResidentCheckbox">Non-Resident</label>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="nationality">Nationality :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="nationality4" name="nationality4"
                          placeholder="Enter Nationality">
                      </div>
                      <div class="form-group">
                        <label for="dateOfBirth">Date of Birth :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="dateOfBirth4" name="dateOfBirth4">
                      </div>
                    </div>

                    <!-- Guardian's Details (If Nominee is a Minor) -->
                    <div class="row">
                      <div class="col-sm-6"> <label style="font-weight: 1000;margin-bottom: 30px;"
                          for="DepositoryAccount">Guardian's Details (If Nominee is a Minor)</label>
                        <div class="form-group">
                          <label for="guardianFullName">Name in Full :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianFullName5"
                            name="guardianFullName5" placeholder="Enter Name in Full">
                        </div>
                        <div class="form-group">
                          <label for="guardianShortName">Short Name (Insert full name starting with Title i.e.
                            Mr./Mrs./Ms/Dr, abbreviate only if over 30 characters) :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianShortName5"
                            name="guardianShortName5" placeholder="Enter Short Name">
                        </div>
                      </div>

                      <div class="col-sm-6">

                        <label style="margin-bottom: 30px;">:</label>
                        <div class="form-group">


                          <label for="guardianRelationship">Relationship with Nominee :</label>
                          <input type="text" class="form-control rounded-0 bg-light" id="guardianRelationship5"
                            name="guardianRelationship5" placeholder="Enter Relationship with Nominee">
                        </div>
                        <div class="form-group">
                          <label for="guardianDateOfBirth">Date of Birth of Minor :</label>
                          <input type="date" class="form-control rounded-0 bg-light" id="guardianDateOfBirth5"
                            name="guardianDateOfBirth5">
                        </div>
                      </div>

                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianMaturityDate">Maturity Date of Minor :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianMaturityDate5"
                          name="guardianMaturityDate5">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianAddress">Address :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianAddress5"
                          name="guardianAddress5" placeholder="Enter Address">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianCity">City :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianCity5" name="guardianCity5"
                          placeholder="Enter City">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianPostCode">Post Code :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianPostCode5"
                          name="guardianPostCode5" placeholder="Enter Post Code">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianState">State/Division :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianState5"
                          name="guardianState5" placeholder="Enter State/Division">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianCountry">Country :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianCountry5"
                          name="guardianCountry5" placeholder="Enter Country">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianTelephone">Telephone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianTelephone5"
                          name="guardianTelephone5" placeholder="Enter Telephone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianMobilePhone">Mobile Phone :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianMobilePhone5"
                          name="guardianMobilePhone5" placeholder="Enter Mobile Phone">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianFax">Fax :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianFax5" name="guardianFax5"
                          placeholder="Enter Fax">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianEmail">Email :</label>
                        <input type="email" class="form-control rounded-0 bg-light" id="guardianEmail5"
                          name="guardianEmail5" placeholder="Enter Email">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianPassportNo">Passport No Grd :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianPassportNo5"
                          name="guardianPassportNo5" placeholder="Enter Passport No">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianNid">NID Grd :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianNid5" name="guardianNid5"
                          placeholder="Enter NID">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianIssuePlace">Issue Place :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianIssuePlace5"
                          name="guardianIssuePlace5" placeholder="Enter Issue Place">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianIssueDate">Issue Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianIssueDate5"
                          name="guardianIssueDate5">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianExpiryDate">Expiry Date :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianExpiryDate5"
                          name="guardianExpiryDate5">
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianResidency">Residency Grd :</label>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="guardianResidencyResidentCheckbox"
                            name="guardianResidencyStatus" value="Resident"
                            onclick="handleResidencySelection('guardianResidencyResidentCheckbox')">
                          <label class="custom-control-label" for="guardianResidencyResidentCheckbox">Resident</label>
                        </div>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="guardianResidencyNonResidentCheckbox"
                            name="guardianResidencyStatus" value="NonResident"
                            onclick="handleResidencySelection('guardianResidencyNonResidentCheckbox')">
                          <label class="custom-control-label"
                            for="guardianResidencyNonResidentCheckbox">Non-Resident</label>
                        </div>
                      </div>
                      <div class="form-group" style="margin-right: 10px;">
                        <label for="guardianNationality">Nationality :</label>
                        <input type="text" class="form-control rounded-0 bg-light" id="guardianNationality"
                          name="guardianNationality" placeholder="Enter Nationality">
                      </div>
                      <div class="form-group">
                        <label for="guardianDateOfBirth">Date of Birth :</label>
                        <input type="date" class="form-control rounded-0 bg-light" id="guardianDateOfBirth"
                          name="guardianDateOfBirth">
                      </div>
                    </div>

                    <script>
                      function handleResidencySelection2(selectedCheckbox) {
                        const residencyResidentCheckbox = document.getElementById('residencyResidentCheckbox');
                        const residencyNonResidentCheckbox = document.getElementById('residencyNonResidentCheckbox');

                        if (selectedCheckbox === 'residencyResidentCheckbox') {
                          residencyNonResidentCheckbox.checked = false;
                        } else if (selectedCheckbox === 'residencyNonResidentCheckbox') {
                          residencyResidentCheckbox.checked = false;
                        }
                      }
                    </script>

                    <script>
                      function handleResidencySelection(selectedCheckbox) {
                        const guardianResidencyResidentCheckbox = document.getElementById('guardianResidencyResidentCheckbox');
                        const guardianResidencyNonResidentCheckbox = document.getElementById('guardianResidencyNonResidentCheckbox');
                        if (selectedCheckbox === 'guardianResidencyResidentCheckbox') {
                          guardianResidencyNonResidentCheckbox.checked = false;
                        } else if (selectedCheckbox === 'guardianResidencyNonResidentCheckbox') {
                          guardianResidencyResidentCheckbox.checked = false;
                        }
                      }
                    </script>
                     <div class="col-sm-12">

                     </div>
                     <div class="form-footer pt-5 border-top" style="margin-bottom: 50px;">
                       <h2>Photograph</h2>
                     </div>
                     <div class="col-sm-12">

                     </div>
                     <div class="col-sm-120">
                       <div class="form-group">
                         <table class="table table-bordered">
                           <thead>
                             <tr>
                               <th scope="col">1st Applicant Signatory in case of Ltd. Co.</th>
                               <th scope="col">2nd Applicant Signatory in case of Ltd. Co.</th>
                               <th scope="col">Authorized Signatory in case of Ltd. Co</th>
                               <th scope="col">Guardian 2 Photograph</th>
                             </tr>
                           </thead>
                           <tbody>
                             <tr>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <span id="selectedFileName1" style="display: none;">No file selected</span>
                                   </div>
                                   <div style="text-align: center; margin-top: 20px;">
                                     <img id="previewImage1" src="#" alt="Selected Image"
                                       style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                   </div>
                                 </div>
                               </td>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <span id="selectedFileName2" style="display: none;">No file selected</span>
                                   </div>
                                   <div style="text-align: center; margin-top: 20px;">
                                     <img id="previewImage2" src="#" alt="Selected Image"
                                       style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                   </div>
                                 </div>
                               </td>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <span id="selectedFileName3" style="display: none;">No file selected</span>
                                   </div>
                                   <div style="text-align: center; margin-top: 20px;">
                                     <img id="previewImage3" src="#" alt="Selected Image"
                                       style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                   </div>
                                 </div>
                               </td>
                               <td>
                                <div
                                  style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                  <div style="position: relative; display: inline-block;">
                                    <span id="selectedFileName4" style="display: none;">No file selected</span>
                                  </div>
                                  <div style="text-align: center; margin-top: 20px;">
                                    <img id="previewImage4" src="#" alt="Selected Image"
                                      style="width: 150px; height: 100px; border: 1px solid #ccc; border-radius: 5px;" />
                                  </div>
                                </div>
                              </td>
                             </tr>
                             <tr>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <input type="file" id="imageInput1" accept="image/*" style="display: none;" />
                                     <label for="imageInput1"
                                       style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                       Image</label>
                                     <span id="selectedFileName1" style="display: none;">No file selected</span>
                                     <button id="clearImageBtn1"
                                       style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                       Image</button>
                                   </div>
                                 </div>
                               </td>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <input type="file" id="imageInput2" accept="image/*" style="display: none;" />
                                     <label for="imageInput2"
                                       style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                       Image</label>
                                     <span id="selectedFileName2" style="display: none;">No file selected</span>
                                     <button id="clearImageBtn2"
                                       style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                       Image</button>
                                   </div>
                                 </div>
                               </td>
                               <td>
                                 <div
                                   style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                   <div style="position: relative; display: inline-block;">
                                     <input type="file" id="imageInput3" accept="image/*" style="display: none;" />
                                     <label for="imageInput3"
                                       style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                       Image</label>
                                     <span id="selectedFileName3" style="display: none;">No file selected</span>
                                     <button id="clearImageBtn3"
                                       style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                       Image</button>
                                   </div>
                                 </div>
                               </td>
                               <td>
                                <div
                                  style="font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 10vh; margin: 0;">
                                  <div style="position: relative; display: inline-block;">
                                    <input type="file" id="imageInput4" accept="image/*" style="display: none;" />
                                    <label for="imageInput4"
                                      style="display: inline-block; background-color: #fd7151; color: #fff; padding: 4px 8px; cursor: pointer; border-radius: 5px; transition: background-color 0.3s ease; font-size: 14px;">Browse
                                      Image</label>
                                    <span id="selectedFileName4" style="display: none;">No file selected</span>
                                    <button id="clearImageBtn4"
                                      style="display: none; margin-top: 10px; background-color: #e74c3c; color: #fff; padding: 4px 8px; border: none; border-radius: 5px; cursor: pointer;">Clear
                                      Image</button>
                                  </div>
                                </div>
                              </td>
                             </tr>
                           </tbody>
                         </table>

                         <script>
                          // ... (existing code)
                        
                          // Function to handle the image input change and display the preview image for Guardian 2
                          function handleImageInputChange(inputId, previewId, fileNameId) {
                            const input = document.getElementById(inputId);
                            const previewImage = document.getElementById(previewId);
                            input.addEventListener('change', function(event) {
                              const file = event.target.files[0];
                              const reader = new FileReader();
                              reader.onload = function() {
                                previewImage.src = reader.result;
                                document.getElementById('clearImageBtn' + inputId.slice(-1)).style.display = 'block';
                              };
                              if (file) {
                                reader.readAsDataURL(file);
                              }
                            });
                            // Function to handle the "Clear Image" button
                            document.getElementById('clearImageBtn' + inputId.slice(-1)).addEventListener('click', function(event) {
                              event.preventDefault(); // Prevent the default form submission behavior
                              previewImage.src = '#';
                              input.value = '';
                              document.getElementById('clearImageBtn' + inputId.slice(-1)).style.display = 'none';
                            });
                          }
                        
                          // Call the function for each input element and preview image
                          handleImageInputChange('imageInput1', 'previewImage1', 'selectedFileName1');
                          handleImageInputChange('imageInput2', 'previewImage2', 'selectedFileName2');
                          handleImageInputChange('imageInput3', 'previewImage3', 'selectedFileName3');
                          handleImageInputChange('imageInput4', 'previewImage4', 'selectedFileName4'); // Call the function for Guardian 2 photograph
                        </script>
                        

                       </div>
                     </div>
                     <div class="col-sm-120">

                       <div class="form-group">
                         <label for="Declaration"></label>

                         <table class="table table-bordered">
                           <thead>
                             <tr>
                               <th scope="col"></th>
                               <th scope="col">Name</th>
                               <th scope="col">Signature</th>
                               <th scope="col">Date</th>
                             </tr>
                           </thead>
                           <tbody>
                             <tr>
                               <td>Nominee/Heir 1</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="firstAccName1"
                                   placeholder="" name="firstAccName1">
                               </td>
                               <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturFirst1"
                                   placeholder="" name="signaturFirst1"><input type="file" class="form-control-file"
                                   id="exampleFormControlFile1"></td>
                               </td>
                               <td> <input type="date" class="form-control rounded-0 bg-light" id="dateFirstSig1"
                                   placeholder="" name="dateFirstSig1"></td>
                               </td>
                             </tr>
                             <tr>
                               <td>Guardian 1</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="secondAccName2"
                                   placeholder="" name="secondAccName2">
                               </td>
                               <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturSecond2"
                                   placeholder="" name="signaturSecond2"><input type="file" class="form-control-file"
                                   id="exampleFormControlFile1"></td>
                               </td>
                               <td> <input type="date" class="form-control rounded-0 bg-light" id="dateSecondSig2"
                                   placeholder="" name="dateSecondSig2"></td>
                               </td>
                             </tr>
                             <tr>
                               <td>Nominee/Heir 2</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="thirdAccName3"
                                   placeholder="" name="thirdAccName3">
                               </td>
                               <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturThird3"
                                   placeholder="" name="signaturThird3">
                                 <input type="file" class="form-control-file" id="exampleFormControlFile1">
                               </td>
                               </td>
                               <td> <input type="date" class="form-control rounded-0 bg-light" id="dateThirdSig3"
                                   placeholder="" name="dateThirdSig3"></td>
                               </td>
                             </tr>
                             <tr>
                              <td>Guardian 2</td>
                              <td>
                                <input type="text" class="form-control rounded-0 bg-light" id="thirdAccName4"
                                  placeholder="" name="thirdAccName4">
                              </td>
                              <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturThird4"
                                  placeholder="" name="signaturThird4">
                                <input type="file" class="form-control-file" id="exampleFormControlFile1">
                              </td>
                              </td>
                              <td> <input type="date" class="form-control rounded-0 bg-light" id="dateThirdSig4"
                                  placeholder="" name="dateThirdSig4"></td>
                              </td>
                            </tr>
                            <tr>
                              <td>First Account Holder</td>
                              <td>
                                <input type="text" class="form-control rounded-0 bg-light" id="thirdAccName5"
                                  placeholder="" name="thirdAccName5">
                              </td>
                              <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturThird5"
                                  placeholder="" name="signaturThird5">
                                <input type="file" class="form-control-file" id="exampleFormControlFile1">
                              </td>
                              </td>
                              <td> <input type="date" class="form-control rounded-0 bg-light" id="dateThirdSig5"
                                  placeholder="" name="dateThirdSig5"></td>
                              </td>
                            </tr>
                            <tr>
                              <td>Second Account Holder</td>
                              <td>
                                <input type="text" class="form-control rounded-0 bg-light" id="thirdAccName6"
                                  placeholder="" name="thirdAccName6">
                              </td>
                              <td> <input type="text" class="form-control rounded-0 bg-light" id="signaturThird6"
                                  placeholder="" name="signaturThird6">
                                <input type="file" class="form-control-file" id="exampleFormControlFile1">
                              </td>
                              </td>
                              <td> <input type="date" class="form-control rounded-0 bg-light" id="dateThirdSig6"
                                  placeholder="" name="dateThirdSig6"></td>
                              </td>
                            </tr>
                           </tbody>
                         </table>
                    <div class="form-footer pt-5 border-top">
                      <button type="submit" class="btn btn-secondary btn-pill" id="submitFirstApplicant">submit</button>

                      <button type="submit" class="btn btn-light btn-pill">Cancel</button>

                    </div>
                  </form>
                </div>
              </div>


              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
  </div>
  </div>

  </div>

  </div>

  </div>

  <!-- Footer -->
  <footer class="footer mt-auto">
    <div class="copyright bg-white">
      <p>
        Noushin Nurjahan
      </p>
    </div>
    <script>
      var d = new Date();
      var year = d.getFullYear();
      document.getElementById("copy-year").innerHTML = year;
    </script>
  </footer>

  </div>
  </div>

  <!-- Card Offcanvas -->
  <div class="card card-offcanvas" id="contact-off">
    <div class="card-header">
      <h2>SideBar ItemRight</h2>
      <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
    </div>
    <div class="card-body">

      <div class="mb-4">
        <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
          placeholder="Search Item...">
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">


        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

    </div>
  </div>

  <script src="plugins/jquery/jquery.min.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="plugins/simplebar/simplebar.min.js"></script>
  <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

  <script src="plugins/prism/prism.js"></script>

  <script src="js/mono.js"></script>
  <script src="js/chart.js"></script>
  <script src="js/map.js"></script>
  <script src="js/custom.js"></script>

  <!--  -->

</body>

</html>