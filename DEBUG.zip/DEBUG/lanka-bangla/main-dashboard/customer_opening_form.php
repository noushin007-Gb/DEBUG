   <?php
   session_start();
   // Check if the user is logged in, if not then redirect him to the login page
   if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
     header("location: customer_opening_form.php");
     exit;
   }
   require_once "connection.php";
   $Client_CODE = $_SESSION["Client_CODE"];
   $Fill_up_DATE_err = "";
   $nameOfTheCustomer1_err = "";
   $dateOfBirth_err = "";
   $father_or_husband_name1_err = "";
   $mother_name1_err = "";
   $email_id1_err = "";
   $genderType1_err = "";
   $presentAddress1_err = "";
   $nid1_err = "";
   $mobile_number1_err = "";
   $natonality_1AccH_err = "";
   $permanentAddress1_err = "";
   $telephone_number1_err = "";
   $occupation1_err = "";
   $electronic_taxpayer1_err = "";
   // Handle Fill-up Date Form Submission
   if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["fillUpDate"])) {
     $Fill_up_DATE = trim($_POST["fillUpDate"]);
     // Validate Fill-up Date
     if (empty($Fill_up_DATE)) {
       $Fill_up_DATE_err = "Enter Date ";
     } else {
       // Check if the Client_CODE already exists
       $checkQuery = "SELECT Client_CODE FROM customer_info_date_client_form WHERE Client_CODE = ?";
       if ($checkStmt1 = mysqli_prepare($link, $checkQuery)) {
         mysqli_stmt_bind_param($checkStmt1, "s", $Client_CODE);
         mysqli_stmt_execute($checkStmt1);
         mysqli_stmt_store_result($checkStmt1);
         if (mysqli_stmt_num_rows($checkStmt1) == 0) {
           // Prepare an insert statement
           $insertQuery1 = "INSERT INTO customer_info_date_client_form (FillupDate, Client_CODE) VALUES (?, ?)";
           if ($insertStmt1 = mysqli_prepare($link, $insertQuery1)) {
             mysqli_stmt_bind_param($insertStmt1, "ss", $Fill_up_DATE, $Client_CODE);
             // Attempt to execute the prepared statement
             if (mysqli_stmt_execute($insertStmt1)) {
               // Redirect to the appropriate page
               header("location: customer_opening_form.php");
               exit();
             } else {
               echo "Something went wrong. Please try again later.";
             }
             // Close statement
             mysqli_stmt_close($insertStmt1);
           }
         } else {
           $errorMessage = "ClientCODE already exists     ";
           $displayError = true; // Set this based on your error condition
         }
         mysqli_stmt_close($checkStmt1);
       }
     }
   }
   // Handle First Account Holder Form Submission
   if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nameOfTheCustomer1"])) {
     // Extract and sanitize form data for the first account holder
     $nameOfTheCustomer1 = trim($_POST["nameOfTheCustomer1"]);
     $dateOfBirth = trim($_POST["dateOfBirth"]);
     $father_or_husband_name1 = trim($_POST["father_or_husband_name1"]);
     $mother_name1 = trim($_POST["mother_name1"]);
     $email_id1 = trim($_POST["email_id1"]);
     $genderType1 = isset($_POST["genderType1"]) ? $_POST["genderType1"] : '';
     $presentAddress1 = trim($_POST["presentAddress1"]);
     $nid1 = trim($_POST["nid1"]);
     $mobile_number1 = trim($_POST["mobile_number1"]);
     $natonality_1AccH = trim($_POST["natonality_1AccH"]);
     $permanentAddress1 = trim($_POST["permanentAddress1"]);
     $telephone_number1 = trim($_POST["telephone_number1"]);
     $occupation1 = trim($_POST["occupation1"]);
     $electronic_taxpayer1 = trim($_POST["electronic_taxpayer1"]);
     if (empty($nameOfTheCustomer1)) {
       $nameOfTheCustomer1_err = "Enter Name.";
     } elseif (strlen($nameOfTheCustomer1) > 30) {
       $nameOfTheCustomer1_err = "Name should have 30 characters or less.";
     }
     if (empty($dateOfBirth)) {
       $dateOfBirth_err = "Enter Date of Birth.";
     }
     if (empty($father_or_husband_name1)) {
       $father_or_husband_name1_err = "Enter Father/Husband Name.";
     } elseif (strlen($father_or_husband_name1) > 30) {
       $father_or_husband_name1_err = "Father/Husband Name should have 30 characters or less.";
     }
     if (empty($mother_name1)) {
       $mother_name1_err = "Enter Mother's Name.";
     } elseif (strlen($mother_name1) > 30) {
       $mother_name1_err = "Mother's Name should have 30 characters or less.";
     }
     if (empty($email_id1)) {
       $email_id1_err = "Enter Email.";
     } elseif (strlen($email_id1) > 50) {
       $email_id1_err = "Email should have 50 characters or less.";
     }
     if (empty($natonality_1AccH)) {
       $natonality_1AccH_err = "Enter Nationality.";
     } elseif (strlen($natonality_1AccH) > 25) {
       $natonality_1AccH_err = "Nationality should have 25 characters or less.";
     }
     if (empty($genderType1)) {
       $genderType1_err = "Select Gender.";
     }
     if (empty($presentAddress1)) {
       $presentAddress1_err = "Enter Present Address.";
     } elseif (strlen($presentAddress1) > 60) {
       $presentAddress1_err = "Present Address should have 60 characters or less.";
     }
     if (empty($permanentAddress1)) {
       $permanentAddress1_err = "Enter Permanent Address.";
     } elseif (strlen($permanentAddress1) > 60) {
       $permanentAddress1_err = "Permanent Address should have 60 characters or less.";
     }
     if (!empty($nid1) && !preg_match('/^\d{11}(\d{6})?$/', $nid1)) {
       $nid1_err = "Enter a valid NID (11 or 17 digits).";
     }
     if (!empty($telephone_number1) && (!is_numeric($telephone_number1) || strlen($telephone_number1) !== 11)) {
       $telephone_number1_err = "Enter a valid telephone number (11 digits).";
     }
     if (!empty($mobile_number1) && (!is_numeric($mobile_number1) || strlen($mobile_number1) !== 11)) {
       $mobile_number1_err = "Enter a valid mobile number (11 digits).";
     }
     if (empty($occupation1)) {
       $occupation1_err = "Enter Occupation.";
     } elseif (strlen($occupation1) > 50) {
       $occupation1_err = "Occupation should have 50 characters or less.";
     }
     if (empty($electronic_taxpayer1) && (!is_numeric($electronic_taxpayer1)) || !preg_match('/^\d{1,15}$/', $electronic_taxpayer1)) {
       $electronic_taxpayer1_err = "Enter a valid electronic taxpayer ID (up to 15 digits).";
     }
     if (
       empty($nameOfTheCustomer1_err) && empty($dateOfBirth_err) &&
       empty($father_or_husband_name1_err) && empty($mother_name1_err) && empty($email_id1_err) &&
       empty($genderType1_err) && empty($presentAddress1_err) && empty($nid1_err) &&
       empty($mobile_number1_err) && empty($natonality_1AccH_err) && empty($permanentAddress1_err) &&
       empty($telephone_number1_err) && empty($occupation1_err) && empty($electronic_taxpayer1_err)
     ) {
       $checkQuery2 = "SELECT Client_CODE FROM customer_info_first_account_holder WHERE Client_CODE = ?";
       if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
         mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
         mysqli_stmt_execute($checkStmt2);
         mysqli_stmt_store_result($checkStmt2);
         if (mysqli_stmt_num_rows($checkStmt2) == 0) {
           // Prepare and execute the insert statement for the first account holder's details
           $insertQuery2 = "INSERT INTO customer_info_first_account_holder (first_acc_h_Name, Client_CODE, Father_or_Husbands_Name, `Mother’s_Name`, Email, Nationality, Date_of_Birth, Sex, Present_Address, Permanent_Address, NID, Tel, Mobile, Occupation, E_tin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
             mysqli_stmt_bind_param($insertStmt2, "sssssssssssssss", $nameOfTheCustomer1, $Client_CODE, $father_or_husband_name1, $mother_name1, $email_id1, $natonality_1AccH, $dateOfBirth, $genderType1, $presentAddress1, $permanentAddress1, $nid1, $telephone_number1, $mobile_number1, $occupation1, $electronic_taxpayer1);
             if (mysqli_stmt_execute($insertStmt2)) {
               // Redirect to success page or display a success message
               $errorMessage = "Success!!!";
               $displayError = true; // Set this based on your error condition
   
             } else {
               echo "Something went wrong. Please try again later.";
             }
             mysqli_stmt_close($insertStmt2);
           }
         } else {
           $errorMessage = "You Have Already Filled Up F_ACC.";
           $displayError = true; // Set this based on your error condition
         }
       }
     }
   }
   // Handle joint Account Holder Form Submission
   if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nameOfTheCustomer2"])) {
     // Extract and sanitize form data for the joint account holder
     $nameOfTheCustomer2 = trim($_POST["nameOfTheCustomer2"]);
     $dateOfBirth2 = trim($_POST["dateOfBirth2"]);
     $father_or_husband_name2 = trim($_POST["father_or_husband_name2"]);
     $mother_name2 = trim($_POST["mother_name2"]);
     $email_id2 = trim($_POST["email_id2"]);
     $genderType2 = isset($_POST["genderType2"]) ? $_POST["genderType2"] : '';
     $presentAddress2 = trim($_POST["presentAddress2"]);
     $nid2 = trim($_POST["nid2"]);
     $mobile_number2 = trim($_POST["mobile_number2"]);
     $natonality_2AccH = trim($_POST["natonality_2AccH"]);
     $permanentAddress2 = trim($_POST["permanentAddress2"]);
     $telephone_number2 = trim($_POST["telephone_number2"]);
     $occupation2 = trim($_POST["occupation2"]);
     $electronic_taxpayer2 = trim($_POST["electronic_taxpayer2"]);
     if (empty($nameOfTheCustomer2)) {
       $nameOfTheCustomer2_err = "Enter Name.";
     } elseif (strlen($nameOfTheCustomer2) > 30) {
       $nameOfTheCustomer2_err = "Name should have 30 characters or less.";
     }
     if (empty($dateOfBirth2)) {
       $dateOfBirth_err2 = "Enter Date of Birth.";
     }
     if (empty($father_or_husband_name2)) {
       $father_or_husband_name2_err = "Enter Father/Husband Name.";
     } elseif (strlen($father_or_husband_name2) > 30) {
       $father_or_husband_name2_err = "Father/Husband Name should have 30 characters or less.";
     }
     if (empty($mother_name2)) {
       $mother_name2_err = "Enter Mother's Name.";
     } elseif (strlen($mother_name2) > 30) {
       $mother_name2_err = "Mother's Name should have 30 characters or less.";
     }
     if (empty($email_id2)) {
       $email_id2_err = "Enter Email.";
     } elseif (strlen($email_id2) > 50) {
       $email_id2_err = "Email should have 50 characters or less.";
     }
     if (empty($natonality_2AccH)) {
       $natonality_2AccH_err = "Enter Nationality.";
     } elseif (strlen($natonality_2AccH) > 25) {
       $natonality_2AccH_err = "Nationality should have 25 characters or less.";
     }
     if (empty($genderType2)) {
       $genderType2_err = "Select Gender.";
     }
     if (empty($presentAddress2)) {
       $presentAddress2_err = "Enter Present Address.";
     } elseif (strlen($presentAddress2) > 60) {
       $presentAddress2_err = "Present Address should have 60 characters or less.";
     }
     if (empty($permanentAddress2)) {
       $permanentAddress2_err = "Enter Permanent Address.";
     } elseif (strlen($permanentAddress2) > 60) {
       $permanentAddress2_err = "Permanent Address should have 60 characters or less.";
     }
     if (!empty($nid2) && !preg_match('/^\d{11}(\d{6})?$/', $nid2)) {
       $nid2_err = "Enter a valid NID (11 or 17 digits).";
     }
     if (!empty($telephone_number2) && (!is_numeric($telephone_number2) || strlen($telephone_number2) !== 11)) {
       $telephone_number2_err = "Enter a valid telephone number (11 digits).";
     }
     if (!empty($mobile_number2) && (!is_numeric($mobile_number2) || strlen($mobile_number2) !== 11)) {
       $mobile_number2_err = "Enter a valid mobile number (11 digits).";
     }
     if (empty($occupation2)) {
       $occupation2_err = "Enter Occupation.";
     } elseif (strlen($occupation2) > 50) {
       $occupation2_err = "Occupation should have 50 characters or less.";
     }
     if (empty($electronic_taxpayer2) && (!is_numeric($electronic_taxpayer2)) || !preg_match('/^\d{1,15}$/', $electronic_taxpayer2)) {
       $electronic_taxpayer2_err = "Enter a valid electronic taxpayer ID (up to 15 digits).";
     }
     if (
       empty($nameOfTheCustomer2_err) && empty($dateOfBirth_err2) &&
       empty($father_or_husband_name2_err) && empty($mother_name2_err) && empty($email_id2_err) &&
       empty($genderType2_err) && empty($presentAddress2_err) && empty($nid2_err) &&
       empty($mobile_number2_err) && empty($natonality_2AccH_err) && empty($permanentAddress2_err) &&
       empty($telephone_number2_err) && empty($occupation2_err) && empty($electronic_taxpayer2_err)
     ) {
       $checkQuery2 = "SELECT Client_CODE FROM customer_info_joint_account_holder WHERE Client_CODE = ?";
       if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
         mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
         mysqli_stmt_execute($checkStmt2);
         mysqli_stmt_store_result($checkStmt2);
         if (mysqli_stmt_num_rows($checkStmt2) == 0) {
           // Prepare and execute the insert statement for the joint account holder's details
           $insertQuery2 = "INSERT INTO customer_info_joint_account_holder (joint_acc_h_Name, Client_CODE, Father_or_Husbands_Name, `Mother’s_Name`, Email, Nationality, Date_of_Birth, Sex, Present_Address, Permanent_Address, NID, Tel, Mobile, Occupation, E_tin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
             mysqli_stmt_bind_param($insertStmt2, "sssssssssssssss", $nameOfTheCustomer2, $Client_CODE, $father_or_husband_name2, $mother_name2, $email_id2, $natonality_2AccH, $dateOfBirth2, $genderType2, $presentAddress2, $permanentAddress2, $nid2, $telephone_number2, $mobile_number2, $occupation2, $electronic_taxpayer2);
             if (mysqli_stmt_execute($insertStmt2)) {
               // Redirect to success page or display a success message
               $errorMessage = "Success!!!";
               $displayError = true; // Set this based on your error condition
             } else {
               echo "Something went wrong. Please try again later.";
             }
             mysqli_stmt_close($insertStmt2);
           }
         } else {
           $errorMessage = "You Have Already Filled Up J_ACC.";
           $displayError = true; // Set this based on your error condition
         }
       }
     }
   }
   if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nameOfTheCustomer3"])) {
     // Extract and sanitize form data for the first account holder
     $nameOfTheCustomer3 = trim($_POST["nameOfTheCustomer3"]);
     $dateOfBirth3 = trim($_POST["dateOfBirth3"]);
     $father_or_husband_name3 = trim($_POST["father_or_husband_name3"]);
     $mother_name3 = trim($_POST["mother_name3"]);
     $email_id3 = trim($_POST["email_id3"]);
     $genderType3 = isset($_POST["genderType3"]) ? $_POST["genderType3"] : '';
     $presentAddress3 = trim($_POST["presentAddress3"]);
     $nid3 = trim($_POST["nid3"]);
     $mobile_number3 = trim($_POST["mobile_number3"]);
     $natonality_3AccH = trim($_POST["natonality_3AccH"]);
     $permanentAddress3 = trim($_POST["permanentAddress3"]);
     $telephone_number3 = trim($_POST["telephone_number3"]);
     $occupation3 = trim($_POST["occupation3"]);
     $electronic_taxpayer3 = trim($_POST["electronic_taxpayer3"]);
     if (empty($nameOfTheCustomer3)) {
       $nameOfTheCustomer3_err = "Enter Name.";
     } elseif (strlen($nameOfTheCustomer3) > 30) {
       $nameOfTheCustomer3_err = "Name should have 30 characters or less.";

     }
     if (empty($dateOfBirth3)) {
       $dateOfBirth_err3 = "Enter Date of Birth.";
     }
     if (empty($father_or_husband_name3)) {
       $father_or_husband_name3_err = "Enter Father/Husband Name.";
     } elseif (strlen($father_or_husband_name3) > 30) {
       $father_or_husband_name3_err = "Father/Husband Name should have 30 characters or less.";
     }
     if (empty($mother_name3)) {
       $mother_name3_err = "Enter Mother's Name.";
     } elseif (strlen($mother_name3) > 30) {
       $mother_name3_err = "Mother's Name should have 30 characters or less.";
     }
     if (empty($email_id3)) {
       $email_id3_err = "Enter Email.";
     } elseif (strlen($email_id3) > 50) {
       $email_id3_err = "Email should have 50 characters or less.";
     }
     if (empty($natonality_3AccH)) {
       $natonality_3AccH_err = "Enter Nationality.";
     } elseif (strlen($natonality_3AccH) > 25) {
       $natonality_3AccH_err = "Nationality should have 25 characters or less.";
     }
     if (empty($genderType3)) {
       $genderType3_err = "Select Gender.";
     }
     if (empty($presentAddress3)) {
       $presentAddress3_err = "Enter Present Address.";
     } elseif (strlen($presentAddress3) > 60) {
       $presentAddress3_err = "Present Address should have 60 characters or less.";
     }
     if (empty($permanentAddress3)) {
       $permanentAddress3_err = "Enter Permanent Address.";
     } elseif (strlen($permanentAddress3) > 60) {
       $permanentAddress3_err = "Permanent Address should have 60 characters or less.";
     }
     if (!empty($nid3) && !preg_match('/^\d{11}(\d{6})?$/', $nid3)) {
       $nid3_err = "Enter a valid NID (11 or 17 digits).";
     }
     if (!empty($telephone_number3) && (!is_numeric($telephone_number3) || strlen($telephone_number3) !== 11)) {
       $telephone_number3_err = "Enter a valid telephone number (11 digits).";
     }
     if (!empty($mobile_number3) && (!is_numeric($mobile_number3) || strlen($mobile_number3) !== 11)) {
       $mobile_number3_err = "Enter a valid mobile number (11 digits).";
     }
     if (empty($occupation3)) {
       $occupation3_err = "Enter Occupation.";
     } elseif (strlen($occupation3) > 50) {
       $occupation3_err = "Occupation should have 50 characters or less.";
     }
     if (empty($electronic_taxpayer3) && (!is_numeric($electronic_taxpayer3)) || !preg_match('/^\d{1,15}$/', $electronic_taxpayer3)) {
       $electronic_taxpayer3_err = "Enter a valid electronic taxpayer ID (up to 15 digits).";
     }
     if (
       empty($nameOfTheCustomer3_err) && empty($dateOfBirth_err3) &&
       empty($father_or_husband_name3_err) && empty($mother_name3_err) && empty($email_id3_err) &&
       empty($genderType3_err) && empty($presentAddress3_err) && empty($nid3_err) &&
       empty($mobile_number3_err) && empty($natonality_3AccH_err) && empty($permanentAddress3_err) &&
       empty($telephone_number3_err) && empty($occupation3_err) && empty($electronic_taxpayer3_err)
     ) {
       $checkQuery2 = "SELECT Client_CODE FROM customer_info_authorized_account_holder WHERE Client_CODE = ?";
       if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
         mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
         mysqli_stmt_execute($checkStmt2);
         mysqli_stmt_store_result($checkStmt2);
         if (mysqli_stmt_num_rows($checkStmt2) == 0) {
           // Prepare and execute the insert statement for the first account holder's details
           $insertQuery2 = "INSERT INTO customer_info_authorized_account_holder (authorized_acc_h_Name, Client_CODE, Father_or_Husbands_Name, `Mother’s_Name`, Email, Nationality, Date_of_Birth, Sex, Present_Address, Permanent_Address, NID, Tel, Mobile, Occupation, E_tin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
             mysqli_stmt_bind_param($insertStmt2, "sssssssssssssss", $nameOfTheCustomer3, $Client_CODE, $father_or_husband_name3, $mother_name3, $email_id3, $natonality_3AccH, $dateOfBirth3, $genderType3, $presentAddress3, $permanentAddress3, $nid3, $telephone_number3, $mobile_number3, $occupation3, $electronic_taxpayer3);
             if (mysqli_stmt_execute($insertStmt2)) {
               // Redirect to success page or display a success message
               $errorMessage = "Success!!!";
               $displayError = true; // Set this based on your error condition
             } else {
               echo "Something went wrong. Please try again later.";
             }
             mysqli_stmt_close($insertStmt2);
           }
         } else {
           $errorMessage = "You Have Already Filled Up A_ACC.";
           $displayError = true; // Set this based on your error condition
         }
       }
     }
   }
   if (
     $_SERVER["REQUEST_METHOD"] == "POST" &&
     isset($_POST["bank_name"])
   ) {

     // Extract and sanitize form data for the first account holder
     $any_stock_exchange = isset($_POST["any_stock_exchange"]) ? $_POST["any_stock_exchange"] : '';
     $name_of_the_Stock_Comp = isset($_POST["name_of_the_Stock_Comp"]) ? trim($_POST["name_of_the_Stock_Comp"]) : '';
     // Handle image uploads
     // $signature_imageData = ''; // Initialize the image data variables
     $F_AccH_Signature_imageData = '';
     $J_AccH_Signature_imageData = '';
     $A_AccH_Signature_imageData = '';

     // if ($_FILES["signature_image"]["error"] == UPLOAD_ERR_OK) {
     //     $signature_imageData = file_get_contents($_FILES["signature_image"]["tmp_name"]);
     // }
     // Repeat the above for the other image fields (F_AccH_Signature, J_AccH_Signature, A_AccH_Signature)
   
     $bank_name = trim($_POST["bank_name"]);
     $branch_name = trim($_POST["branch_name"]);
     $account_No = trim($_POST["account_No"]);
     $routing_No = trim($_POST["routing_No"]);
     $F_AccH_Name2 = trim($_POST["F_AccH_Name2"]);
     $J_AccH_Name2 = trim($_POST["J_AccH_Name2"]);
     $A_AccH_Name2 = trim($_POST["A_AccH_Name2"]);
     $F_AccH_Signature_Date = trim($_POST["F_AccH_Signature_Date"]);
     $J_AccH_Signature_Date = trim($_POST["J_AccH_Signature_Date"]);
     $A_AccH_Signature_Date = trim($_POST["A_AccH_Signature_Date"]);

     if (empty($bank_name)) {
       $bank_name_err = "Enter Bank Name ";
     } elseif (strlen($bank_name) > 100) {
       $bank_name_err = "Bank Name should have 100 characters or less.";

     }

     if (empty($branch_name)) {
       $branch_name_err = "Enter Branch Name";
     } elseif (strlen($branch_name) > 40) {
       $branch_name_err = "Branch Name should have 40 characters or less.";
     }

     if (empty($account_No)) {
       $account_No_err = "Enter Account No";
     } elseif ((!is_numeric($account_No) || strlen($account_No) > 20 || strlen($account_No) < 10)) {
       $account_No_err = "Account Number should have 10 to 20 numbers.";
     }

     if (empty($routing_No)) {
       $routing_No_err = "Enter Routing No";
     } elseif ((!is_numeric($routing_No) || strlen($routing_No) > 20 || strlen($routing_No) < 10)) {
       $routing_No_err = "Routing Number should have 10 to 20 numbers.";
     }


     if (empty($F_AccH_Name2)) {
       $F_AccH_Name2_err = "Enter First Acc Name.";
     } elseif (strlen($F_AccH_Name2) > 25) {
       $F_AccH_Name2_err = "First Acc Name should have 30 characters or less.";
     }
     if (empty($J_AccH_Name2)) {
       $J_AccH_Name2_err = "Enter Joint Acc Name.";
     } elseif (strlen($J_AccH_Name2) > 25) {
       $J_AccH_Name2_err = "Joint Acc Name should have 30 characters or less.";
     }
     if (empty($A_AccH_Name2)) {
       $A_AccH_Name2_err = "Enter Auth/Manager Acc Name.";
     } elseif (strlen($A_AccH_Name2) > 25) {
       $A_AccH_Name2_err = "Auth Acc Name should have 30 characters or less.";
     }

     if (empty($any_stock_exchange)) {
       $any_stock_exchange_err = "Define Yes or NO";
     }
     if (empty($F_AccH_Signature_Date)) {
       $F_AccH_Signature_Date_err = "Enter Signature Date";
     }
     if (empty($F_AccH_Signature_Date)) {
       $J_AccH_Signature_Date_err = "Enter Signature Date";
     }
     if (empty($F_AccH_Signature_Date)) {
       $A_AccH_Signature_Date_err = "Enter Signature Date";
     }

     if (
       empty($bank_name_err) &&
       empty($any_stock_exchange_err) &&
       //  empty($signature_image_err) &&
       //  empty($F_AccH_Signature_image_err) && 
       //  empty($J_AccH_Signature_image_err) && 
       //  empty($A_AccH_Signature_image_err) &&
       empty($branch_name_err) &&
       empty($account_No_err) &&
       empty($routing_No_err) &&
       empty($F_AccH_Name2_err) &&
       empty($J_AccH_Name2_err) &&
       empty($A_AccH_Name2_err) &&
       empty($F_AccH_Signature_Date_err) &&
       empty($J_AccH_Signature_Date_err) &&
       empty($A_AccH_Signature_Date_err)
     ) {

       $checkQuery2 = "SELECT Client_CODE FROM customer_info_rest_of_info WHERE Client_CODE = ?";
       if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
         mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
         mysqli_stmt_execute($checkStmt2);
         mysqli_stmt_store_result($checkStmt2);

         if (isset($_POST['submit']) && mysqli_stmt_num_rows($checkStmt2) == 0) {
           // Prepare and execute the insert statement for the first account holder's details
           $signature_imageData = $_FILES['signature_image']['name'];
           $signature_TMPimageData = $_FILES['signature_image']['tmp_name'];
           $folder = "signatureFiles/";

           $F_AccH_Signature_imageData = $_FILES['F_AccH_Signature']['name'];
           $F_AccH_Signature_TMPimageData = $_FILES['F_AccH_Signature']['tmp_name'];

           $J_AccH_Signature_imageData = $_FILES['J_AccH_Signature']['name'];
           $J_AccH_Signature_TMPimageData = $_FILES['J_AccH_Signature']['tmp_name'];

           $A_AccH_Signature_imageData = $_FILES['A_AccH_Signature']['name'];
           $A_AccH_Signature_TMPimageData = $_FILES['A_AccH_Signature']['tmp_name'];

           move_uploaded_file($signature_TMPimageData, $folder . $signature_imageData);
           move_uploaded_file($F_AccH_Signature_TMPimageData, $folder . $F_AccH_Signature_imageData);
           move_uploaded_file($J_AccH_Signature_TMPimageData, $folder . $J_AccH_Signature_imageData);
           move_uploaded_file($A_AccH_Signature_TMPimageData, $folder . $A_AccH_Signature_imageData);

           $insertQuery2 = "INSERT INTO customer_info_rest_of_info (any_stock_exchange, Client_CODE, name_of_the_Stock_Comp, bank_name, branch_name, account_No, routing_No, F_AccH_Name, J_AccH_Name, A_AccH_Name, F_AccH_Signature_Date, J_AccH_Signature_Date, A_AccH_Signature_Date) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

           $insertQuery3 = "UPDATE customer_info_rest_of_info
                          SET signature_image = '$signature_imageData',
                              F_AccH_Signature = '$F_AccH_Signature_imageData',
                              J_AccH_Signature = '$J_AccH_Signature_imageData',
                              A_AccH_Signature = '$A_AccH_Signature_imageData'
                          WHERE Client_CODE = '$Client_CODE'";

           // Start a transaction
           mysqli_autocommit($link, false); // Disable auto-commit
   
           if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
             mysqli_stmt_bind_param(
               $insertStmt2,
               "sssssssssssss",
               $any_stock_exchange,
               $Client_CODE,
               $name_of_the_Stock_Comp,
               $bank_name,
               $branch_name,
               $account_No,
               $routing_No,
               $F_AccH_Name2,
               $J_AccH_Name2,
               $A_AccH_Name2,
               $F_AccH_Signature_Date,
               $J_AccH_Signature_Date,
               $A_AccH_Signature_Date
             );

             if (mysqli_stmt_execute($insertStmt2)) {
               $insertStmt2->close();

               // Insert the second part of data
               if ($insertStmt3 = mysqli_prepare($link, $insertQuery3)) {

                 $qry = mysqli_query($link, $insertQuery3);

                 if ($qry) {
                   mysqli_commit($link); // Commit the transaction
                   $signature_image_err = "Uploaded";
                   $errorMessage = "Success!!!";
                   $displayError = true; // Set this based on your error condition
                 } else {
                   mysqli_rollback($link); // Rollback the transaction
                   echo "Something went wrong. Please try again later.";
                 }

                 $insertStmt3->close();
               }
             } else {
               mysqli_rollback($link); // Rollback the transaction
               echo "Something went wrong. Please try again later.";
             }
           }
         } else {
           $errorMessage = "You Have Already Filled Up Rest Of the Info";
           $displayError = true; // Set this based on your error condition
         }

         $checkStmt2->close();
       }
     }
   }
   // Close the database connection
   mysqli_close($link);
   ?>
   <!DOCTYPE html>
   <html lang="en" dir="ltr">

   <head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
     <title>Fill Customer Info</title>
     <meta name="theme-name" content="mono" />
     <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
     <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
     <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
     <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
     <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
     <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
     <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
     <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
     <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
     <link id="main-css-href" rel="stylesheet" href="css/style.css" />
     <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
     <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css"
       type="text/css" />
     <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
       type="text/css" />
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
     <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
     <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
     <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>
     <style>
       .arrow-button {
         position: absolute;
         top: 10px;
         right: 20px;
       }

       .rotate {
         transform: rotate(180deg);
       }
     </style>
     <style>
       .hidden {
         display: none;
       }

       .custom-alert {
         position: relative;
         background-color: #187016;
         color: #fff;
         padding: 10px;
         width: 500px;
         border-radius: 5px;
       }

       .close-button {
         position: absolute;
         top: 5px;
         right: 5px;
         font-size: 20px;
         cursor: pointer;
         z-index: 1;
         padding-left: 5px;
         /* Ensure the cross is on top */
       }
     </style>

     <script>
       /* for alert box */
       document.addEventListener("DOMContentLoaded", function() {
         const errorDiv = document.getElementById("errorDiv");
         const closeButton = document.getElementById("closeButton");
         closeButton.addEventListener("click", function() {
           errorDiv.style.display = "none";
         });
         setTimeout(function() {
           errorDiv.style.display = "none";
         }, 3000);
       });
     </script>
     <script src="plugins/nprogress/nprogress.js"></script>
   </head>

   <body class="navbar-fixed sidebar-fixed" id="body">
     <script>
       NProgress.configure({
         showSpinner: false
       });
       NProgress.start();
     </script>
     <div id="toaster"></div>
     <div class="wrapper">
       <aside class="left-sidebar sidebar-light" id="left-sidebar">
         <div id="sidebar" class="sidebar sidebar-with-footer">
           <!-- Aplication Brand -->
           <div class="app-brand">
             <a href="#">
               <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
             </a>
           </div>
           <!-- begin sidebar scrollbar -->
           <div class="sidebar-left" data-simplebar style="height: 100%;">
             <!-- sidebar menu -->
             <ul class="nav sidebar-inner" id="sidebar-menu">
               <li>
                 <a class="sidenav-item-link" href="index.php">
                   <i class="mdi mdi-briefcase-account-outline"></i>
                   <span class="nav-text">Dashboard</span>
                 </a>
               </li>
               <li class="section-title">
                 Forms
               </li>
               <li class="active">
                 <a class="sidenav-item-link" href="customer_opening_form.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">ACCOUNT INFORMATION</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">CREDIT FACILITY</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="customer_BO_account_form.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">BO ACC. OPENING</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">BO ACC. NOMINATION</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="customer_POA.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">Power of Attorney (POA)</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="customer_application_for_terms_and_conditions_by_laws.php">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">Terms & Conditions</span>
                 </a>
               </li>

               <li>
                 <a class="sidenav-item-link" href="">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">EFT Enrollment</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">Signature Card</span>
                 </a>
               </li>
               <li>
                 <a class="sidenav-item-link" href="">
                   <i class="mdi mdi-account-edit"></i>
                   <span class="nav-text">Value Added Service</span>
                 </a>
               </li>
               <li class="section-title">
                 Pages
               </li>
               <li class="has-sub">
                 <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                   data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                   <i class="mdi mdi-account"></i>
                   <span class="nav-text">Authentication</span> <b class="caret"></b>
                 </a>
                 <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                   <div class="sub-menu">
                     <li>
                       <a class="sidenav-item-link" href="sign-in.html">
                         <span class="nav-text">Sign In</span>
                       </a>
                     </li>
                   </div>
                 </ul>
               </li>
               <li class="has-sub">
                 <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                   aria-expanded="false" aria-controls="other-page">
                   <i class="mdi mdi-file-multiple"></i>
                   <span class="nav-text">Other pages</span> <b class="caret"></b>
                 </a>
                 <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                   <div class="sub-menu">
                     <li>
                       <a class="sidenav-item-link" href="3">
                         <span class="nav-text">Nothing</span>
                       </a>
                     </li>
                   </div>
                 </ul>
               </li>
               <li class="section-title">
                 Documentation
               </li>
               <li>
                 <a class="sidenav-item-link" href="#">
                   <i class="mdi mdi-airplane"></i>
                   <span class="nav-text">Nothing</span>
                 </a>
               </li>
             </ul>
           </div>
           <div class="sidebar-footer">
             <div class="sidebar-footer-content">
               <ul class="d-flex">
                 <li>
                   <a href="#" data-toggle="tooltip" title="Profile settings"><i class="mdi mdi-settings"></i></a>
                 </li>
                 <li>
                   <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip" title="Logout"><i
                       class="mdi mdi-logout"></i></a>
                 </li>
               </ul>
             </div>
           </div>
         </div>
       </aside>
       <div class="page-wrapper">
         <!-- Header -->
         <header class="main-header" id="header">
           <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
             <!-- Sidebar toggle button -->
             <button id="sidebar-toggler" class="sidebar-toggle">
               <span class="sr-only">Toggle navigation</span>
             </button>
             <span class="page-title">Customer Dashboard</span>
             <div class="navbar-right ">
               <!-- search form -->
               <div class="search-form">
                 <form action="index.php" method="get">
                   <div class="input-group input-group-sm" id="input-group-search">
                     <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                       placeholder="Search..." />
                     <div class="input-group-append">
                       <button class="btn" type="button">/</button>
                     </div>
                   </div>
                 </form>
                 <ul class="dropdown-menu dropdown-menu-search">
                   <li class="nav-item">
                     <a class="nav-link" href="index.php"></a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="index.php"></a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="index.php"></a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="index.php"></a>
                   </li>
                 </ul>
               </div>
               <ul class="nav navbar-nav">
                 <!-- Offcanvas -->
                 <li class="custom-dropdown">
                   <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                     href="javascript:">
                     <i class="mdi mdi-contacts icon"></i>
                   </a>
                 </li>
                 <li class="custom-dropdown">
                   <button class="notify-toggler custom-dropdown-toggler">
                     <i class="mdi mdi-bell-outline icon"></i>
                     <span class="badge badge-xs rounded-circle">21</span>
                   </button>
                   <div class="dropdown-notify">
                     <header>
                       <div class="nav nav-underline" id="nav-tab" role="tablist">
                         <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                           aria-controls="nav-home" aria-selected="true">All (5)</a>
                         <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                           aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                         <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                           aria-controls="nav-contact" aria-selected="false">Others (3)</a>
                       </div>
                     </header>
                     <footer class="border-top dropdown-notify-footer">
                       <div class="d-flex justify-content-between align-items-center py-2 px-4">
                         <span>Last updated 3 min ago</span>
                         <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                       </div>
                     </footer>
                   </div>
                 </li>
                 <!-- User Account -->
                 <li class="dropdown user-menu">
                   <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                     <img
                       src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                       class="user-image rounded-circle" alt="User Image" />
                     <span class="d-none d-lg-inline-block"><b>
                         <?php echo htmlspecialchars($_SESSION["username"]); ?></i>
                       </b>
                       <b>
                         <?php echo htmlspecialchars($Client_CODE); ?>
                       </b></span>
                   </button>
                   <ul class="dropdown-menu dropdown-menu-right">
                     <li>
                       <a class="dropdown-link-item" href="#">
                         <i class="mdi mdi-settings"></i>
                         <span class="nav-text">Account Setting</span>
                       </a>
                     </li>
                     <li class="dropdown-footer">
                       <a class="dropdown-link-item" href="/debug/lanka-bangla/main-login/client_logout.php">
                         <i class="mdi mdi-logout"></i> Log Out </a>
                     </li>
                   </ul>
                 </li>
               </ul>
             </div>
           </nav>
         </header>
         <!-- ====================================
           ——— CONTENT WRAPPER
           ===================================== -->
         <div class="content-wrapper">
           <div class="content">
             <!-- For Components documentaion -->
             <div class="px-6 py-4">
               <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
               <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023,
                   Chittagong
                   Stock Exchange </span> </p>
               <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">CUSTOMER
                   ACCOUNT
                   INFORMATION FORM </span> </p>
               <div class="alert alert-dark <?php if (!$displayError)
                 echo 'hidden'; ?> custom-alert" role="alert" id="errorDiv">
                 <span class="close-button" id="closeButton">&times;</span>
                 <?php echo $errorMessage; ?>
               </div>
             </div>
             <div class="row">
               <div class="col-sm-10">
                 <!-- Custom Styles -->
                 <div class="card card-default">
                   <div class="card-header" id="cardHeader4">
                     <h2></h2>
                   </div>
                   <div class="card-body" id="custom-input4">
                     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"
                       enctype="multipart/form-data">
                       <div class="row">
                         <div class="col-sm-6">
                           <div class="form-group <?php echo (!empty($Fill_up_DATE_err)) ? 'has-error' : ''; ?>">
                             <label for="date">Date :</label>
                             <input type="date" class="form-control rounded-0 bg-light" id="fillUpDate"
                               name="fillUpDate">
                             <?php if (!empty($Fill_up_DATE_err)): ?>
                             <span class="text-danger">
                               <?php echo $Fill_up_DATE_err; ?>
                             </span>
                             <?php endif; ?>
                           </div>
                           <fieldset disabled>
                             <div class="form-group">
                               <label for="client_code">Client Code :</label>
                               <input type="text" class="form-control rounded-0 bg-light"
                                 placeholder=<?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?>>
                             </div>
                           </fieldset>
                         </div>
                         <div class="col-sm-6">
                           <div class="form-group">
                             <div class="px-6 py-4">[FILL UP THE FORM IN CAPITAL LETTERS]</div>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             </div>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             </div>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             </div>
                           </div>
                         </div>
                       </div>
                       <div class="form-footer pt-5 border-top">
                         <button type="submit" class="btn btn-secondary btn-pill"
                           id="submitDate&ClientCode">Next</button>
                         <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                       </div>
                     </form>
                   </div>
                 </div>
                 <!-- First Account Holder -->
                 <div class="card card-default">
                   <div class="card-header" id="cardHeader3">
                     <h2>First Account Holder</h2>
                     <button type="button" class="btn btn-link arrow-button3">
                       <i class="fas fa-chevron-down"></i>
                     </button>
                   </div>
                   <div class="card-body collapse" id="collapse-custom-input3">

                     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"
                       enctype="multipart/form-data">

                       <div class="row">
                         <div class="col-sm-6">
                           <div class="form-group">
                             <label for="nameOfTheCustomer">Name of the Customer :</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="nameOfTheCustomer1"
                               name="nameOfTheCustomer1" placeholder="Enter Name of the Customer">
                             <?php if (!empty($nameOfTheCustomer1_err)): ?>
                             <span class="text-danger"><?php echo $nameOfTheCustomer1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="dateOfBirth">Date Of Birth :</label>
                             <input type="date" class="form-control rounded-0 bg-light" id="dateOfBirth"
                               name="dateOfBirth">
                             <?php if (!empty($dateOfBirth_err)): ?>
                             <span class="text-danger"><?php echo $dateOfBirth_err; ?></span>
                             <?php endif; ?>
                           </div>
                         </div>
                         <div class="col-sm-6">
                           <div class="form-group">
                             <label for="father_or_husband_name">Father's/Husband's Name</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="father_or_husband_name1"
                               name="father_or_husband_name1" placeholder="Enter Father's/Husband's Name">
                             <?php if (!empty($father_or_husband_name1_err)): ?>
                             <span class="text-danger"><?php echo $father_or_husband_name1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="mother_name">Mother's Name :</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="mother_name1"
                               name="mother_name1" placeholder="Enter Mother's Name">
                             <?php if (!empty($mother_name1_err)): ?>
                             <span class="text-danger"><?php echo $mother_name1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="email_id">Email ID :</label>
                             <input type="email" class="form-control rounded-0 bg-light" id="email_id1" name="email_id1"
                               placeholder="Enter Email">
                             <span class="mt-2 d-block">We'll never share your email with anyone else.</span>
                             <?php if (!empty($email_id1_err)): ?>
                             <span class="text-danger"><?php echo $email_id1_err; ?></span>
                             <?php endif; ?>
                           </div>
                         </div>
                         <div class="col-sm-6">
                           <div class="form-group">
                             <label for="genderName">Sex : </label>
                             <div>
                             </div>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                               <input type="checkbox" class="custom-control-input" id="customCheckMale1"
                                 name="genderType1" value="Male">
                               <label class="custom-control-label" for="customCheckMale1">Male</label>
                             </div>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                               <input type="checkbox" class="custom-control-input" id="customCheckFemale1"
                                 name="genderType1" value="Female">
                               <label class="custom-control-label" for="customCheckFemale1">Female</label>
                             </div>
                             <?php if (empty($genderType1) && $_SERVER["REQUEST_METHOD"] === "POST"): ?>
                             <span class="text-danger">Please select a gender.</span>
                             <?php endif; ?>
                             <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3"></div>
                             <div class="form-group">
                               <label for="presentAddress">Present Address : </label>
                               <input type="text" class="form-control rounded-0 bg-light" id="presentAddress1"
                                 name="presentAddress1" placeholder=" Enter Present address">
                               <?php if (!empty($presentAddress1_err)): ?>
                               <span class="text-danger"><?php echo $presentAddress1_err; ?></span>
                               <?php endif; ?>
                             </div>
                             <div class="form-group">
                               <label for="nid">NID : </label>
                               <input type="text" class="form-control rounded-0 bg-light" id="nid1" name="nid1"
                                 placeholder="Enter NID No.">
                               <?php if (!empty($nid1_err)): ?>
                               <span class="text-danger"><?php echo $nid1_err; ?></span>
                               <?php endif; ?>
                             </div>
                             <div class="form-group">
                               <label for="mobile_number">Mobile : (+88)</label>
                               <input type="text" class="form-control rounded-0 bg-light" id="mobile_number1"
                                 name="mobile_number1" placeholder="Enter Mobile number">
                               <?php if (!empty($mobile_number1_err)): ?>
                               <span class="text-danger"><?php echo $mobile_number1_err; ?></span>
                               <?php endif; ?>
                             </div>
                           </div>
                         </div>
                         <script>
                           const maleCheckbox = document.getElementById("customCheckMale1");
                           const femaleCheckbox = document.getElementById("customCheckFemale1");
                           maleCheckbox.addEventListener("change", function() {
                             if (maleCheckbox.checked) {
                               femaleCheckbox.checked = false;
                             }
                           });
                           femaleCheckbox.addEventListener("change", function() {
                             if (femaleCheckbox.checked) {
                               maleCheckbox.checked = false;
                             }
                           });
                         </script>
                         <div class="col-sm-6">
                           <div class="form-group">
                             <label for="nationality">Nationality : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="natonality_1AccH"
                               name="natonality_1AccH" placeholder=" Enter Natonality">
                             <?php if (!empty($natonality_1AccH_err)): ?>
                             <span class="text-danger"><?php echo $natonality_1AccH_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="permanentAddress">Permanent Address : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="permanentAddress1"
                               name="permanentAddress1" placeholder=" Enter Permanent address">
                             <?php if (!empty($permanentAddress1_err)): ?>
                             <span class="text-danger"><?php echo $permanentAddress1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="telephone_number">Tel# :</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="telephone_number1"
                               name="telephone_number1" placeholder="Enter telephone number">
                             <?php if (!empty($telephone_number1_err)): ?>
                             <span class="text-danger"><?php echo $telephone_number1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="occupation">Occupation :</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="occupation1"
                               name="occupation1" placeholder="Occupation Details">
                             <?php if (!empty($occupation1_err)): ?>
                             <span class="text-danger"><?php echo $occupation1_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="electronic_taxpayer">E-Tin # : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="electronic_taxpayer1"
                               name="electronic_taxpayer1" placeholder="Enter Elc. Tax Payer No.">
                             <?php if (!empty($electronic_taxpayer1_err)): ?>
                             <span class="text-danger"><?php echo $electronic_taxpayer1_err; ?></span>
                             <?php elseif (empty($electronic_taxpayer1_err)): ?>
                             <span class="text">Tax payer number should 15 or less</span>
                             <?php endif; ?>
                           </div>
                         </div>
                         <div class="col-sm-6">
                         </div>
                       </div>
                       <div class="form-footer pt-5 border-top">
                         <button type="submit" class="btn btn-secondary btn-pill" id="submitFirstAccount">Next</button>
                         <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                       </div>

                   </div>
                 </div>
                 <!-- Joint Account Holder -->
                 <div class="card card-default">
                   <div class="card-header" id="cardHeader2">
                     <h2>Joint Account Holder</h2>
                     <button type="button" class="btn btn-link arrow-button2">
                       <i class="fas fa-chevron-down"></i>
                     </button>
                   </div>
                   <div class="card-body collapse" id="collapse-custom-input2">

                     <div class="row">
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="nameOfTheCustomer">Name of the Joint Account Holder :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="nameOfTheCustomer2"
                             name="nameOfTheCustomer2" placeholder="Enter Name of the Joint Acc. Holder">
                           <?php if (!empty($nameOfTheCustomer2_err)): ?>
                           <span class="text-danger"><?php echo $nameOfTheCustomer2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="dateOfBirth">Date Of Birth :</label>
                           <input type="date" class="form-control rounded-0 bg-light" id="dateOfBirth2"
                             name="dateOfBirth2">
                           <?php if (!empty($dateOfBirth_err2)): ?>
                           <span class="text-danger"><?php echo $dateOfBirth_err2; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="father_or_husband_name">Father's/Husband's Name</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="father_or_husband_name2"
                             name="father_or_husband_name2" placeholder="Enter Father's/Husband's Name">
                           <?php if (!empty($father_or_husband_name2_err)): ?>
                           <span class="text-danger"><?php echo $father_or_husband_name2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="mother_name">Mother's Name :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="mother_name2"
                             name="mother_name2" placeholder="Enter Mother's Name">
                           <?php if (!empty($mother_name2_err)): ?>
                           <span class="text-danger"><?php echo $mother_name2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="email_id">Email ID :</label>
                           <input type="email" class="form-control rounded-0 bg-light" id="email_id2" name="email_id2"
                             placeholder="Enter Email">
                           <span class="mt-2 d-block">We'll never share your email with anyone else.</span>
                           <?php if (!empty($email_id2_err)): ?>
                           <span class="text-danger"><?php echo $email_id2_err; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="genderName">Sex : </label>
                           <div>
                           </div>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckMale2"
                               name="genderType2" value="Male">
                             <label class="custom-control-label" for="customCheckMale2">Male</label>
                           </div>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckFemale2"
                               name="genderType2" value="Female">
                             <label class="custom-control-label" for="customCheckFemale2">Female</label>
                           </div>
                           <?php if (empty($genderType2) && $_SERVER["REQUEST_METHOD"] === "POST"): ?>
                           <span class="text-danger">Please select a gender.</span>
                           <?php endif; ?>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3"></div>
                           <div class="form-group">
                             <label for="presentAddress">Present Address : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="presentAddress2"
                               name="presentAddress2" placeholder=" Enter Present address">
                             <?php if (!empty($presentAddress2_err)): ?>
                             <span class="text-danger"><?php echo $presentAddress2_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="nid">NID : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="nid2" name="nid2"
                               placeholder="Enter NID No.">
                             <?php if (!empty($nid2_err)): ?>
                             <span class="text-danger"><?php echo $nid2_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="mobile_number">Mobile : (+88)</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="mobile_number2"
                               name="mobile_number2" placeholder="Enter Mobile number">
                             <?php if (!empty($mobile_number2_err)): ?>
                             <span class="text-danger"><?php echo $mobile_number2_err; ?></span>
                             <?php endif; ?>
                           </div>
                         </div>
                       </div>
                       <script>
                         const maleCheckbox2 = document.getElementById("customCheckMale2");
                         const femaleCheckbox2 = document.getElementById("customCheckFemale2");
                         maleCheckbox2.addEventListener("change", function() {
                           if (maleCheckbox2.checked) {
                             femaleCheckbox2.checked = false;
                           }
                         });
                         femaleCheckbox2.addEventListener("change", function() {
                           if (femaleCheckbox2.checked) {
                             maleCheckbox2.checked = false;
                           }
                         });
                       </script>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="nationality">Nationality : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="natonality_2AccH"
                             name="natonality_2AccH" placeholder=" Enter Natonality">
                           <?php if (!empty($natonality_2AccH_err)): ?>
                           <span class="text-danger"><?php echo $natonality_2AccH_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="permanentAddress">Permanent Address : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="permanentAddress2"
                             name="permanentAddress2" placeholder=" Enter Permanent address">
                           <?php if (!empty($permanentAddress2_err)): ?>
                           <span class="text-danger"><?php echo $permanentAddress2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="telephone_number">Tel# :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="telephone_number2"
                             name="telephone_number2" placeholder="Enter telephone number">
                           <?php if (!empty($telephone_number2_err)): ?>
                           <span class="text-danger"><?php echo $telephone_number2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="occupation">Occupation :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="occupation2"
                             name="occupation2" placeholder="Occupation Details">
                           <?php if (!empty($occupation2_err)): ?>
                           <span class="text-danger"><?php echo $occupation2_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="electronic_taxpayer">E-Tin # : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="electronic_taxpayer2"
                             name="electronic_taxpayer2" placeholder="Enter Elc. Tax Payer No.">
                           <?php if (!empty($electronic_taxpayer2_err)): ?>
                           <span class="text-danger"><?php echo $electronic_taxpayer2_err; ?></span>
                           <?php elseif (empty($electronic_taxpayer2_err)): ?>
                           <span class="text">Tax payer number should 15 or less</span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                       </div>
                     </div>
                     <div class="form-footer pt-5 border-top">
                       <button type="submit" class="btn btn-secondary btn-pill" id="submitJointAccount">Next</button>
                       <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                     </div>

                   </div>
                 </div>
                 <!-- Authorized Person Information -->
                 <div class="card card-default">
                   <div class="card-header" id="cardHeader1">
                     <h2>Authorized Person Information</h2>
                     <button type="button" class="btn btn-link arrow-button1">
                       <i class="fas fa-chevron-down"></i>
                     </button>
                   </div>
                   <div class="card-body collapse" id="collapse-custom-input1">

                     <div class="row">
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="nameOfTheCustomer">Name of the Authorized Person :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="nameOfTheCustomer3"
                             name="nameOfTheCustomer3" placeholder="Enter Name of the Auth. Person">
                           <?php if (!empty($nameOfTheCustomer3_err)): ?>
                           <span class="text-danger"><?php echo $nameOfTheCustomer3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="dateOfBirth">Date Of Birth :</label>
                           <input type="date" class="form-control rounded-0 bg-light" id="dateOfBirth3"
                             name="dateOfBirth3">
                           <?php if (!empty($dateOfBirth_err3)): ?>
                           <span class="text-danger"><?php echo $dateOfBirth_err3; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="father_or_husband_name">Father's/Husband's Name</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="father_or_husband_name3"
                             name="father_or_husband_name3" placeholder="Enter Father's/Husband's Name">
                           <?php if (!empty($father_or_husband_name3_err)): ?>
                           <span class="text-danger"><?php echo $father_or_husband_name3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="mother_name">Mother's Name :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="mother_name3"
                             name="mother_name3" placeholder="Enter Mother's Name">
                           <?php if (!empty($mother_name3_err)): ?>
                           <span class="text-danger"><?php echo $mother_name3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="email_id">Email ID :</label>
                           <input type="email" class="form-control rounded-0 bg-light" id="email_id3" name="email_id3"
                             placeholder="Enter Email">
                           <span class="mt-2 d-block">We'll never share your email with anyone else.</span>
                           <?php if (!empty($email_id3_err)): ?>
                           <span class="text-danger"><?php echo $email_id3_err; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="genderName">Sex : </label>
                           <div>
                           </div>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckMale3"
                               name="genderType3" value="Male">
                             <label class="custom-control-label" for="customCheckMale3">Male</label>
                           </div>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckFemale3"
                               name="genderType3" value="Female">
                             <label class="custom-control-label" for="customCheckFemale3">Female</label>
                           </div>
                           <?php if (empty($genderType3) && $_SERVER["REQUEST_METHOD"] === "POST"): ?>
                           <span class="text-danger">Please select a gender.</span>
                           <?php endif; ?>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3"></div>
                           <div class="form-group">
                             <label for="presentAddress">Present Address : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="presentAddress3"
                               name="presentAddress3" placeholder=" Enter Present address">
                             <?php if (!empty($presentAddress3_err)): ?>
                             <span class="text-danger"><?php echo $presentAddress3_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="nid">NID : </label>
                             <input type="text" class="form-control rounded-0 bg-light" id="nid3" name="nid3"
                               placeholder="Enter NID No.">
                             <?php if (!empty($nid3_err)): ?>
                             <span class="text-danger"><?php echo $nid3_err; ?></span>
                             <?php endif; ?>
                           </div>
                           <div class="form-group">
                             <label for="mobile_number">Mobile : (+88)</label>
                             <input type="text" class="form-control rounded-0 bg-light" id="mobile_number3"
                               name="mobile_number3" placeholder="Enter Mobile number">
                             <?php if (!empty($mobile_number3_err)): ?>
                             <span class="text-danger"><?php echo $mobile_number3_err; ?></span>
                             <?php endif; ?>
                           </div>
                         </div>
                       </div>
                       <script>
                         const maleCheckbox3 = document.getElementById("customCheckMale3");
                         const femaleCheckbox3 = document.getElementById("customCheckFemale3");
                         maleCheckbox3.addEventListener("change", function() {
                           if (maleCheckbox3.checked) {
                             femaleCheckbox3.checked = false;
                           }
                         });
                         femaleCheckbox3.addEventListener("change", function() {
                           if (femaleCheckbox3.checked) {
                             maleCheckbox3.checked = false;
                           }
                         });
                       </script>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="nationality">Nationality : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="natonality_3AccH"
                             name="natonality_3AccH" placeholder=" Enter Natonality">
                           <?php if (!empty($natonality_3AccH_err)): ?>
                           <span class="text-danger"><?php echo $natonality_3AccH_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="permanentAddress">Permanent Address : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="permanentAddress3"
                             name="permanentAddress3" placeholder=" Enter Permanent address">
                           <?php if (!empty($permanentAddress3_err)): ?>
                           <span class="text-danger"><?php echo $permanentAddress3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="telephone_number">Tel# :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="telephone_number3"
                             name="telephone_number3" placeholder="Enter telephone number">
                           <?php if (!empty($telephone_number3_err)): ?>
                           <span class="text-danger"><?php echo $telephone_number3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="occupation">Occupation :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="occupation3"
                             name="occupation3" placeholder="Occupation Details">
                           <?php if (!empty($occupation3_err)): ?>
                           <span class="text-danger"><?php echo $occupation3_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="electronic_taxpayer">E-Tin # : </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="electronic_taxpayer3"
                             name="electronic_taxpayer3" placeholder="Enter Elc. Tax Payer No.">
                           <?php if (!empty($electronic_taxpayer3_err)): ?>
                           <span class="text-danger"><?php echo $electronic_taxpayer3_err; ?></span>
                           <?php elseif (empty($electronic_taxpayer3_err)): ?>
                             <span class="text">Tax payer number should 15 or less</span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                       </div>
                     </div>
                     <div class="form-footer pt-5 border-top">
                       <button type="submit" class="btn btn-secondary btn-pill" id="submitAuthAccount">Next</button>
                       <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                     </div>

                   </div>
                 </div>

                 <!-- Rest Of Information -->
                 <div class="card card-default">
                   <div class="card-body">

                     <div class="row">
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="AccountType">Officer or Director or Spnosor Shareholder of any Stock
                             Exchange
                             Listed Comp </label>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckYes5"
                               name="any_stock_exchange" value="Yes">
                             <label class="custom-control-label" for="customCheckYes5">Yes</label>
                           </div>
                           <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                             <input type="checkbox" class="custom-control-input" id="customCheckNo5"
                               name="any_stock_exchange" value="No">
                             <label class="custom-control-label" for="customCheckNo5">No</label>
                           </div>
                           <?php if (empty($any_stock_exchange) && $_SERVER["REQUEST_METHOD"] === "POST"): ?>
                           <span class="text-danger">Please select a Yes or No.</span>
                           <?php endif; ?>
                           <div class="form-group">
                             <label for="Signature">Signature :</label>
                             <fieldset disabled>
                               <input type="text" class="form-control rounded-0 bg-light" id="temp4"
                                 placeholder="Signature" name="temp4">
                             </fieldset>
                             <input type="file" class="form-control-file" name="signature_image" id="signature_image">
                             <?php if (!empty($signature_image_err)): ?>
                             <span class="text-danger"><?php echo $signature_image_err; ?></span>
                             <?php endif; ?>
                           </div>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="name_of_the_Stock_Comp">If yes, Name of the Stock Exchange/Listed Company
                           </label>
                           <input type="text" class="form-control rounded-0 bg-light" id="name_of_the_Stock_Comp"
                             placeholder="Enter Company name" name="name_of_the_Stock_Comp">
                         </div>
                         <div class="form-group">
                           <label for="bank_name">Bank Name :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="bank_name"
                             placeholder="Enter Bank Name" name="bank_name">
                           <?php if (!empty($bank_name_err)): ?>
                           <span class="text-danger"><?php echo $bank_name_err; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="branch_name">Branch Name :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="branch_name"
                             placeholder="Enter Branch Name" name="branch_name">
                           <?php if (!empty($branch_name_err)): ?>
                           <span class="text-danger"><?php echo $branch_name_err; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                       <div class="col-sm-6">
                         <div class="form-group">
                           <label for="account_No">Account No :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="account_No"
                             placeholder="Enter Acc. No." name="account_No">
                           <?php if (!empty($account_No_err)): ?>
                           <span class="text-danger"><?php echo $account_No_err; ?></span>
                           <?php endif; ?>
                         </div>
                         <div class="form-group">
                           <label for="routing_No">Routing No :</label>
                           <input type="text" class="form-control rounded-0 bg-light" id="routing_No"
                             placeholder="Enter Rout. No." name="routing_No">
                           <?php if (!empty($routing_No_err)): ?>
                           <span class="text-danger"><?php echo $routing_No_err; ?></span>
                           <?php endif; ?>
                         </div>
                       </div>
                     </div>
                     <script>
                       const yesCheckbox = document.getElementById("customCheckYes5");
                       const noCheckbox = document.getElementById("customCheckNo5");
                       const companyNameInput = document.getElementById("name_of_the_Stock_Comp");
                       yesCheckbox.addEventListener("change", function() {
                         if (yesCheckbox.checked) {
                           noCheckbox.checked = false;
                           companyNameInput.disabled = false;
                           companyNameInput.placeholder =
                             "Enter Company name"; // Reset placeholder when enabled
                         }
                       });
                       noCheckbox.addEventListener("change", function() {
                         if (noCheckbox.checked) {
                           yesCheckbox.checked = false;
                           companyNameInput.disabled = true;
                           companyNameInput.placeholder =
                             "Disabled"; // Set the placeholder to "Disabled" when disabled
                         }
                       });
                     </script>
                     <div class="form-footer pt-5 border-top">
                     </div>

                   </div>
                   <div class="card-body">
                     <div class="col-sm-120">
                       <div class="form-group">
                         <label for="Declaration">Declaration : It is hereby declared that all the above
                           mentioned
                           information in customer account information form are true & valid. </label>
                         <table class="table table-bordered">
                           <thead>
                             <tr>
                               <th scope="col"></th>
                               <th scope="col">Name</th>
                               <th scope="col">Signature</th>
                               <th scope="col">Date</th>
                             </tr>
                           </thead>
                           <tbody>
                             <tr>
                               <td>First Account Holder</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="F_AccH_Name2"
                                   placeholder="" name="F_AccH_Name2">
                                 <?php if (!empty($F_AccH_Name2_err)): ?>
                                 <span class="text-danger"><?php echo $F_AccH_Name2_err; ?></span>
                                 <?php endif; ?>
                               </td>
                               <td>
                                 <fieldset disabled>
                                   <input type="text" class="form-control rounded-0 bg-light" id="temp1" placeholder=""
                                     name="temp1">
                                 </fieldset>
                                 <input type="file" class="form-control-file" name="F_AccH_Signature"
                                   id="F_AccH_Signature">
                                 <?php if (!empty($F_AccH_Signature_image_err)): ?>
                                 <span class="text-danger"><?php echo $F_AccH_Signature_image_err; ?></span>
                                 <?php endif; ?>
                               </td>
                               <td>
                                 <input type="date" class="form-control rounded-0 bg-light" id="F_AccH_Signature_Date"
                                   placeholder="" name="F_AccH_Signature_Date">
                                 <?php if (!empty($F_AccH_Signature_Date_err)): ?>
                                 <span class="text-danger"><?php echo $F_AccH_Signature_Date_err; ?></span>
                                 <?php endif; ?>
                               </td>
                             </tr>
                             <tr>
                               <td>Second Account Holder</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="J_AccH_Name2"
                                   placeholder="" name="J_AccH_Name2">
                                 <?php if (!empty($J_AccH_Name2_err)): ?>
                                 <span class="text-danger"><?php echo $J_AccH_Name2_err; ?></span>
                                 <?php endif; ?>
                               </td>
                               <td>
                                 <fieldset disabled>
                                   <input type="text" class="form-control rounded-0 bg-light" id="temp2" placeholder=""
                                     name="temp2">
                                 </fieldset>
                                 <input type="file" class="form-control-file" id="J_AccH_Signature"
                                   name="J_AccH_Signature">
                                 <?php if (!empty($J_AccH_Signature_image_err)): ?>
                                 <span class="text-danger"><?php echo $J_AccH_Signature_image_err; ?></span>
                                 <?php endif; ?>
                               </td>

                               <td> <input type="date" class="form-control rounded-0 bg-light"
                                   id="J_AccH_Signature_Date" placeholder="" name="J_AccH_Signature_Date">
                                 <?php if (!empty($J_AccH_Signature_Date_err)): ?>
                                 <span class="text-danger"><?php echo $J_AccH_Signature_Date_err; ?></span>
                                 <?php endif; ?>
                               </td>
                             </tr>
                             <tr>
                               <td>Officer/Manager/Branch In-charge</td>
                               <td>
                                 <input type="text" class="form-control rounded-0 bg-light" id="A_AccH_Name2"
                                   placeholder="" name="A_AccH_Name2">
                                 <?php if (!empty($A_AccH_Name2_err)): ?>
                                 <span class="text-danger"><?php echo $A_AccH_Name2_err; ?></span>
                                 <?php endif; ?>
                               </td>
                               <td>
                                 <fieldset disabled>
                                   <input type="text" class="form-control rounded-0 bg-light" id="temp3" placeholder=""
                                     name="temp3">
                                 </fieldset>
                                 <input type="file" class="form-control-file" id="A_AccH_Signature"
                                   name="A_AccH_Signature">
                                 <?php if (!empty($A_AccH_Signature_image_err)): ?>
                                 <span class="text-danger"><?php echo $A_AccH_Signature_image_err; ?></span>
                                 <?php endif; ?>
                               </td>
                               <td> <input type="date" class="form-control rounded-0 bg-light"
                                   id="A_AccH_Signature_Date" placeholder="" name="A_AccH_Signature_Date">
                                 <?php if (!empty($A_AccH_Signature_Date_err)): ?>
                                 <span class="text-danger"><?php echo $A_AccH_Signature_Date_err; ?></span>
                                 <?php endif; ?>
                               </td>
                             </tr>
                           </tbody>
                         </table>
                       </div>
                     </div>
                     <div class="form-footer pt-5 border-top">
                     </div>
                     <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                       <input type="checkbox" class="custom-control-input" id="customCheckTerms" name="customCheckTerms"
                         value="customCheckTerms">
                       <label class="custom-control-label" for="customCheckTerms">See our <button type="button"
                           data-toggle="modal" data-target="#exampleModalLong" style="color: green;"
                           style="border: 20cap;">
                           TERMS AND CONDITIONS
                         </button> for more info. By checking the box you acknowledge and represent
                         it</label>
                     </div>
                     <!-- those are for terms and conditions-->
                     <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog"
                       aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                       <div class="modal-dialog" role="document">
                         <div class="modal-content">
                           <div class="modal-header">
                             <h5 class="modal-title" id="exampleModalLongTitle">TERMS AND CONDITIONS</h5>
                             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                               <span aria-hidden="true">×</span>
                             </button>
                           </div>
                           <div class="modal-body">
                             <h2>DECLARATION/AGREEMENT</h2>
                             <p>I/ We the undersigned whose information is given in the Brokerage Application
                               Form hereby
                               request to be registered as
                               a client of LankaBangla Securities Limited, to open a brokerage account in
                               my/our/company
                               name. I/We further agree and
                               confirm that the account hereby requested to be opened by me/us shall be held
                               and be
                               governed by the terms and
                               conditions of this agreement as provided hereinafter and as may be modified
                               from time to
                               time by LankaBangla
                               Securities Limited and that I /we/company name have/has the necessary
                               authority and
                               permission to enter this
                               agreement.</p>
                             <h3>TERMS AND CONDITIONS</h3>
                             <p><strong>Instruction:</strong> A written instruction shall be given to
                               LankaBangla
                               Securities Limited from time to
                               time to purchase and /or sell investments (which shall mean and include
                               stocks,
                               debentures, mutual funds and private
                               placement or any other similar financial instrument as may be made available
                               from time to
                               time) on behalf of the
                               account holder. On receipt of such instructions along with a cash deposit or
                               delivery of
                               shares, LankaBangla
                               Securities Limited shall, so far as LankaBangla Securities Limited considers
                               it reasonably
                               practicable, purchase
                               and/or sell investments in accordance with those instructions, provided always
                               that (I)
                               any such dealings do not
                               contravene any applicable laws or regulations; (II) LangkaBangla Securities
                               Limited shall
                               have an absolute discretion
                               to accept or reject purchase/sell instructions and (III) accounts holder's
                               instruction
                               shall include the following
                               details:</p>
                             <ul>
                               <li>The name of the investment.</li>
                               <li>Quantity</li>
                               <li>Price with notification of limit or discretion.</li>
                               <li>The duration of the order.</li>
                               <li>The nature of the lot (i.e. scrip size) for sale or the desired format for
                                 the
                                 purchase order (See Note below).
                               </li>
                               <li>The order should specify completion formats of:</li>
                               <li>All or partial fill with minimum trade value or number of shares.</li>
                               <li>Mode of execution i.e. DVP (Delivery versus payment)/NON DVP (non-delivery
                                 versus
                                 payment).</li>
                             </ul>
                             <p><em>(Note: The number of shares constituting a "market lot" may change.
                                 Sellers must
                                 include the exact format of
                                 their holding. This has a direct impact on market pricing given the
                                 predominantly retail
                                 nature of the market.
                                 Trades may fail where non-agreed lot sizes are delivered).</em></p>
                             <h3>Joint Accounts:</h3>
                             <p>If this is a joint account, unless the account holders notify LankaBangla
                               Securities
                               Limited otherwise and provide
                               such documentation as LankaBangla Securities Limited may require at its sole
                               discretion,
                               the brokerage account(s)
                               shall be held by the account holders jointly with rights or survivorship
                               (payable to
                               either or the survivor). Under
                               these terms and conditions, each joint account holder irrevocably appoints the
                               other as
                               attorney in fact to take all
                               action on his or her behalf and to represent him or her in all respects in
                               connection with
                               this agreement. LankaBangla
                               Securities Limited shall be fully protected and indemnified in acting but
                               shall not be
                               required to act upon the
                               instruction of either of the account holder, who shall be liable, jointly or
                               severally,
                               for any amounts due to
                               LankaBangla Securities Limited pursuant to this agreement, whether incurred by
                               either both
                               of the account holders.</p>
                             <h3>Risk:</h3>
                             <p>The account holder understands that the stock market is a rapidly changing
                               market and
                               that there is an inherent risk
                               in incurring loss in share dealings, which LankaBangla Securities Limited is
                               not in any
                               way whatsoever liable and/or
                               responsible for the share dealings of the account holder.</p>
                             <h3>Limit Orders:</h3>
                             <p>While LankaBangla Securities Limited will endeavor to purchase or sell the
                               investment
                               within the limits of the prices
                               that may be notified by the account holder, LankaBangla Securities Limited
                               does not
                               guarantee or assure that the
                               transactions will be met or realized on such notified limits, LankaBangla
                               Securities
                               Limited will always endeavor to
                               obtain the best price.</p>
                             <h3>Agents:</h3>
                             <p>LankaBangla Securities Limited is authorized to employ other brokers as
                               agents to perform
                               all or part of its duties under these terms and conditions and to provide
                               information
                               regarding the account to such agents. LankaBangla Securities Limited may seek
                               and act on
                               an opinion from any lawyer, accountant or professional adviser or other expert
                               and shall
                               not incur any liability by acting upon such opinion.</p>
                             <h3>Associate Companies:</h3>
                             <p>LankaBangla Securities Limited may purchase and / or sell investment on
                               behalf of the
                               account holder by placing order with itself and other company whether acting
                               as
                               underwriter(s), investment manager(s), merchant or commercial bank(s),
                               registered or
                               licensed deposit-taker(s), broker (s), dealer(s) or otherwise, or with any
                               other broker(s)
                               and dealer(s) as LankaBangla Securities Limited in its sole discretion may
                               decide.</p>
                             <h3>All Rules and Regulations of the Stock Exchange(s):</h3>
                             <p>All transactions duly concluded through and recognized by the Dhaka &
                               Chittagong Stock
                               Exchange Limited (hereafter DSE & CSE) is governed by the respective rules of
                               DSE & CSE
                               relating to trading and settlement in particular and will be binding on both
                               the parties
                               concerned.</p>
                             <h3>Payment and Disclosure:</h3>
                             <p>LankaBangla Securities Limited shall not be obliged to make any payment on
                               behalf of the
                               account holders. LankaBangla Securities Limited may disclose information
                               regarding the
                               account holder or his/her dealings in relation to this agreement to any
                               department of the
                               government or public, body upon request, whether or not such request is in
                               fact legally
                               enforceable, and LankaBangla Securities Limited will not be liable in any way
                               to account
                               holder for doing so.</p>
                             <h3>Cancellation provisions:</h3>
                             <p>LankaBangla Securities Limited is authorized, in its absolute discretion,
                               should the
                               undersigned die or should LankaBangla Securities Limited for any reason
                               whatsoever deems
                               it necessary for its protection, without notice, or for any reason to cancel
                               any
                               outstanding orders in order to close out the accounts of the account holder,
                               in whole or
                               in part, or to close out any commitment made on behalf of the account holder.
                             </p>
                             <h3>Indemnity:</h3>
                             <p>In the event of a default, omission or act committed by LankaBangla
                               Securities Limited as
                               a broker/member of the DSE & CSE the account holder shall be indemnified if
                               and only as
                               provided by the Rules and Regulation of the DSE & CSE.</p>
                             <h3>Confirmation and Settlements:</h3>
                             <p>LankaBangla Securities Limited shall use its best endeavors to provide the
                               account holder
                               with (a) written confirmation of each transaction it has effected on
                               instructions and (b)
                               contract notes (in such form as LankaBangla Securities Limited shall
                               determine) surfing
                               forth (i) details of the trade date, value date, settlement date, quantity,
                               price,
                               commission rate and DSE Howla' number equivalent provided also that the
                               account holder
                               does hereby agree and undertake to confirm in writing beforehand of all
                               its/their
                               instructions.</p>
                             <h3>Fees and expenses:</h3>
                             <p>The account holder will pay a brokerage commission of, and any other related
                               expenses as
                               charged that may from time to time be applicable, every transaction concluded
                               through and
                               recognized by the DSE is subject to transaction levies or other fees imposed
                               by the DSE.
                               The account holder understands, acknowledges and accepts that the rate of
                               commission may
                               be changed from time to time at the discretion of LankaBangla Securities
                               Limited.</p>
                             <h3>Set-off:</h3>
                             <p>LankaBangla Securities Limited shall be entitled to, in respect of all
                               commission, costs,
                               charged or expense, set off from any monies from time to time held by
                               LankaBangla
                               Securities Limited for the account holder and if such monies are insufficient
                               for the
                               purpose, to sell any investment held by LankaBangla Securities Limited or any
                               of its
                               agents on behalf of the account holder without notification, recourse or
                               instruction form
                               the account holder.</p>
                             <h3>Period:</h3>
                             <p>This agreement shall remain in force for a period
                               of.......................months/years
                               from the date of signing.</p>
                             <h3>Terminations:</h3>
                             <p>This agreement will stand terminated:</p>
                             <ol>
                               <li>Upon the expiry of the period of this Agreement unless renewed upon mutual
                                 agreement
                                 between LankaBangla Securities Limited and the Account Holder.</li>
                               <li>Before the expiry of the period of this Agreement, if either LankaBangla
                                 Securities
                                 Limited or the Account Holder gives.........months’ notice. Termination
                                 shall not
                                 absolve the parties from completing accounts and adjusting any outstanding
                                 dues or
                                 respective rights and obligations under this agreement.</li>
                               <li>If the account holder fails to make payment for any transaction upon due
                                 notice for a
                                 period of..........days.</li>
                             </ol>
                             <h3>Assignment:</h3>
                             <p>The benefits/rights and burdens/obligations of this agreement are capable of
                               assignment
                               of both the account holder and LankaBangla Securities Limited without the
                               consent of the
                               other but the notice of assignment must be given to the other in writing.</p>
                             <h3>Force Majeur:</h3>
                             <p>LankaBangla Securities Limited shall not be liable for any loss, damages,
                               expenses,
                               costs, or otherwise resulting directly or indirectly from any Government
                               restriction,
                               exchange ruling, suspension of trading, war, strike/national disaster, or any
                               other event
                               or force majeure or circumstances beyond its control.</p>
                             <h3>Forged Shares:</h3>
                             <p>LankaBangla Securities Limited shall not be liable or responsible for any
                               shares that are
                               found to be forged. However, LankaBangla Securities Limited will make every
                               attempt to
                               replace the forged shares from the seller.</p>
                             <h3>Law:</h3>
                             <p>The terms and conditions contained herein shall be governed by and be
                               construed in
                               accordance with the laws of Bangladesh.</p>
                             <h3>Notices:</h3>
                             <p>(a) All notices, instructions, or other communications shall be given in
                               English and in
                               writing (facsimile, telex, telegram, cable, or letter) or orally and shall be
                               sent to
                               LankaBangla Securities Limited and the account Holder at the address, fax,
                               and/or telex
                               number shown herein or at such other address as may be communicated by the
                               parties here to
                               in writing.</p>
                             <p>(b) Proof of delivery or dispatch shall be:</p>
                             <ol>
                               <li>in the case of a letter: dispatch of the letter duly stamped and addressed
                               </li>
                               <li>in the case of facsimile, telex, telegram, or cable on the day of dispatch
                                 with
                                 physical or actual confirmation.</li>
                             </ol>
                             <p>(c) All verbal notices, instructions, or other communications should be
                               confirmed in
                               writing within 24 hours.</p>
                             <h3>Definitions:</h3>
                             <p>Words defined herein, save where a contrary meaning appears or such meaning
                               is
                               inconsistent with the context, shall have this same defined meaning wherever
                               used.</p>
                             <h3>Sums Due:</h3>
                             <p>For all purposes, including any legal proceedings, a certificate by any of
                               LankaBangla
                               Securities Limited officers confirming the monies and/or liabilities for the
                               time being
                               due and/or incurred to by the account holder shall be conclusive evidence
                               thereof against
                               him/her.</p>
                             <h3>Disputes and Resolution of Dispute:</h3>
                             <p>In-case of any dispute arising between the LankaBangla Securities Limited and
                               the account
                               holder in connection with the interpretation or enforcement of the terms and
                               conditions
                               contained herein, attempts should be made to settle the matter amicably, in
                               case of
                               failure to settle the matter amicably, the same shall be referred to
                               arbitration of two
                               arbitrators, each to be nominated by the parties who shall also appoint an
                               Umpire. The
                               decision of the arbitrators, so nominated, shall be binding on both the
                               parties. The
                               arbitration shall be conducted in accordance with the Arbitration Act, 2001.
                             </p>
                             <h3>Signature:</h3>
                             <p>I/We have read the terms and conditions contained herein above, and having
                               agreed with
                               such terms and conditions I/We put my/our/company seal and signature on this
                               the day
                               of..........20............</p>
                             <div class="signature-field">
                               <label for="firstAccountHolderSignature">Signature of the First Account
                                 Holder:</label>
                               <input type="text" id="firstAccountHolderSignature" name="firstAccountHolderSignature"
                                 placeholder="Enter First Account Holder's Signature">
                             </div>
                             <!-- Witness for First Account Holder's Signature -->
                             <div class="witness-field">
                               <label for="firstAccountHolderWitnessSignature">Witnessed By:</label>
                               <input type="text" id="firstAccountHolderWitnessSignature"
                                 name="firstAccountHolderWitnessSignature" placeholder="Enter Witness Signature">
                               <label for="firstAccountHolderWitnessName">Name:</label>
                               <input type="text" id="firstAccountHolderWitnessName"
                                 name="firstAccountHolderWitnessName" placeholder="Enter Witness Name">
                               <label for="firstAccountHolderWitnessAddress">Address:</label>
                               <input type="text" id="firstAccountHolderWitnessAddress"
                                 name="firstAccountHolderWitnessAddress" placeholder="Enter Witness Address">
                             </div>
                             <!-- Signature of the Joint Account Holder -->
                             <div class="signature-field">
                               <label for="jointAccountHolderSignature">Signature of the Joint Account
                                 Holder:</label>
                               <input type="text" id="jointAccountHolderSignature" name="jointAccountHolderSignature"
                                 placeholder="Enter Joint Account Holder's Signature">
                             </div>
                             <!-- Witness for Joint Account Holder's Signature -->
                             <div class="witness-field">
                               <label for="jointAccountHolderWitnessSignature">Witnessed By:</label>
                               <input type="text" id="jointAccountHolderWitnessSignature"
                                 name="jointAccountHolderWitnessSignature" placeholder="Enter Witness Signature">
                               <label for="jointAccountHolderWitnessName">Name:</label>
                               <input type="text" id="jointAccountHolderWitnessName"
                                 name="jointAccountHolderWitnessName" placeholder="Enter Witness Name">
                               <label for="jointAccountHolderWitnessAddress">Address:</label>
                               <input type="text" id="jointAccountHolderWitnessAddress"
                                 name="jointAccountHolderWitnessAddress" placeholder="Enter Witness Address">
                             </div>
                           </div>
                           <div class="modal-footer">
                             <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
                           </div>
                         </div>
                       </div>
                     </div>
                     <button type="submit" class="btn btn-secondary btn-pill" name="submit" id="submit">Submit</button>
                     <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                     <div class="custom-control custom-checkbox d-inline-block mr-3 mb-3">
                     </div>
                   </div>
                   </form>
                 </div>
               </div>
               <script>
                 const cardHeader1 = document.getElementById("cardHeader1");
                 const cardBody1 = document.getElementById("collapse-custom-input1");
                 const arrowButton1 = cardHeader1.querySelector(".arrow-button1");
                 const cardHeader2 = document.getElementById("cardHeader2");
                 const cardBody2 = document.getElementById("collapse-custom-input2");
                 const arrowButton2 = cardHeader2.querySelector(".arrow-button2");
                 const cardHeader3 = document.getElementById("cardHeader3");
                 const cardBody3 = document.getElementById("collapse-custom-input3");
                 const arrowButton3 = cardHeader3.querySelector(".arrow-button3");
                 const cardHeader4 = document.getElementById("cardHeader4");
                 const cardBody4 = document.getElementById("custom-input4");
                 const submitFirstAccountBtn = document.getElementById("submitFirstAccount");
                 const submitJointAccountBtn = document.getElementById("submitJointAccount");
                 const submitAuthAccountBtn = document.getElementById("submitAuthAccount");
                 const submitDateClientCodeBtn = document.getElementById("submitDate&ClientCode");
                 const submitBtn = document.getElementsByName("submit")[
                   0]; // Assuming there's only one button with the name "submit"
                 const customCheckTerms = document.getElementById("customCheckTerms");
                 submitBtn.addEventListener("click", function(event) {
                   if (!customCheckTerms.checked) {
                     event.preventDefault();
                     alert("Please agree to the terms before submitting.");
                   }
                 });
                 submitDateClientCodeBtn.addEventListener("click", function(event) {
                   cardBody3.classList.add("show");
                   arrowButton3.querySelector("i").classList.remove("fa-chevron-down");
                   arrowButton3.querySelector("i").classList.add("fa-chevron-up");
                 });
                 submitFirstAccountBtn.addEventListener("click", function(event) {
                   event
                     .preventDefault();
                   cardBody3.classList.remove("show");
                   arrowButton3.querySelector("i").classList.remove("fa-chevron-up");
                   arrowButton3.querySelector("i").classList.add("fa-chevron-down");
                   cardBody2.classList.add("show");
                   arrowButton2.querySelector("i").classList.remove("fa-chevron-down");
                   arrowButton2.querySelector("i").classList.add("fa-chevron-up");
                 });
                 submitJointAccountBtn.addEventListener("click", function(event) {
                   event
                     .preventDefault();
                   cardBody2.classList.remove("show");
                   arrowButton2.querySelector("i").classList.remove("fa-chevron-up");
                   arrowButton2.querySelector("i").classList.add("fa-chevron-down");
                   cardBody1.classList.add("show");
                   arrowButton1.querySelector("i").classList.remove("fa-chevron-down");
                   arrowButton1.querySelector("i").classList.add("fa-chevron-up");
                 });
                 submitAuthAccountBtn.addEventListener("click", function(event) {
                   event
                     .preventDefault();
                   cardBody1.classList.remove("show");
                   arrowButton1.querySelector("i").classList.remove("fa-chevron-up");
                   arrowButton1.querySelector("i").classList.add("fa-chevron-down");
                 });
                 cardHeader1.addEventListener("click", function() {
                   cardBody1.classList.toggle("show");
                   arrowButton1.querySelector("i").classList.toggle("fa-chevron-down");
                   arrowButton1.querySelector("i").classList.toggle("fa-chevron-up");
                 });
                 cardHeader2.addEventListener("click", function() {
                   cardBody2.classList.toggle("show");
                   arrowButton2.querySelector("i").classList.toggle("fa-chevron-down");
                   arrowButton2.querySelector("i").classList.toggle("fa-chevron-up");
                 });
                 cardHeader3.addEventListener("click", function() {
                   cardBody3.classList.toggle("show");
                   arrowButton3.querySelector("i").classList.toggle("fa-chevron-down");
                   arrowButton3.querySelector("i").classList.toggle("fa-chevron-up");
                 });
                 cardHeader4.addEventListener("click", function() {
                   cardBody4.classList.toggle("show");
                 });
                 //  submitBtn.addEventListener("click", function(event) {
                 //    // Trigger the click events of the other buttons
                 //    submitDateClientCodeBtn.click();
                 //    submitFirstAccountBtn.click();
                 //    submitJointAccountBtn.click();
                 //    submitAuthAccountBtn.click();
                 //  });
               </script>
               <script>
                 var firstAccHInput = document.getElementById("nameOfTheCustomer1");
                 var firstAccHInput2 = document.getElementById("F_AccH_Name2");
                 var jointAccHInput = document.getElementById("nameOfTheCustomer2");
                 var jointAccHInput2 = document.getElementById("J_AccH_Name2");
                 var authAccHInput = document.getElementById("nameOfTheCustomer3");
                 var authAccHInput2 = document.getElementById("A_AccH_Name2");
                 firstAccHInput.addEventListener("input", function() {
                   var name1Value = firstAccHInput.value;
                   firstAccHInput2.value = name1Value; // Update the value of name2 input field
                   firstAccHInput2.setAttribute("value", name1Value); // Update the value attribute
                 });
                 jointAccHInput.addEventListener("input", function() {
                   var name2Value = jointAccHInput.value;
                   jointAccHInput2.value = name2Value; // Update the value of name2 input field
                   jointAccHInput2.setAttribute("value", name2Value); // Update the value attribute
                 });
                 authAccHInput.addEventListener("input", function() {
                   var name3Value = authAccHInput.value;
                   authAccHInput2.value = name3Value; // Update the value of name2 input field
                   authAccHInput2.setAttribute("value", name3value); // Update the value attribute
                 });
               </script>
             </div>
           </div>
         </div>
       </div>
     </div>
     </div>
     </div>
     </div>
     <!-- Footer -->
     <footer class="footer mt-auto">
       <div class="copyright bg-white">
         <p>
           Noushin Nurjahan
         </p>
       </div>
       <script>
         var d = new Date();
         var year = d.getFullYear();
         document.getElementById("copy-year").innerHTML = year;
       </script>
     </footer>
     </div>
     </div>
     <!-- Card Offcanvas -->
     <div class="card card-offcanvas" id="contact-off">
       <div class="card-header">
         <h2>SideBar ItemRight</h2>
         <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
       </div>
       <div class="card-body">
         <div class="mb-4">
           <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
             placeholder="Search Item...">
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
         <div class="media media-sm">
           <div class="media-sm-wrapper">
           </div>
           <div class="media-body">
           </div>
         </div>
       </div>
     </div>
     <script src="plugins/jquery/jquery.min.js"></script>
     <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="plugins/simplebar/simplebar.min.js"></script>
     <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>
     <script src="plugins/prism/prism.js"></script>
     <script src="js/mono.js"></script>
     <script src="js/chart.js"></script>
     <script src="js/map.js"></script>
     <script src="js/custom.js"></script>
     <!--  -->
   </body>

   </html>