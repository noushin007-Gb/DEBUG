<?php
// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: customer_application_for_terms_and_conditions_by_laws.php");
    exit;
}
require_once "connection.php";
$Client_CODE = $_SESSION["Client_CODE"];


$sql1 = "SELECT first_acc_h_Name FROM customer_info_first_account_holder WHERE Client_CODE = ?";
$sql2 = "SELECT joint_acc_h_Name FROM customer_info_joint_account_holder WHERE Client_CODE = ?";
$sql3 = "SELECT authorized_acc_h_Name FROM customer_info_authorized_account_holder WHERE Client_CODE = ?";
if ($stmt1 = mysqli_prepare($link, $sql1)) {
    mysqli_stmt_bind_param($stmt1, "s", $Client_CODE);
    mysqli_stmt_execute($stmt1);
    $result1 = mysqli_stmt_get_result($stmt1);
    mysqli_stmt_close($stmt1);
}
if ($stmt2 = mysqli_prepare($link, $sql2)) {
  mysqli_stmt_bind_param($stmt2, "s", $Client_CODE);
  mysqli_stmt_execute($stmt2);
  $result2 = mysqli_stmt_get_result($stmt2);
  mysqli_stmt_close($stmt2);
}
if ($stmt3 = mysqli_prepare($link, $sql3)) {
  mysqli_stmt_bind_param($stmt3, "s", $Client_CODE);
  mysqli_stmt_execute($stmt3);
  $result3 = mysqli_stmt_get_result($stmt3);
  mysqli_stmt_close($stmt3);
}
// Loop through the query result and store the attributes in PHP sessions
while ($row = mysqli_fetch_assoc($result1)) {
    $_SESSION['first_acc_h_Name'] = $row['first_acc_h_Name'];
} 
while ($row = mysqli_fetch_assoc($result2)) {
  $_SESSION['joint_acc_h_Name'] = $row['joint_acc_h_Name'];
} 
while ($row = mysqli_fetch_assoc($result3)) {
  $_SESSION['authorized_acc_h_Name'] = $row['authorized_acc_h_Name'];
} 
$First_Account_Holder = $_SESSION['first_acc_h_Name'];                   
$Second_Account_Holder = $_SESSION['joint_acc_h_Name'];            
$_3rd_Signatory = $_SESSION['authorized_acc_h_Name'];



if (
  $_SERVER["REQUEST_METHOD"] == "POST")
 {


  // Handle image uploads
  $First_Account_Holder_sig_imageData = '';
  $Second_Account_Holder_sig_imageData = '';
  $_3rd_Signatory_sig_imageData = '';

  $DATE1 = trim($_POST["DATE1"]);
  $DATE2 = trim($_POST["DATE2"]);
  $DATE3 = trim($_POST["DATE3"]);

  if (empty($DATE1)) {
    $DATE1_err = "Enter Signature Date";
  }
  if (empty($DATE1)) {
    $DATE2_err = "Enter Signature Date";
  }
  if (empty($DATE1)) {
    $DATE3_err = "Enter Signature Date";
  }

  if (
    empty($DATE1_err) &&
    empty($DATE2_err) &&
    empty($DATE3_err)
  ) {

    $checkQuery2 = "SELECT Client_CODE FROM customer_application_for_terms_and_conditions_by_laws WHERE Client_CODE = ?";
    if ($checkStmt2 = mysqli_prepare($link, $checkQuery2)) {
      mysqli_stmt_bind_param($checkStmt2, "s", $Client_CODE);
      mysqli_stmt_execute($checkStmt2);
      mysqli_stmt_store_result($checkStmt2);

      if (isset($_POST['submit']) && mysqli_stmt_num_rows($checkStmt2) == 0) {
        // Prepare and execute the insert statement for the first account holder's details
        $folder = "signatureTermsByLawsFiles/";

        $First_Account_Holder_sig_imageData = $_FILES['First_Account_Holder_sig']['name'];
        $First_Account_Holder_sig_TMPimageData = $_FILES['First_Account_Holder_sig']['tmp_name'];

        $Second_Account_Holder_sig_imageData = $_FILES['Second_Account_Holder_sig']['name'];
        $Second_Account_Holder_sig_TMPimageData = $_FILES['Second_Account_Holder_sig']['tmp_name'];

        $_3rd_Signatory_sig_imageData = $_FILES['_3rd_Signatory_sig']['name'];
        $_3rd_Signatory_sig_TMPimageData = $_FILES['_3rd_Signatory_sig']['tmp_name'];

        move_uploaded_file($First_Account_Holder_sig_TMPimageData, $folder . $First_Account_Holder_sig_imageData);
        move_uploaded_file($Second_Account_Holder_sig_TMPimageData, $folder . $Second_Account_Holder_sig_imageData);
        move_uploaded_file($_3rd_Signatory_sig_TMPimageData, $folder . $_3rd_Signatory_sig_imageData);

        $insertQuery2 = "INSERT INTO customer_application_for_terms_and_conditions_by_laws (Client_CODE,First_Account_Holder, Second_Account_Holder, _3rd_Signatory, DATE1, DATE2, DATE3) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";

        $insertQuery3 = "UPDATE customer_application_for_terms_and_conditions_by_laws
                       SET 
                           First_Account_Holder_sig = '$First_Account_Holder_sig_imageData',
                           Second_Account_Holder_sig = '$Second_Account_Holder_sig_imageData',
                           _3rd_Signatory_sig = '$_3rd_Signatory_sig_imageData'
                       WHERE Client_CODE = '$Client_CODE'";

        // Start a transaction
        mysqli_autocommit($link, false); // Disable auto-commit

        if ($insertStmt2 = mysqli_prepare($link, $insertQuery2)) {
          mysqli_stmt_bind_param(
            $insertStmt2,
            "sssssss",
            $Client_CODE,
            $First_Account_Holder,
            $Second_Account_Holder,
            $_3rd_Signatory,
            $DATE1,
            $DATE2,
            $DATE3
          );

          if (mysqli_stmt_execute($insertStmt2)) {
            $insertStmt2->close();

            // Insert the second part of data
            if ($insertStmt3 = mysqli_prepare($link, $insertQuery3)) {

              $qry = mysqli_query($link, $insertQuery3);

              if ($qry) {
                mysqli_commit($link); // Commit the transaction
                $errorMessage = "Success!!!";
                $displayError = true; // Set this based on your error condition
              } else {
                mysqli_rollback($link); // Rollback the transaction
                echo "Something went wrong. Please try again later.";
              }

              $insertStmt3->close();
            }
          } else {
            mysqli_rollback($link); // Rollback the transaction
            echo "Something went wrong. Please try again later.";
          }
        }
      } else {
        $errorMessage = "You Have Already Filled Up Rest Of the Info";
        $displayError = true; // Set this based on your error condition
      }

      $checkStmt2->close();
    }
  }
}
// Close the database connection
mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Fill Customer Info</title>
  <meta name="theme-name" content="mono" />
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700|Roboto" rel="stylesheet">
  <link href="plugins/material/css/materialdesignicons.min.css" rel="stylesheet" />
  <link href="plugins/simplebar/simplebar.css" rel="stylesheet" />
  <link href="plugins/nprogress/nprogress.css" rel="stylesheet" />
  <link href="plugins/DataTables/DataTables-1.10.18/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="plugins/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
  <link href="plugins/daterangepicker/daterangepicker.css" rel="stylesheet" />
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <link href="plugins/toaster/toastr.min.css" rel="stylesheet" />
  <link id="main-css-href" rel="stylesheet" href="css/style.css" />
  <link rel="icon" type="image/x-icon" href="https://www.lankabangla.com/wp-content/themes/lbflrevamp/favicon.ico">
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select@1.12.4/dist/css/bootstrap-select.min.css" type="text/css" />
  <link rel="stylesheet" href="//unpkg.com/bootstrap-select-country@4.0.0/dist/css/bootstrap-select-country.min.css"
    type="text/css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="//unpkg.com/jquery@3.4.1/dist/jquery.min.js"></script>
  <script src="//unpkg.com/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  <script src="//unpkg.com/bootstrap-select@1.12.4/dist/js/bootstrap-select.min.js"></script>
  <script src="//unpkg.com/bootstrap-select-country@4.0.0/dist/js/bootstrap-select-country.min.js"></script>

  <style>
    .arrow-button {
      position: absolute;
      top: 10px;
      right: 20px;
    }

    .rotate {
      transform: rotate(180deg);
    }
  </style>
  <style>
    .hidden {
      display: none;
    }

    .custom-alert {
      position: relative;
      background-color: #187016;
      color: #fff;
      padding: 10px;
      width: 500px;
      border-radius: 5px;
    }

    .close-button {
      position: absolute;
      top: 5px;
      right: 5px;
      font-size: 20px;
      cursor: pointer;
      z-index: 1;
      padding-left: 5px;
      /* Ensure the cross is on top */
    }
  </style>

  <script>
    /* for alert box */
    document.addEventListener("DOMContentLoaded", function() {
      const errorDiv = document.getElementById("errorDiv");
      const closeButton = document.getElementById("closeButton");
      closeButton.addEventListener("click", function() {
        errorDiv.style.display = "none";
      });
      setTimeout(function() {
        errorDiv.style.display = "none";
      }, 3000);
    });
  </script>
  <script src="plugins/nprogress/nprogress.js"></script>
</head>

<body class="navbar-fixed sidebar-fixed" id="body">
  <script>
    NProgress.configure({
      showSpinner: false
    });
    NProgress.start();
  </script>
  <div id="toaster"></div>
  <div class="wrapper">
    <aside class="left-sidebar sidebar-light" id="left-sidebar">
      <div id="sidebar" class="sidebar sidebar-with-footer">
        <!-- Aplication Brand -->
        <div class="app-brand">
          <a href="#">
            <img src="images/logo_Lanka_Bangla.png" alt="Mono" height="65" width="230">
          </a>
        </div>
        <!-- begin sidebar scrollbar -->
        <div class="sidebar-left" data-simplebar style="height: 100%;">
          <!-- sidebar menu -->
          <ul class="nav sidebar-inner" id="sidebar-menu">
            <li>
              <a class="sidenav-item-link" href="index.php">
                <i class="mdi mdi-briefcase-account-outline"></i>
                <span class="nav-text">Dashboard</span>
              </a>
            </li>
            <li class="section-title">
              Forms
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_opening_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">ACCOUNT INFORMATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_application_for_creditfacility_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">CREDIT FACILITY</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_BO_account_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. OPENING</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_BO_account_nomination_form.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">BO ACC. NOMINATION</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="customer_POA.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Power of Attorney (POA)</span>
              </a>
            </li>
            <li class="active">
              <a class="sidenav-item-link" href="customer_application_for_terms_and_conditions_by_laws.php">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Terms & Conditions</span>
              </a>
            </li>

            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">EFT Enrollment</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Signature Card</span>
              </a>
            </li>
            <li>
              <a class="sidenav-item-link" href="">
                <i class="mdi mdi-account-edit"></i>
                <span class="nav-text">Value Added Service</span>
              </a>
            </li>
            <li class="section-title">
              Pages
            </li>

            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse"
                data-target="#authentication" aria-expanded="false" aria-controls="authentication">
                <i class="mdi mdi-account"></i>
                <span class="nav-text">Authentication</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="authentication" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="sign-in.html">
                      <span class="nav-text">Sign In</span>

                    </a>
                  </li>
                </div>
              </ul>
            </li>
            <li class="has-sub">
              <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#other-page"
                aria-expanded="false" aria-controls="other-page">
                <i class="mdi mdi-file-multiple"></i>
                <span class="nav-text">Other pages</span> <b class="caret"></b>
              </a>
              <ul class="collapse" id="other-page" data-parent="#sidebar-menu">
                <div class="sub-menu">
                  <li>
                    <a class="sidenav-item-link" href="#">
                      <span class="nav-text">Nothing</span>

                    </a>
                  </li>
                </div>
              </ul>
            </li>
            <li class="section-title">
              Documentation
            </li>
            <li>
              <a class="sidenav-item-link" href="#">
                <i class="mdi mdi-airplane"></i>
                <span class="nav-text">Nothing</span>
              </a>
            </li>

          </ul>
        </div>

        <div class="sidebar-footer">
          <div class="sidebar-footer-content">
            <ul class="d-flex">
              <li>
                <a href="#" data-toggle="tooltip" title="Profile settings"><i class="mdi mdi-settings"></i></a></li>
              <li>
                <a href="/debug/lanka-bangla/main-login/client_logout.php" data-toggle="tooltip" title="Logout"><i
                    class="mdi mdi-logout"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </aside>
    <div class="page-wrapper">

      <!-- Header -->
      <header class="main-header" id="header">
        <nav class="navbar navbar-expand-lg navbar-light" id="navbar">
          <!-- Sidebar toggle button -->
          <button id="sidebar-toggler" class="sidebar-toggle">
            <span class="sr-only">Toggle navigation</span>
          </button>

          <span class="page-title">Customer Dashboard</span>

          <div class="navbar-right ">

            <!-- search form -->
            <div class="search-form">
              <form action="index.php" method="get">
                <div class="input-group input-group-sm" id="input-group-search">
                  <input type="text" autocomplete="off" name="query" id="search-input" class="form-control"
                    placeholder="Search..." />
                  <div class="input-group-append">
                    <button class="btn" type="button">/</button>
                  </div>
                </div>
              </form>
              <ul class="dropdown-menu dropdown-menu-search">

                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"></a>
                </li>

              </ul>

            </div>

            <ul class="nav navbar-nav">
              <!-- Offcanvas -->
              <li class="custom-dropdown">
                <a class="offcanvas-toggler active custom-dropdown-toggler" data-offcanvas="contact-off"
                  href="javascript:">
                  <i class="mdi mdi-contacts icon"></i>
                </a>
              </li>
              <li class="custom-dropdown">
                <button class="notify-toggler custom-dropdown-toggler">
                  <i class="mdi mdi-bell-outline icon"></i>
                  <span class="badge badge-xs rounded-circle">21</span>
                </button>
                <div class="dropdown-notify">

                  <header>
                    <div class="nav nav-underline" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="all-tabs" data-toggle="tab" href="#all" role="tab"
                        aria-controls="nav-home" aria-selected="true">All (5)</a>
                      <a class="nav-item nav-link" id="message-tab" data-toggle="tab" href="#message" role="tab"
                        aria-controls="nav-profile" aria-selected="false">Msgs (4)</a>
                      <a class="nav-item nav-link" id="other-tab" data-toggle="tab" href="#other" role="tab"
                        aria-controls="nav-contact" aria-selected="false">Others (3)</a>
                    </div>
                  </header>

                  <footer class="border-top dropdown-notify-footer">
                    <div class="d-flex justify-content-between align-items-center py-2 px-4">
                      <span>Last updated 3 min ago</span>
                      <a id="refress-button" href="javascript:" class="btn mdi mdi-cached btn-refress"></a>
                    </div>
                  </footer>
                </div>
              </li>
              <!-- User Account -->
              <li class="dropdown user-menu">
                <button class="dropdown-toggle nav-link" data-toggle="dropdown">
                  <img
                    src="https://static.vecteezy.com/system/resources/previews/008/442/086/original/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg"
                    class="user-image rounded-circle" alt="User Image" />
                  <span
                    class="d-none d-lg-inline-block"><b><?php echo htmlspecialchars($_SESSION["username"]); ?></i></b>
                    <b><?php echo htmlspecialchars($_SESSION["Client_CODE"]); ?></b></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">

                  <li>
                    <a class="dropdown-link-item" href="#">
                      <i class="mdi mdi-settings"></i>
                      <span class="nav-text">Account Setting</span>
                    </a>
                  </li>

                  <li class="dropdown-footer">
                    <a class="dropdown-link-item" href="/debug/lanka-bangla/main-login/client_logout.php"> <i
                        class="mdi mdi-logout"></i> Log Out </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>

      </header>

      <!-- ====================================
        ——— CONTENT WRAPPER
        ===================================== -->
      <div class="content-wrapper">
        <div class="content">
          <!-- For Components documentaion -->

          <div class="px-6 py-4">
            <p><span class="text-secondary text-capitalize"> Corporate Member</span></p>
            <p><span class="text-secondary text-capitalize">Dhaka Stock Exchange Limited-3.1/132/98-023, Chittagong
                Stock Exchange </span> </p>
            <p><span class="text-customer text-capitalize" style="font-size: 20px; color: black;">Terms & Conditions - By Laws 7.3.3(c) </span> </p>
            <div class="alert alert-dark <?php if (!$displayError)
                 echo 'hidden'; ?> custom-alert" role="alert" id="errorDiv">
              <span class="close-button" id="closeButton">&times;</span>
              <?php echo $errorMessage; ?>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-10">
              <!-- Custom Styles -->
              <div class="card card-default">
                <div class="card-body">
                  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <h2>Terms & Conditions - By Laws</h2>
                        <label for="text" style="margin-top: 20px;margin-bottom: 20px;">Dear Sir,
Please open a Depository account (Bo Account) in my/our names (s) on the terms and conditions set out below. In consideration of
LankaBangla Securities Limited (the “CDBL Participant”) Opening the account providing depository account facilities to me/us/we
have signed the BO Account Opening form as a token of acceptance of the terms and conditions set out below.<br>
1. I/ we agree to be bound by the Depositories Act, 1999, Depositories Regulations, 2000, The Depository (User Regulations) 2003,
and abide by the Bye laws and Opening Instructions issued from time to time by CDBL.<br>
2. CDBL shall allocate a unique identification number to me/us (Account Holder BO ID) for the CDBL Participant to maintain a
separate Account for me/us, unless the I/we instructs the CDBL Participant keep the securities in an Omibus Account of the CDBL
Participant. The CDBL Participant shall however ensure that may / our securities shall not be mixed with the CDBL Participant’s<br>
3. I/We agree to pay such fees, charges and deposits to the CDBL Participant, as may be mutually agreed upon, for the Purpose of
opening and maintaining my/our account, for carrying out the instructions, and for rendering such other Services as are incidental or
consequential to my/our holding securities in and transacting through the said depository Account with the CDBL Participant.<br>
4. I/We shall be responsible for:
(a) The veracity of all statement and particulars set out in the account opening form, supporting or accompanying Documents.<br>
(b) The authenticity and geniuses of all certificates and / or documents submitted to the CDBL Participant along with or in
Support of the account opening form or subsequently for dematerialization.<br>
(c) Title to the securities submitted to the CDBL participant from time to time for dematerialization.<br>
(d) Ensuring at all times that the securities to the credit of my/our account are sufficient to meet the instructions issued to the
CDBL Participant for effecting any transaction/transfer.<br>
(e) Informing the CDBL Participant at the earliest of any changes in my / our account particulars such as address bank details ,
status, Authorizations, mandates, nomination, signature etc.<br>
(f) Furnishing accurate identification details whilst subscribing to any issue of securities.<br>
5. I/we shall notify the CDBL Participant of any change in the particular’s set out in the application form submitted to the CDBL
Participant at the time of opening the account or furnished to the CDBL Participant from time to time at the earliest. The CDBL
Participant shall not be liable or responsible for any loss that may be caused to me/ us by reason of my / our failure to intimate<br>
6. Where I/we have executed a BO Account Nomination Form<br>
(a) In the event of my/ our death, the nominee shall receive/ draw the securities held in my/our account.<br>
(b) In the event the nominee so authorized remains a minor at the time of / our death, the legal guardian is authorized to
Receive/ draw the securities held in my/ our account.<br>
(c) The nominee so authorized, shall be entitled to all my / our account to the exclusion of all other persons i.e, my/our heirs
Executors, and administrators and all other persons calming through or under me/ us and delivery of securities to the Nominee in
pursuance of this authority shall be binding on all other persons.<br>
7. I/we may at any time call upon the CDBL Participant to close my/our account with the CDBL Participant provide no instructions
Remain pending or unexecuted and no fees or charges remain payable by me/us to the CDBL, Participant. In such event I/we may
close my / our account by executing the Account Closing form if no balances are standing to my/our credit in the account. In case
Any balances of securities exist in the account the account may be closed by me/us in one of the following ways:<br>
</label>
<label>(a) By remateralization of all existing balances in my/our account<br>
(b) By transfer of existing balances in my / your to one more of my/your other accounts (s) held with any other CDBL Participants<br>
(b) By rematerialization of a part of the existing balances in my/your account and by transferring the rest to one or more of
my/our other account (s) with any other CDBL Participant (s).<br>
8. CDBL Participant covenants that it shall<br>
(a) act only on the instructions or mandate of the Account Holder or that of such person (s) as may have been duly Authorized by
the Account Holder in that benefit.<br>
(b) not affect any debit or credit to and from the account Holder without appropriate instructions from the Account Holder.<br>
(c) maintain adequate audit trail of the execution of the instructions of the Account Holder.<br>
(d) not honour or act upon any instructions for effecting any debit to the account of the Account Holder in respect of any
Securities unless<br>
(i) Such instructions are issued by the Holder under his signature or that of his/ its constituted attorney duly authorized in
that behalf.<br>
(ii) The CDBL Participant is satisfied that the signature of the Accounts Holder under which instructions are issued matches<br>
With the specimen of the Account Holder or his/ its constituted attorney available on the records of the CDBL Participant.<br>
(iii) The balance of clear securities available in the Account Holder’s account are sufficient to honour the Account Holder’s
instructions.<br>
(e) Furnish to the Account Holder a statement of account at the end of every month if there has been even a single entry of
transaction during that month, and in any event once at the end of each financial year, the CDBL Participant shall furnish such
statement at such shorter periods as may be required by the Account Holder on payment of such charges by the Account Holder
as may be specified by the CDBL Participant. The Account Holder shall scrutinize every statement of account received from the
CDBL Participant for the accuracy and veracity thereof and shall promptly bring to the notice of the CDBL Participant any<br>
(f) Promptly end to all grievances / complaints of the Account Holder and shall resolve all such grievances / complaints as it
Relates to matters exclusively within the domain of the CDBL Participant within one month of the same being brought to the
notice of CDBL Participant and shall forthwith forward to and follow up with CDBL all other grievances / complaints of the Account
Holder on the same being brought to the notice of the CDBL Participant and shall endeavor to resolve the same at the earliest.<br>
9. The CDBL Participant shall be entitled to terminate the account relationship in the event of the Account Holder.<br>
(a) Failing to pay the fees or charges as may be mutually agreed upon within a period of one month from the date of demand
made in that behalf.<br>
(b) Submitting for dematerialization any certificates or other documents of title which are forged, fabricated, counterfeit or stolen
or have been obtained by forgery or the transfer whereof is restrained or prohibited by any direction, order or decree of any court
or the Securities and Exchange Commission:<br>
I/we hereby acknowledge that I/we have read and understood the aforesaid terms and conditions for operating Depository
Account (BO) Account) with CDBL Participant and agree to comply with them.<br>
(d) Otherwise misconducting himself in any manner.<br>
(c) Committing or participating in any fraud or other act of moral turpitude in his / its dealings with CDBL Participant.<br>
10. Declaration and Signature<br>
I/we hereby acknowledge that I/we have read and understood the aforesaid terms and conditions for operating Depository
Account (BO) Account) with CDBL Participant and agree to comply with them.<br>
</label>
                          
                        </div>
                      </div>

                      <div class="col-sm-6">
                        <div class="form-group">
                        </div>
                      </div>
                      
                      <div class="col-sm-120">

                        <div class="form-group">
                            <label for="Declaration"></label>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Applicant</th>
                                        <th scope="col">Name of applicant
                                            /Authorized signatories in case of ltd</th>
                                        <th scope="col">Signature</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>First Account Holder</td>
                                        <td>
                                            <input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id="First_Account_Holder" placeholder="<?php echo $First_Account_Holder; ?>"
                                                name="First_Account_Holder" readonly>

                                        </td>
                                        <td>    <fieldset disabled><input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id=""  placeholder=""
                                                name=""></fieldset>
                                                
                                                
                                                <input type="file"
                                                class="form-control-file"
                                                id="First_Account_Holder_sig"  
                                                name="First_Account_Holder_sig"></td>
                                        </td>
                                        <td> <input type="date" class="form-control rounded-0 bg-light" id="DATE1"
                                  placeholder="" name="DATE1">
                                <?php if (!empty($DATE1_err)): ?>
                                      <span class="text-danger"><?php echo $DATE1_err; ?></span>
                                <?php endif; ?>
                              </td>
                                    </tr>
                                    <tr>
                                        <td>Second Account Holder</td>
                                        <td>
                                            <input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id="Second_Account_Holder" placeholder="<?php echo $Second_Account_Holder; ?>"
                                                name="Second_Account_Holder" readonly>

                                        </td>
                                        <td>
                                        <fieldset disabled><input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id=""  placeholder=""
                                                name=""></fieldset>
                                         <input type="file"
                                                class="form-control-file"
                                                id="Second_Account_Holder_sig"  
                                                 name="Second_Account_Holder_sig">
                                        </td>
                                        <td> <input type="date" class="form-control rounded-0 bg-light" id="DATE2"
                                  placeholder="" name="DATE2">
                                <?php if (!empty($DATE2_err)): ?>
                                      <span class="text-danger"><?php echo $DATE2_err; ?></span>
                                <?php endif; ?>
                              </td>
                                    </tr>
                                    <tr>
                                        <td>3rd Signatory ( Ltd Co. Only)</td>
                                        <td>
                                            <input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id="_3rd_Signatory" placeholder="<?php echo $_3rd_Signatory; ?>"
                                                name="_3rd_Signatory" readonly>
                                        </td>
                                        <td>
                                        <fieldset disabled><input type="text"
                                                class="form-control rounded-0 bg-light"
                                                id=""  placeholder=""
                                                name=""></fieldset>
                                         
                                            <input type="file" class="form-control-file"
                                            id="_3rd_Signatory_sig"  
                                            name="_3rd_Signatory_sig">
                                        </td>
                                        <td> <input type="date" class="form-control rounded-0 bg-light" id="DATE3"
                                  placeholder="" name="DATE3">
                                <?php if (!empty($DATE3_err)): ?>
                                      <span class="text-danger"><?php echo $DATE3_err; ?></span>
                                <?php endif; ?>
                              </td>
                                        </td>

                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    <div class="form-footer pt-5 border-top">
                      <button type="submit" class="btn btn-secondary btn-pill" id="submit" name="submit">Submit</button>
                      <button type="submit" class="btn btn-light btn-pill">Cancel</button>
                    </div>
                  </form>
                </div>
                <script>
                  const submitBtn = document.getElementsByName("submit")[0];
                  const customCheckTerms = document.getElementById("customCheckTerms");
                  submitBtn.addEventListener("click", function(event) {
                    if (!customCheckTerms.checked) {
                      event.preventDefault();
                      alert("Please agree to the terms before submitting.");
                    }
                  });
                </script>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer mt-auto">
    <div class="copyright bg-white">
      <p>
        Noushin Nurjahan
      </p>
    </div>
    <script>
      var d = new Date();
      var year = d.getFullYear();
      document.getElementById("copy-year").innerHTML = year;
    </script>
  </footer>

  </div>
  </div>

  <!-- Card Offcanvas -->
  <div class="card card-offcanvas" id="contact-off">
    <div class="card-header">
      <h2>SideBar ItemRight</h2>
      <a href="#" class="btn btn-primary btn-pill px-4">Add New</a>
    </div>
    <div class="card-body">

      <div class="mb-4">
        <input type="text" class="form-control form-control-lg form-control-secondary rounded-0"
          placeholder="Search Item...">
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

      <div class="media media-sm">
        <div class="media-sm-wrapper">

        </div>
        <div class="media-body">

        </div>
      </div>

    </div>
  </div>

  <script src="plugins/jquery/jquery.min.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="plugins/simplebar/simplebar.min.js"></script>
  <script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>

  <script src="plugins/prism/prism.js"></script>

  <script src="js/mono.js"></script>
  <script src="js/chart.js"></script>
  <script src="js/map.js"></script>
  <script src="js/custom.js"></script>

  <!--  -->

</body>

</html>